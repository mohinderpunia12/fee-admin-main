/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.13-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: feeadmin_db
-- ------------------------------------------------------
-- Server version	10.11.13-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `status` varchar(15) NOT NULL,
  `hours_worked` decimal(5,2) DEFAULT NULL,
  `notes` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `school_id` bigint(20) NOT NULL,
  `staff_id` bigint(20) DEFAULT NULL,
  `student_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `attendance_school__ee2cee_idx` (`school_id`,`date`),
  KEY `attendance_staff_i_0601b5_idx` (`staff_id`,`date`),
  KEY `attendance_student_0943ef_idx` (`student_id`,`date`),
  KEY `attendance_date_32df9b_idx` (`date`,`status`),
  CONSTRAINT `attendance_school_id_07037447_fk_schools_id` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`),
  CONSTRAINT `attendance_staff_id_9bdffbda_fk_staff_id` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`),
  CONSTRAINT `attendance_student_id_d55196c7_fk_students_id` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  CONSTRAINT `attendance_staff_or_student` CHECK (`staff_id` is not null and `student_id` is null or `staff_id` is null and `student_id` is not null)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` VALUES
(1,'2025-11-13','present',NULL,'','2025-11-13 07:41:38.243320','2025-11-13 10:18:44.161127',4,2,NULL),
(2,'2025-11-03','leave',NULL,'','2025-11-13 07:42:45.730927','2025-11-13 07:42:45.730947',4,2,NULL),
(3,'2025-11-13','present',NULL,'','2025-11-13 10:19:04.024010','2025-11-13 10:19:04.024035',4,4,NULL),
(4,'2025-11-13','leave',NULL,'','2025-11-13 10:19:21.916681','2025-11-13 10:19:29.430593',4,9,NULL),
(5,'2025-11-13','present',NULL,'','2025-11-13 10:19:42.493212','2025-11-13 10:19:42.493228',4,8,NULL),
(6,'2025-11-13','present',NULL,'','2025-11-13 10:20:01.682158','2025-11-13 10:20:01.682186',4,10,NULL),
(7,'2025-11-13','present',NULL,'','2025-11-13 10:20:17.187413','2025-11-13 10:20:17.187432',4,3,NULL),
(8,'2025-11-13','present',NULL,'','2025-11-13 10:20:28.882652','2025-11-13 10:20:28.882670',4,5,NULL),
(9,'2025-11-13','present',NULL,'','2025-11-13 10:20:43.969252','2025-11-13 10:20:43.969277',4,6,NULL),
(10,'2025-11-13','present',NULL,'','2025-11-13 10:20:54.573883','2025-11-13 10:20:54.573921',4,7,NULL),
(12,'2025-11-14','present',NULL,'','2025-11-14 06:13:28.624893','2025-11-14 06:13:28.624917',4,4,NULL),
(13,'2025-11-14','present',NULL,'','2025-11-14 06:13:39.907653','2025-11-14 06:13:39.907671',4,7,NULL),
(14,'2025-11-14','present',NULL,'','2025-11-14 06:14:04.730059','2025-11-14 06:14:04.730087',4,6,NULL),
(15,'2025-11-14','present',NULL,'','2025-11-14 06:14:17.033287','2025-11-14 06:14:17.033313',4,2,NULL),
(16,'2025-11-14','present',NULL,'','2025-11-14 06:14:27.390504','2025-11-14 06:14:27.390529',4,9,NULL),
(17,'2025-11-14','present',NULL,'','2025-11-14 06:14:39.397930','2025-11-14 06:14:39.397962',4,10,NULL),
(18,'2025-11-14','present',NULL,'','2025-11-14 06:14:56.227598','2025-11-14 06:14:56.227626',4,8,NULL),
(19,'2025-11-14','present',NULL,'','2025-11-14 06:15:08.576501','2025-11-14 06:15:08.576528',4,3,NULL),
(20,'2025-11-14','present',NULL,'','2025-11-14 06:15:19.520830','2025-11-14 06:15:19.520850',4,5,NULL),
(21,'2025-11-12','present',8.00,'','2025-11-14 06:16:11.850520','2025-11-14 06:16:11.850547',4,4,NULL),
(22,'2025-11-12','present',8.00,'','2025-11-14 06:16:11.860584','2025-11-14 06:16:11.860612',4,7,NULL),
(23,'2025-11-12','present',8.00,'','2025-11-14 06:16:11.869618','2025-11-14 06:16:11.869640',4,6,NULL),
(24,'2025-11-12','present',8.00,'','2025-11-14 06:16:11.877884','2025-11-14 06:16:11.877905',4,2,NULL),
(25,'2025-11-12','present',8.00,'','2025-11-14 06:16:11.884553','2025-11-14 06:16:11.884580',4,9,NULL),
(26,'2025-11-12','present',8.00,'','2025-11-14 06:16:11.891265','2025-11-14 06:16:11.891290',4,10,NULL),
(27,'2025-11-12','present',8.00,'','2025-11-14 06:16:11.898543','2025-11-14 06:16:11.898565',4,8,NULL),
(28,'2025-11-12','present',8.00,'','2025-11-14 06:16:11.908782','2025-11-14 06:16:11.908807',4,3,NULL),
(29,'2025-11-12','present',8.00,'','2025-11-14 06:16:11.916393','2025-11-14 06:16:11.916420',4,5,NULL),
(30,'2025-11-20','present',8.00,'','2025-11-20 04:35:06.359049','2025-11-20 04:35:06.359082',13,15,NULL),
(31,'2025-11-28','present',8.00,'','2025-11-28 04:54:54.167956','2025-11-28 04:54:54.167974',21,19,NULL);
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES
(1,'Can add log entry',1,'add_logentry'),
(2,'Can change log entry',1,'change_logentry'),
(3,'Can delete log entry',1,'delete_logentry'),
(4,'Can view log entry',1,'view_logentry'),
(5,'Can add permission',2,'add_permission'),
(6,'Can change permission',2,'change_permission'),
(7,'Can delete permission',2,'delete_permission'),
(8,'Can view permission',2,'view_permission'),
(9,'Can add group',3,'add_group'),
(10,'Can change group',3,'change_group'),
(11,'Can delete group',3,'delete_group'),
(12,'Can view group',3,'view_group'),
(13,'Can add content type',4,'add_contenttype'),
(14,'Can change content type',4,'change_contenttype'),
(15,'Can delete content type',4,'delete_contenttype'),
(16,'Can view content type',4,'view_contenttype'),
(17,'Can add session',5,'add_session'),
(18,'Can change session',5,'change_session'),
(19,'Can delete session',5,'delete_session'),
(20,'Can view session',5,'view_session'),
(21,'Can add Blacklisted Token',6,'add_blacklistedtoken'),
(22,'Can change Blacklisted Token',6,'change_blacklistedtoken'),
(23,'Can delete Blacklisted Token',6,'delete_blacklistedtoken'),
(24,'Can view Blacklisted Token',6,'view_blacklistedtoken'),
(25,'Can add Outstanding Token',7,'add_outstandingtoken'),
(26,'Can change Outstanding Token',7,'change_outstandingtoken'),
(27,'Can delete Outstanding Token',7,'delete_outstandingtoken'),
(28,'Can view Outstanding Token',7,'view_outstandingtoken'),
(29,'Can add School',8,'add_school'),
(30,'Can change School',8,'change_school'),
(31,'Can delete School',8,'delete_school'),
(32,'Can view School',8,'view_school'),
(33,'Can add Class Room',9,'add_classroom'),
(34,'Can change Class Room',9,'change_classroom'),
(35,'Can delete Class Room',9,'delete_classroom'),
(36,'Can view Class Room',9,'view_classroom'),
(37,'Can add Staff Member',10,'add_staff'),
(38,'Can change Staff Member',10,'change_staff'),
(39,'Can delete Staff Member',10,'delete_staff'),
(40,'Can view Staff Member',10,'view_staff'),
(41,'Can add Salary Record',11,'add_salaryrecord'),
(42,'Can change Salary Record',11,'change_salaryrecord'),
(43,'Can delete Salary Record',11,'delete_salaryrecord'),
(44,'Can view Salary Record',11,'view_salaryrecord'),
(45,'Can add Student',12,'add_student'),
(46,'Can change Student',12,'change_student'),
(47,'Can delete Student',12,'delete_student'),
(48,'Can view Student',12,'view_student'),
(49,'Can add Fee Record',13,'add_feerecord'),
(50,'Can change Fee Record',13,'change_feerecord'),
(51,'Can delete Fee Record',13,'delete_feerecord'),
(52,'Can view Fee Record',13,'view_feerecord'),
(53,'Can add Attendance Record',14,'add_attendance'),
(54,'Can change Attendance Record',14,'change_attendance'),
(55,'Can delete Attendance Record',14,'delete_attendance'),
(56,'Can view Attendance Record',14,'view_attendance'),
(57,'Can add User',15,'add_user'),
(58,'Can change User',15,'change_user'),
(59,'Can delete User',15,'delete_user'),
(60,'Can view User',15,'view_user'),
(61,'Can add System Settings',16,'add_systemsettings'),
(62,'Can change System Settings',16,'change_systemsettings'),
(63,'Can delete System Settings',16,'delete_systemsettings'),
(64,'Can view System Settings',16,'view_systemsettings'),
(65,'Can add Guard',17,'add_guard'),
(66,'Can change Guard',17,'change_guard'),
(67,'Can delete Guard',17,'delete_guard'),
(68,'Can view Guard',17,'view_guard'),
(69,'Can add Visitor',18,'add_visitor'),
(70,'Can change Visitor',18,'change_visitor'),
(71,'Can delete Visitor',18,'delete_visitor'),
(72,'Can view Visitor',18,'view_visitor');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classrooms`
--

DROP TABLE IF EXISTS `classrooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `classrooms` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `section` varchar(10) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `school_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `classrooms_school_id_name_section_9723dd25_uniq` (`school_id`,`name`,`section`),
  KEY `classrooms_school__827510_idx` (`school_id`,`name`),
  CONSTRAINT `classrooms_school_id_f73900bf_fk_schools_id` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=261 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classrooms`
--

LOCK TABLES `classrooms` WRITE;
/*!40000 ALTER TABLE `classrooms` DISABLE KEYS */;
INSERT INTO `classrooms` VALUES
(3,'NURSURY','A','2025-11-13 05:31:58.106204','2025-11-13 05:31:58.106226',3),
(4,'LKG','A','2025-11-13 05:32:08.751275','2025-11-13 05:32:08.751301',3),
(5,'UKG','A','2025-11-13 05:32:15.888614','2025-11-13 05:32:15.888633',3),
(6,'IST','A','2025-11-13 05:52:02.868741','2025-11-13 05:52:02.868794',3),
(7,'SECOND','A','2025-11-13 05:52:13.056480','2025-11-13 05:52:13.056506',3),
(8,'THIRD','A','2025-11-13 05:52:21.750769','2025-11-13 05:52:21.750798',3),
(9,'FOURTH','A','2025-11-13 05:52:28.633646','2025-11-13 05:52:28.633677',3),
(10,'FIFTH','A','2025-11-13 05:52:41.899926','2025-11-13 05:52:41.899946',3),
(11,'SIXTH','A','2025-11-13 05:52:52.136003','2025-11-13 05:52:52.136028',3),
(12,'SEVENTH','A','2025-11-13 05:54:31.933385','2025-11-13 05:54:31.933406',3),
(13,'EIGHTH','A','2025-11-13 05:54:42.569593','2025-11-13 05:54:42.569614',3),
(14,'NINETH','A','2025-11-13 05:54:51.513739','2025-11-13 05:54:51.513760',3),
(15,'TENTH','A','2025-11-13 05:54:58.134767','2025-11-13 05:54:58.134801',3),
(16,'ELEVENTH','A','2025-11-13 05:55:21.650877','2025-11-13 05:55:21.650899',3),
(17,'TWELVETH','A','2025-11-13 05:55:36.816017','2025-11-13 05:55:36.816038',3),
(18,'Nursary','A','2025-11-13 07:26:28.343988','2025-11-13 07:26:28.344009',4),
(19,'L.KG','A','2025-11-13 07:26:49.105953','2025-11-13 07:26:49.105973',4),
(20,'U.KG','A','2025-11-13 07:27:00.156951','2025-11-13 07:27:00.156973',4),
(21,'1st','A','2025-11-13 07:27:09.878570','2025-11-13 07:27:09.878598',4),
(22,'2nd','A','2025-11-13 07:27:19.476649','2025-11-13 07:27:19.476669',4),
(23,'3rd','A','2025-11-13 07:27:27.449228','2025-11-13 07:27:27.449254',4),
(24,'4th','A','2025-11-13 07:27:35.707948','2025-11-13 07:27:35.707978',4),
(25,'5th','A','2025-11-13 07:27:44.422133','2025-11-13 07:27:44.422158',4),
(26,'6th','A','2025-11-13 07:27:51.967371','2025-11-13 07:27:51.967399',4),
(27,'7th','A','2025-11-13 07:27:59.270729','2025-11-13 07:27:59.270763',4),
(28,'8th','A','2025-11-13 07:28:06.515296','2025-11-13 07:28:06.515327',4),
(29,'9th','A','2025-11-13 07:28:14.517688','2025-11-13 07:28:14.517707',4),
(30,'10th','A','2025-11-13 07:28:24.962855','2025-11-13 07:28:24.962882',4),
(31,'11th','A','2025-11-13 07:28:32.861696','2025-11-13 07:28:32.861715',4),
(32,'12th','A','2025-11-13 07:28:41.170065','2025-11-13 07:28:41.170096',4),
(73,'Nursary','A','2025-11-19 04:22:06.759962','2025-11-19 04:22:06.759984',11),
(74,'LKG','A','2025-11-19 04:22:14.417845','2025-11-19 04:22:14.417879',11),
(75,'UKG','A','2025-11-19 04:22:20.962958','2025-11-19 04:22:20.962982',11),
(96,'Nursary','A','2025-11-20 04:23:02.662136','2025-11-20 04:23:02.662171',13),
(97,'LKG','A','2025-11-20 04:23:14.879929','2025-11-20 04:23:14.881247',13),
(98,'UKG','A','2025-11-20 04:23:22.019605','2025-11-20 04:23:22.020304',13),
(99,'1st','A','2025-11-20 04:23:33.319307','2025-11-20 04:23:33.319329',13),
(100,'2nd','A','2025-11-20 04:23:40.760014','2025-11-20 04:23:40.760040',13),
(101,'3rd','A','2025-11-20 04:23:47.532051','2025-11-20 04:23:47.532077',13),
(102,'4th','A','2025-11-20 04:23:55.100538','2025-11-20 04:23:55.100561',13),
(103,'5th','A','2025-11-20 04:24:02.728893','2025-11-20 04:24:02.728922',13),
(104,'6th','A','2025-11-20 04:24:08.888899','2025-11-20 04:24:08.888931',13),
(105,'7th','A','2025-11-20 04:24:15.172927','2025-11-20 04:24:15.172952',13),
(106,'8th','A','2025-11-20 04:24:21.606704','2025-11-20 04:24:21.606731',13),
(107,'9th','A','2025-11-20 04:24:28.330161','2025-11-20 04:24:28.330194',13),
(108,'10th','A','2025-11-20 04:24:35.892480','2025-11-20 04:24:35.892501',13),
(109,'11th','A','2025-11-20 04:24:41.454765','2025-11-20 04:24:41.454792',13),
(110,'12th','A','2025-11-20 04:24:47.675834','2025-11-20 04:24:47.675857',13),
(116,'NURSARY','A','2025-11-21 04:29:12.660780','2025-11-21 04:29:12.660805',15),
(117,'Class X','A','2025-11-21 05:43:53.836432','2025-11-21 05:43:53.836455',16),
(118,'Class IX','A','2025-11-21 05:44:06.303544','2025-11-21 05:44:06.303572',16),
(119,'Class VIII','A','2025-11-21 05:44:19.851471','2025-11-21 05:44:19.851491',16),
(120,'Class VII','A','2025-11-21 05:44:32.542774','2025-11-21 05:44:32.542794',16),
(121,'Class VI','A','2025-11-21 05:44:43.222266','2025-11-21 05:44:43.222290',16),
(122,'Class V','A','2025-11-21 05:44:54.602582','2025-11-21 05:44:54.602609',16),
(123,'Class IV','A','2025-11-21 05:45:36.315646','2025-11-21 05:45:36.315672',16),
(124,'Class III','A','2025-11-21 05:45:44.103199','2025-11-21 05:45:44.103220',16),
(125,'Class II','A','2025-11-21 05:45:55.094481','2025-11-21 05:45:55.094508',16),
(126,'Class I','A','2025-11-21 05:46:02.886816','2025-11-21 05:46:02.886838',16),
(127,'Class U.K.G','A','2025-11-21 05:46:44.756410','2025-11-21 05:46:44.756431',16),
(128,'Class L.K.G','A','2025-11-21 05:46:53.587151','2025-11-21 05:46:53.587177',16),
(129,'Class Nursery','A','2025-11-21 05:47:06.258754','2025-11-21 05:47:06.258777',16),
(131,'Nursary','A','2025-11-25 05:53:33.657509','2025-11-25 05:53:33.657540',17),
(132,'LKG','A','2025-11-25 05:53:39.742760','2025-11-25 05:53:39.742802',17),
(133,'UKG','A','2025-11-25 05:53:45.266492','2025-11-25 05:53:45.266679',17),
(134,'1st','A','2025-11-25 05:53:59.362422','2025-11-25 05:53:59.362450',17),
(135,'2nd','A','2025-11-25 05:54:20.481099','2025-11-25 05:54:20.481161',17),
(136,'3rd','A','2025-11-25 05:55:12.604664','2025-11-25 05:55:12.604879',17),
(137,'4th','A','2025-11-25 05:55:17.922190','2025-11-25 05:55:17.922216',17),
(138,'5th','A','2025-11-25 05:55:24.740981','2025-11-25 05:55:24.741010',17),
(139,'6th','A','2025-11-25 05:55:31.901406','2025-11-25 05:55:31.901428',17),
(140,'7th','A','2025-11-25 05:55:37.981575','2025-11-25 05:55:37.981602',17),
(141,'8th','A','2025-11-25 05:55:44.983618','2025-11-25 05:55:44.983644',17),
(142,'9th','A','2025-11-25 05:55:50.280420','2025-11-25 05:55:50.280451',17),
(143,'10th','A','2025-11-25 05:55:59.022569','2025-11-25 05:55:59.022600',17),
(144,'11th','A','2025-11-25 05:56:04.561631','2025-11-25 05:56:04.561657',17),
(145,'12th','A','2025-11-25 05:56:10.139705','2025-11-25 05:56:10.139729',17),
(180,'Nursary','A','2025-11-27 11:49:07.856248','2025-11-27 11:49:07.856277',8),
(181,'Nursary','A','2025-11-28 04:49:28.057132','2025-11-28 04:49:28.058039',21),
(182,'LKG','A','2025-11-28 04:49:35.216316','2025-11-28 04:49:35.216363',21),
(183,'UKG','A','2025-11-28 04:49:41.082428','2025-11-28 04:49:41.082448',21),
(184,'1st','A','2025-11-28 04:50:02.739037','2025-11-28 04:50:02.739073',21),
(185,'2nd','A','2025-11-28 04:50:12.322237','2025-11-28 04:50:12.322269',21),
(186,'3rd','A','2025-11-28 04:50:18.034097','2025-11-28 04:50:18.034164',21),
(187,'4th','A','2025-11-28 04:50:25.131952','2025-11-28 04:50:25.131975',21),
(188,'5th','A','2025-11-28 04:50:33.871459','2025-11-28 04:50:33.871480',21),
(189,'6th','A','2025-11-28 04:50:42.273212','2025-11-28 04:50:42.273232',21),
(190,'7th','A','2025-11-28 04:50:49.384167','2025-11-28 04:50:49.384187',21),
(191,'8th','A','2025-11-28 04:50:55.556994','2025-11-28 04:50:55.557014',21),
(217,'Nursery','A','2025-11-30 13:29:20.389218','2025-11-30 13:29:20.389239',25),
(218,'10','A','2025-12-01 02:08:50.962527','2025-12-01 02:08:50.962552',26),
(220,'1','a','2025-12-01 12:59:38.409495','2025-12-01 12:59:38.409518',15),
(221,'Nursary','A','2025-12-02 04:53:05.931137','2025-12-02 04:53:05.931176',27),
(222,'LKG','A','2025-12-02 04:53:18.175336','2025-12-02 04:53:18.175372',27),
(223,'UKG','A','2025-12-02 04:53:27.334636','2025-12-02 04:53:27.334659',27),
(224,'1st','A','2025-12-02 04:53:41.932010','2025-12-02 04:53:41.932029',27),
(225,'2nd','A','2025-12-02 04:53:50.916888','2025-12-02 04:53:50.916909',27),
(226,'3rd','A','2025-12-02 04:53:59.414189','2025-12-02 04:53:59.414225',27),
(227,'4th','A','2025-12-02 04:54:10.192013','2025-12-02 04:54:10.192042',27),
(228,'5th','A','2025-12-02 04:54:19.476576','2025-12-02 04:54:19.476596',27),
(229,'6th','A','2025-12-02 04:54:31.256386','2025-12-02 04:54:31.256411',27),
(230,'7th','A','2025-12-02 04:54:50.126552','2025-12-02 04:54:50.126579',27),
(231,'8th','A','2025-12-02 04:55:01.568503','2025-12-02 04:55:01.568538',27),
(233,'Nursary','A','2025-12-02 06:56:44.179782','2025-12-02 06:56:44.179804',28),
(234,'LKG','A','2025-12-02 06:56:48.849241','2025-12-02 06:56:48.849263',28),
(235,'UKG','A','2025-12-02 06:56:54.188942','2025-12-02 06:56:54.188962',28),
(236,'1st','A','2025-12-02 06:57:00.029872','2025-12-02 06:57:00.029898',28),
(237,'2nd','A','2025-12-02 06:57:05.651429','2025-12-02 06:57:05.651457',28),
(238,'3rd','A','2025-12-02 06:57:10.899336','2025-12-02 06:57:10.899357',28),
(239,'4th','A','2025-12-02 06:57:16.649343','2025-12-02 06:57:16.649370',28),
(240,'5th','A','2025-12-02 06:57:21.950302','2025-12-02 06:57:21.950323',28),
(241,'6th','A','2025-12-02 06:57:27.210858','2025-12-02 06:57:27.210884',28),
(242,'7th','A','2025-12-02 06:57:33.277727','2025-12-02 06:57:33.277754',28),
(243,'8th','A','2025-12-02 06:57:39.529512','2025-12-02 06:57:39.529539',28),
(244,'NA','NA','2025-12-03 01:11:30.534184','2025-12-03 01:11:30.534204',29),
(245,'1st','A','2025-12-03 05:51:32.655651','2025-12-03 05:51:32.656340',8),
(246,'Nursery','A','2025-12-03 06:10:16.642683','2025-12-03 06:10:16.642732',30),
(247,'L.K.G','A','2025-12-03 06:10:26.932509','2025-12-03 06:10:26.932538',30),
(248,'U.K.G.','A','2025-12-03 06:10:36.218191','2025-12-03 06:10:36.218211',30),
(249,'1ST','A','2025-12-03 06:10:43.524541','2025-12-03 06:10:43.524571',30),
(250,'2ND','A','2025-12-03 06:10:48.271678','2025-12-03 06:10:48.271697',30),
(251,'3RD','A','2025-12-03 06:10:53.592416','2025-12-03 06:10:53.592443',30),
(252,'4TH','A','2025-12-03 06:10:58.796753','2025-12-03 06:10:58.796774',30),
(253,'6TH','A','2025-12-03 06:11:10.392649','2025-12-03 06:11:10.392672',30),
(254,'5TH','A','2025-12-03 06:11:18.168251','2025-12-03 06:11:18.168282',30),
(255,'7TH','A','2025-12-03 06:11:24.202049','2025-12-03 06:11:24.202070',30),
(256,'8TH','A','2025-12-03 06:11:29.877038','2025-12-03 06:11:29.877058',30),
(257,'9TH','A','2025-12-03 06:11:34.787599','2025-12-03 06:11:34.787628',30),
(258,'10TH','A','2025-12-03 06:11:43.383211','2025-12-03 06:11:43.383238',30),
(259,'11TH','A','2025-12-03 06:11:51.818443','2025-12-03 06:11:51.818471',30),
(260,'12TH','A','2025-12-03 06:11:57.542816','2025-12-03 06:11:57.542844',30);
/*!40000 ALTER TABLE `classrooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_users_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES
(1,'2025-11-12 21:39:00.546847','2','aryan (Superuser)',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',15,1),
(2,'2025-11-12 21:39:44.732784','1','root (Superuser)',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',15,1),
(3,'2025-11-13 03:18:10.372849','1','root (Superuser)',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',15,2),
(4,'2025-11-13 03:41:10.801483','4','mohinderpunia82@gmail.com (Superuser)',1,'[{\"added\": {}}]',15,1),
(5,'2025-11-13 05:27:49.034722','4','mohinderpunia82@gmail.com (Superuser)',2,'[{\"changed\": {\"fields\": [\"First name\", \"Last name\", \"Email address\", \"Staff status\", \"Superuser status\"]}}]',15,1),
(6,'2025-11-13 05:29:31.675967','4','mohinderpunia82@gmail.com (Superuser)',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',15,1),
(7,'2025-11-13 05:32:39.728317','4','mohinderpunia82@gmail.com (Superuser)',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',15,1),
(8,'2025-11-13 06:41:01.330785','4','mohinderpunia82@gmail.com (Superuser)',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',15,1),
(9,'2025-11-17 01:27:20.900900','3','test_school (School Admin)',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',15,2),
(10,'2025-11-18 07:25:20.612270','27','Anshi Chaturvedi - January 2027',3,'',13,2),
(11,'2025-11-18 07:25:20.612615','26','Anshi Chaturvedi - March 2026',3,'',13,2),
(12,'2025-11-18 07:25:20.612642','25','Anshi Chaturvedi - February 2026',3,'',13,2),
(13,'2025-11-18 07:25:20.612661','24','Anshi Chaturvedi - January 2026',3,'',13,2),
(14,'2025-11-18 07:25:20.612676','23','Anshi Chaturvedi - December 2025',3,'',13,2),
(15,'2025-11-18 07:25:20.612689','22','Anshi Chaturvedi - November 2025',3,'',13,2),
(16,'2025-11-18 07:25:20.612702','21','Anshi Chaturvedi - October 2025',3,'',13,2),
(17,'2025-11-18 07:25:20.612714','20','Anshi Chaturvedi - September 2025',3,'',13,2),
(18,'2025-11-18 07:25:20.612725','19','Anshi Chaturvedi - August 2025',3,'',13,2),
(19,'2025-11-18 07:25:20.612737','18','Anshi Chaturvedi - July 2025',3,'',13,2),
(20,'2025-11-18 07:25:20.612749','17','Anshi Chaturvedi - June 2025',3,'',13,2),
(21,'2025-11-18 07:25:20.612761','16','Anshi Chaturvedi - May 2025',3,'',13,2),
(22,'2025-11-18 07:25:20.612772','15','Anshi Chaturvedi - April 2025',3,'',13,2),
(23,'2025-11-19 04:58:56.886635','16','Aryan Chaturvedi (17)',3,'',12,2),
(24,'2025-11-30 12:55:16.836930','3','test_school (School Admin)',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',15,2),
(25,'2025-11-30 12:55:57.927233','3','test_school (School Admin)',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',15,2);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES
(1,'admin','logentry'),
(3,'auth','group'),
(2,'auth','permission'),
(4,'contenttypes','contenttype'),
(14,'school','attendance'),
(9,'school','classroom'),
(13,'school','feerecord'),
(17,'school','guard'),
(11,'school','salaryrecord'),
(8,'school','school'),
(10,'school','staff'),
(12,'school','student'),
(16,'school','systemsettings'),
(15,'school','user'),
(18,'school','visitor'),
(5,'sessions','session'),
(6,'token_blacklist','blacklistedtoken'),
(7,'token_blacklist','outstandingtoken');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES
(1,'contenttypes','0001_initial','2025-11-12 17:48:35.913526'),
(2,'contenttypes','0002_remove_content_type_name','2025-11-12 17:48:35.947675'),
(3,'auth','0001_initial','2025-11-12 17:48:36.065849'),
(4,'auth','0002_alter_permission_name_max_length','2025-11-12 17:48:36.087772'),
(5,'auth','0003_alter_user_email_max_length','2025-11-12 17:48:36.092798'),
(6,'auth','0004_alter_user_username_opts','2025-11-12 17:48:36.096816'),
(7,'auth','0005_alter_user_last_login_null','2025-11-12 17:48:36.100567'),
(8,'auth','0006_require_contenttypes_0002','2025-11-12 17:48:36.102902'),
(9,'auth','0007_alter_validators_add_error_messages','2025-11-12 17:48:36.108759'),
(10,'auth','0008_alter_user_username_max_length','2025-11-12 17:48:36.112664'),
(11,'auth','0009_alter_user_last_name_max_length','2025-11-12 17:48:36.116583'),
(12,'auth','0010_alter_group_name_max_length','2025-11-12 17:48:36.131999'),
(13,'auth','0011_update_proxy_permissions','2025-11-12 17:48:36.137532'),
(14,'auth','0012_alter_user_first_name_max_length','2025-11-12 17:48:36.141991'),
(15,'school','0001_initial','2025-11-12 17:48:37.070513'),
(16,'admin','0001_initial','2025-11-12 17:48:37.130600'),
(17,'admin','0002_logentry_remove_auto_add','2025-11-12 17:48:37.142842'),
(18,'admin','0003_logentry_add_action_flag_choices','2025-11-12 17:48:37.153170'),
(19,'sessions','0001_initial','2025-11-12 17:48:37.175592'),
(20,'token_blacklist','0001_initial','2025-11-12 17:48:37.256006'),
(21,'token_blacklist','0002_outstandingtoken_jti_hex','2025-11-12 17:48:37.279001'),
(22,'token_blacklist','0003_auto_20171017_2007','2025-11-12 17:48:37.298956'),
(23,'token_blacklist','0004_auto_20171017_2013','2025-11-12 17:48:37.340356'),
(24,'token_blacklist','0005_remove_outstandingtoken_jti','2025-11-12 17:48:37.363631'),
(25,'token_blacklist','0006_auto_20171017_2113','2025-11-12 17:48:37.423392'),
(26,'token_blacklist','0007_auto_20171017_2214','2025-11-12 17:48:37.525973'),
(27,'token_blacklist','0008_migrate_to_bigautofield','2025-11-12 17:48:37.622476'),
(28,'token_blacklist','0010_fix_migrate_to_bigautofield','2025-11-12 17:48:37.639328'),
(29,'token_blacklist','0011_linearizes_history','2025-11-12 17:48:37.640773'),
(30,'token_blacklist','0012_alter_outstandingtoken_user','2025-11-12 17:48:37.652945'),
(31,'token_blacklist','0013_alter_blacklistedtoken_options_and_more','2025-11-12 17:48:37.667680'),
(32,'school','0002_staff_total_amount_student_total_amount','2025-11-18 02:22:16.691744'),
(33,'school','0003_staff_profile_picture_student_profile_picture_and_more','2025-11-26 03:32:06.738825');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES
('020wwuxboaqg7s1gfu3kpyxaf33604hm','.eJxVjDkOwjAUBe_iGlnYP7YTSvqcIfqbSQDZUpYKcXeIlALaNzPvZQbc1nHYFp2HSczFeHP63Qj5oWUHcsdyq5ZrWeeJ7K7Ygy62r6LP6-H-HYy4jN-6bRInDCTeMUDOQhKYUxJGyhFi4_IZArWBO58ciMaIHbXSeEUHqub9AQYkOMM:1vPgy5:Z2WdWJQBvH0NdSakLKkHHL9Zz_tZKpeCuJVOKtQ8WTA','2025-12-14 12:55:57.945143'),
('1nbau2y2e3vnl9dd4qxyrbqm13v472go','.eJxVjDkOwjAUBe_iGlnYP7YTSvqcIfqbSQDZUpYKcXeIlALaNzPvZQbc1nHYFp2HSczFeHP63Qj5oWUHcsdyq5ZrWeeJ7K7Ygy62r6LP6-H-HYy4jN-6bRInDCTeMUDOQhKYUxJGyhFi4_IZArWBO58ciMaIHbXSeEUHqub9AQYkOMM:1vL0xs:b4r9RnNaFS1ibLXMXy1muPjVzdb6b9j-crjPqzdgwIA','2025-12-01 15:16:24.205439'),
('6rbd6pv2smp6csqvhc0yx28xy9miax98','.eJxVjMsOwiAQRf-FtSE8C7h07zeQgRmkaiAp7cr479qkC93ec859sQjbWuM2aIkzsjNT7PS7JcgPajvAO7Rb57m3dZkT3xV-0MGvHel5Ody_gwqjfmsv0GBx2QkbLJD1KlGCiSB47aXOKH1WWqUAJLV10k7FoKFAxpWSQbD3B-wROD4:1vJml5:--5GRjRklOO1Kj47EjTMNVsGtFpcgxv1IJqmbi3Z6Jk','2025-11-28 05:54:07.597913'),
('6z7utid89senza35qvypnn7zqzonqpqq','.eJxVjEEOwiAQRe_C2pBiGaa4dN8zNDMMSNVAUtqV8e7apAvd_vfef6mJtjVPW4vLNIu6KKNOvxtTeMSyA7lTuVUdalmXmfWu6IM2PVaJz-vh_h1kavlbc7TRodCZoIuEQcQgpgF9cpadEcMhAHbs_QBeerKWIQGIDQ6pN0m9PwT6OHI:1vJNye:p-wLJj2nnZoN9OeEQe8UU9Vd2eof2fRzFGYkEW4FtUI','2025-11-27 03:26:28.320610'),
('fjyih03h55gqiyypudvxw7i2gyejexlx','.eJxVjDkOwjAUBe_iGlnYP7YTSvqcIfqbSQDZUpYKcXeIlALaNzPvZQbc1nHYFp2HSczFeHP63Qj5oWUHcsdyq5ZrWeeJ7K7Ygy62r6LP6-H-HYy4jN-6bRInDCTeMUDOQhKYUxJGyhFi4_IZArWBO58ciMaIHbXSeEUHqub9AQYkOMM:1vKtmH:cuDrE_tRfYuD6P20e6wKUxXIjJRlbpIcMZJZ_oFpLHg','2025-12-01 07:35:57.486213'),
('izbmw412tikf3vp1b2r3eservif1f0n2','.eJxVjMsOwiAQRf-FtSEzFAbq0r3fQIZHpWogKe3K-O_apAvd3nPOfQnP21r81vPi5yTOAsXpdwscH7nuIN253pqMra7LHOSuyIN2eW0pPy-H-3dQuJdvrQkYgiNUQwRABTRQJBsGnHJO1rHVRBomM1qLLpEyZnSo0MUcWJsg3h-nQjZ8:1vJIZ6:ypFmMk_lzwFVAYyS9FAn9i6Pxs1oH_SGpfN004wXISA','2025-11-26 21:39:44.741809'),
('k1g3bdwgwplge0cf27378mgr82q40xc6','.eJxVjDkOwjAUBe_iGlnYP7YTSvqcIfqbSQDZUpYKcXeIlALaNzPvZQbc1nHYFp2HSczFeHP63Qj5oWUHcsdyq5ZrWeeJ7K7Ygy62r6LP6-H-HYy4jN-6bRInDCTeMUDOQhKYUxJGyhFi4_IZArWBO58ciMaIHbXSeEUHqub9AQYkOMM:1vOo45:27HbOVRhUhjhkMHVnOFr8TOAowuCYiABKSA-ai6GKCw','2025-12-12 02:18:29.097355'),
('k1lx7rkhajb1h0xhz9hmn1xrcahv27k9','.eJxVjDkOwjAUBe_iGlnYP7YTSvqcIfqbSQDZUpYKcXeIlALaNzPvZQbc1nHYFp2HSczFeHP63Qj5oWUHcsdyq5ZrWeeJ7K7Ygy62r6LP6-H-HYy4jN-6bRInDCTeMUDOQhKYUxJGyhFi4_IZArWBO58ciMaIHbXSeEUHqub9AQYkOMM:1vKoT0:M16OIXKOeQjOkFPRV_mHeetFfIqqHVmKDZQ7zPCCKwc','2025-12-01 01:55:42.036513'),
('qsyx575p8lqwctrxhf5znszq5qfjfr8z','.eJxVjMsOwiAQRf-FtSE8C7h07zeQgRmkaiAp7cr479qkC93ec859sQjbWuM2aIkzsjNT7PS7JcgPajvAO7Rb57m3dZkT3xV-0MGvHel5Ody_gwqjfmsv0GBx2QkbLJD1KlGCiSB47aXOKH1WWqUAJLV10k7FoKFAxpWSQbD3B-wROD4:1vJUY5:q-jo4vZSlFR_G6FX4oV9QNrbrJjVc85le_3uOMpgU2k','2025-11-27 10:27:29.336947'),
('zmaxsy3379qd30wjq64f4qiq4eyfzwh4','.eJxVjEEOwiAQRe_C2pBiGaa4dN8zNDMMSNVAUtqV8e7apAvd_vfef6mJtjVPW4vLNIu6KKNOvxtTeMSyA7lTuVUdalmXmfWu6IM2PVaJz-vh_h1kavlbc7TRodCZoIuEQcQgpgF9cpadEcMhAHbs_QBeerKWIQGIDQ6pN0m9PwT6OHI:1vJR0v:pOxQVTIUlVxVwLDkx-RFyJK-pM85daaZ-6YWcHZkUU4','2025-11-27 06:41:01.353552');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fee_records`
--

DROP TABLE IF EXISTS `fee_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fee_records` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `academic_year` varchar(20) NOT NULL,
  `fee_components` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`fee_components`)),
  `total_amount` decimal(10,2) NOT NULL,
  `late_fee` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) NOT NULL,
  `paid` tinyint(1) NOT NULL,
  `paid_on` date DEFAULT NULL,
  `payment_mode` varchar(20) NOT NULL,
  `notes` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `school_id` bigint(20) NOT NULL,
  `student_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fee_records_school_id_student_id_month_year_47bd9a11_uniq` (`school_id`,`student_id`,`month`,`year`),
  KEY `fee_records_school__3df929_idx` (`school_id`,`year`,`month`),
  KEY `fee_records_student_9b45d3_idx` (`student_id`,`paid`),
  CONSTRAINT `fee_records_school_id_2a1bb6ed_fk_schools_id` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`),
  CONSTRAINT `fee_records_student_id_ab133879_fk_students_id` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fee_records`
--

LOCK TABLES `fee_records` WRITE;
/*!40000 ALTER TABLE `fee_records` DISABLE KEYS */;
INSERT INTO `fee_records` VALUES
(1,11,2025,'2025-26','{\"tuition\": 800, \"transport\": 0, \"library\": 0, \"lab\": 0, \"sports\": 0, \"exam\": 0}',800.00,0.00,0.00,0,NULL,'','','2025-11-13 05:37:36.123209','2025-11-13 05:37:36.123243',3,1),
(10,11,2025,'2025-2026','{}',8000.00,0.00,0.00,0,NULL,'','आदरणीय अभिभावक जी,\n      आपको सूचित किया जाता है कि आपके बच्चे की फीस बकाया है। कृपया 20 नवंबर 2025 से अपने बच्चे की फीस जमा करवाएं।\n\nधन्यवाद','2025-11-14 04:57:44.924535','2025-11-14 05:27:09.612901',4,2),
(11,11,2025,'2025-2026','{}',12000.00,0.00,0.00,0,NULL,'','R/P\n   You are informed that your child\'s fees are pending. Please pay the child\'s fees on time.\n\nThankyou','2025-11-14 05:44:11.910427','2025-11-14 05:44:11.910452',4,6),
(12,11,2025,'2025-2026','{}',57800.00,0.00,0.00,0,NULL,'','','2025-11-14 05:54:15.427743','2025-11-14 05:54:15.427772',4,8),
(34,11,2025,'2025-2026','{}',1000.00,0.00,0.00,0,NULL,'','','2025-11-20 04:33:32.713298','2025-11-20 04:33:32.713326',13,18),
(48,12,2025,'2025-2026','{}',1666.67,0.00,0.00,0,NULL,'','','2025-12-02 07:02:36.718218','2025-12-02 07:02:36.718245',28,64),
(49,12,2025,'2025-26','{}',2083.33,0.00,0.00,1,'2025-12-03','cash','','2025-12-03 06:15:55.898141','2025-12-03 06:16:47.906058',30,67);
/*!40000 ALTER TABLE `fee_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guard`
--

DROP TABLE IF EXISTS `guard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `guard` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `shift` varchar(50) NOT NULL,
  `employee_id` varchar(50) DEFAULT NULL,
  `profile_picture` varchar(100) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `school_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `guard_school_id_c55ac1da_fk_schools_id` (`school_id`),
  CONSTRAINT `guard_school_id_c55ac1da_fk_schools_id` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guard`
--

LOCK TABLES `guard` WRITE;
/*!40000 ALTER TABLE `guard` DISABLE KEYS */;
INSERT INTO `guard` VALUES
(6,'Mahender Punia','7027733053','Night','0001','profiles/guards/WhatsApp_Image_2025-10-29_at_10_MqMGmJH.45.36_92f983a5.jpg','2025-11-26 09:50:37.930774','2025-11-26 09:50:37.930801',8),
(9,'aaa','9518163580','MOR','1564664','','2025-12-03 06:20:43.424383','2025-12-03 06:20:43.424405',30);
/*!40000 ALTER TABLE `guard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salary_records`
--

DROP TABLE IF EXISTS `salary_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `salary_records` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `base_salary` decimal(10,2) NOT NULL,
  `allowances` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`allowances`)),
  `deductions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`deductions`)),
  `bonuses` decimal(10,2) NOT NULL,
  `net_salary` decimal(10,2) NOT NULL,
  `paid` tinyint(1) NOT NULL,
  `paid_on` date DEFAULT NULL,
  `payment_mode` varchar(20) NOT NULL,
  `notes` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `school_id` bigint(20) NOT NULL,
  `staff_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `salary_records_school_id_staff_id_month_year_be7be3fe_uniq` (`school_id`,`staff_id`,`month`,`year`),
  KEY `salary_reco_school__4be383_idx` (`school_id`,`year`,`month`),
  KEY `salary_reco_staff_i_85504f_idx` (`staff_id`,`paid`),
  CONSTRAINT `salary_records_school_id_3008f8b5_fk_schools_id` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`),
  CONSTRAINT `salary_records_staff_id_5ff2902d_fk_staff_id` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_records`
--

LOCK TABLES `salary_records` WRITE;
/*!40000 ALTER TABLE `salary_records` DISABLE KEYS */;
INSERT INTO `salary_records` VALUES
(7,11,2025,15000.00,'{}','{}',0.00,15000.00,0,NULL,'','','2025-11-16 03:55:03.788477','2025-11-16 03:55:03.788499',7,12),
(25,12,2025,20000.00,'{}','{}',0.00,20000.00,0,NULL,'','','2025-12-02 06:26:15.959684','2025-12-02 06:26:15.959705',8,23);
/*!40000 ALTER TABLE `salary_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schools`
--

DROP TABLE IF EXISTS `schools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `schools` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `subscription_start` date DEFAULT NULL,
  `subscription_end` date DEFAULT NULL,
  `active` tinyint(1) NOT NULL,
  `payment_amount` decimal(10,2) DEFAULT NULL,
  `last_payment_date` date DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schools`
--

LOCK TABLES `schools` WRITE;
/*!40000 ALTER TABLE `schools` DISABLE KEYS */;
INSERT INTO `schools` VALUES
(3,'ASIAN HIGH SCHOOL','9802862560','ASIANHIGHSCHOOL0@GMAIL.COM','SHIV COLONY GALI NO 1 ,KAITHAL ROAD,KARNAL','','2025-11-13','2025-12-13',1,199.00,'2025-11-13','2025-11-13 05:30:55.290191','2025-11-13 10:56:34.594702'),
(4,'NIRAKAR JYOTI VIDYA MANDIR','7777077176','njvidyamandir@gmail.com','ON PEONT ROAD GULLARPUR (KARNAL)','school_logos/WhatsApp_Image_2025-11-14_at_10.53.19_ec5dcd29.jpg','2025-11-13','2025-12-13',1,199.00,'2025-11-13','2025-11-13 07:25:29.479641','2025-11-16 12:56:30.083954'),
(7,'UTKANTI HOME HEALTH CARE PVT. LTD.','9998396899','parmarjaswant073@gmail.com','A Block fist floor, shop No 1.Ashiwad Complex, Chankyapuri Sola Bridge','school_logos/IMG-20251116-WA0005.jpg','2025-11-16','2025-12-16',1,199.00,'2025-11-16','2025-11-16 03:52:13.412404','2025-11-16 12:54:16.187010'),
(8,'Fee Admin','9518233053','makegraphy92@gmail.com','VPO Kaul,District Kaithal Haryana 136021','school_logos/WhatsApp_Image_2025-10-29_at_10.45.36_92f983a5.jpg','2025-11-17','2025-12-17',1,199.00,'2025-11-17','2025-11-17 01:14:35.478694','2025-11-17 01:15:13.747854'),
(11,'Mother\'s Care','9813856789','mothercare736@gmail.com','228 New  Prem Nagar Karnal','','2025-11-19','2025-12-19',1,199.00,'2025-11-20','2025-11-19 04:21:27.184216','2025-11-20 01:33:27.055179'),
(13,'Saraswati Public School Amupur','9017214055','saraswatipublicschool2019@gmail.com','Village Amupur Karnal','','2025-11-20','2025-12-20',1,199.00,'2025-11-21','2025-11-20 04:21:41.440369','2025-11-21 01:45:01.636558'),
(15,'RAVINDRA SCHOOL','9417284369','kondal1683@gmail.com','kangra jawali','school_logos/my_logo.png','2025-11-26','2025-12-26',1,199.00,'2025-11-26','2025-11-21 04:25:39.978825','2025-11-26 12:52:20.811667'),
(16,'Gyan Vidya Peeth','7833015056','gvpjangal@gmail.com','VPO Jangal Alampur Distt.Kangra H.P 176082','','2025-11-21','2025-12-21',1,199.00,'2025-11-21','2025-11-21 05:42:59.885519','2025-11-21 10:41:25.467951'),
(17,'Shivalik Public School Shahapur','8607043002','bijendershahapur23@gmail.com',NULL,'','2025-11-25','2025-12-25',1,199.00,'2025-11-26','2025-11-25 05:52:31.472436','2025-11-26 00:08:44.981537'),
(21,'MD public School','9466367356','chanderparkasharya@gmail.com','Village Daha, District Karnal Haryana','','2025-11-28','2025-12-28',1,299.00,'2025-11-28','2025-11-28 04:46:26.544637','2025-11-28 13:08:17.831290'),
(25,'Shashank','5454554554','cursor.08-oxbow@icloud.com',NULL,'school_logos/IMG_9770.jpeg','2025-11-30','2025-12-07',1,NULL,NULL,'2025-11-30 13:28:58.605358','2025-11-30 13:28:58.605379'),
(26,'Testt33','5454554545','cursor.08-oxbow@icloud.com',NULL,'','2025-12-01','2025-12-08',1,NULL,NULL,'2025-12-01 02:07:48.827425','2025-12-01 02:07:48.827468'),
(27,'MAHARANA PARTAP PUBLIC SCHOOL AGONDH','7206056824','mpps9508@gmail.com','VPO Agondh,District Karnal','','2025-12-02','2026-01-02',1,299.00,'2025-12-03','2025-12-02 04:52:13.041572','2025-12-03 03:06:47.303219'),
(28,'GRAMIN VIKAS PUBLIC SCHOOL','7015658715','vinay99816@gmail.com','VPO BALU,DISTRCT KARNAL','','2025-12-02','2026-01-02',1,299.00,'2025-12-03','2025-12-02 06:56:07.247374','2025-12-03 03:06:24.628832'),
(29,'Testing School','8318683717','mandaknidevi04@gmail.com','Vikas Nagar , Sector 7 , Near PNB Bank , Lucknow','school_logos/Gemini_Generated_Image_s2alrxs2alrxs2al_4VxLdPP.png','2025-12-03','2025-12-10',1,NULL,NULL,'2025-12-03 01:10:15.605888','2025-12-03 01:10:15.605920'),
(30,'VAID PUBLIC SCHOOL','9518163580','vedpublicschool15@gmail.com',NULL,'','2025-12-03','2025-12-10',1,NULL,NULL,'2025-12-03 06:09:19.284800','2025-12-03 06:09:19.285662');
/*!40000 ALTER TABLE `schools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `qualifications` longtext NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `joining_date` date NOT NULL,
  `employment_status` varchar(10) NOT NULL,
  `monthly_salary` decimal(10,2) NOT NULL,
  `bank_account_no` varchar(50) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `ifsc_code` varchar(11) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `school_id` bigint(20) NOT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `profile_picture` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `staff_school__d6480a_idx` (`school_id`,`employment_status`),
  CONSTRAINT `staff_school_id_161c90f4_fk_schools_id` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES
(2,'Joginder Singh','Clerk','BA','9306757602','2025-04-01','active',10000.00,'','','','2025-11-13 07:35:26.200726','2025-11-13 07:35:26.200755',4,NULL,NULL),
(3,'Sonia Devi','Teacher','BA','9729065408','2025-04-01','active',5300.00,'','','','2025-11-13 10:07:36.375017','2025-11-13 10:07:36.375040',4,NULL,NULL),
(4,'Babli','Teacher','JBT','9485618808','2025-04-01','active',5000.00,'','','','2025-11-13 10:08:42.049027','2025-11-13 10:08:42.049055',4,NULL,NULL),
(5,'Yogita','teacher','BA','8295426026','2025-04-01','active',5299.00,'','','','2025-11-13 10:09:38.241624','2025-11-13 10:09:38.241641',4,NULL,NULL),
(6,'Jaspal Singh','Driver','10','7496051895','2025-04-01','active',8000.00,'','','','2025-11-13 10:11:22.467868','2025-11-13 10:11:22.467886',4,NULL,NULL),
(7,'Birbal','Driver','10','8295444947','2025-04-01','active',10000.00,'','','','2025-11-13 10:12:19.218005','2025-11-13 10:12:19.218023',4,NULL,NULL),
(8,'Pooja Rani','Teacher','B.Ed','9728187285','2025-07-01','active',6000.00,'','','','2025-11-13 10:13:24.324665','2025-11-13 10:13:24.324687',4,NULL,NULL),
(9,'Neeru','Teeacher','MA','8683090621','2025-07-01','active',6000.00,'','','','2025-11-13 10:14:12.169852','2025-11-13 10:14:12.169876',4,NULL,NULL),
(10,'Pinki Rani','Teacher','B.Ed','9017240155','2025-04-01','active',6000.00,'','','','2025-11-13 10:14:58.985553','2025-11-13 10:14:58.985569',4,NULL,NULL),
(12,'Jaswant','Manager','Nursing','9998396899','2023-11-16','active',15000.00,'','','','2025-11-16 03:54:28.128108','2025-11-16 03:54:28.128136',7,NULL,NULL),
(15,'Jagdeep','Teacher TGT','MA','9996994439','2025-04-08','active',5000.00,'','','','2025-11-20 04:27:46.121330','2025-11-20 04:27:46.121393',13,60000.00,NULL),
(19,'Aarti Sharma','Science Teacher','MA','8930115105','2025-03-28','active',4000.00,'','','','2025-11-28 04:53:47.185879','2025-11-28 04:53:47.185910',21,47997.00,''),
(23,'Mahender Punia','PTI','M.Sc','9518233053','2025-12-01','active',20000.00,'','','','2025-12-01 01:43:26.888354','2025-12-01 01:43:26.888390',8,240000.00,'profiles/staff/14082.jpg'),
(26,'Vinod Kumar','Mathematics','MA','7015465715','2012-12-02','active',10000.00,'','','','2025-12-02 07:21:39.957477','2025-12-02 07:21:39.957508',28,120000.00,'profiles/staff/Screenshot_2025-11-30-19-56-09-94_a23b203fd3aafc6dcb84e438dda678b6.jpg');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `admission_no` varchar(50) DEFAULT NULL,
  `roll_number` varchar(50) DEFAULT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `address` longtext NOT NULL,
  `parent_guardian_name` varchar(200) NOT NULL,
  `parent_guardian_contact` varchar(15) NOT NULL,
  `enrollment_status` varchar(10) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `classroom_id` bigint(20) DEFAULT NULL,
  `school_id` bigint(20) NOT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `profile_picture` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `students_school__cd9efc_idx` (`school_id`,`enrollment_status`),
  KEY `students_admissi_becaf8_idx` (`admission_no`),
  KEY `students_roll_nu_954626_idx` (`roll_number`),
  KEY `students_classroom_id_9ef5538f_fk_classrooms_id` (`classroom_id`),
  CONSTRAINT `students_classroom_id_9ef5538f_fk_classrooms_id` FOREIGN KEY (`classroom_id`) REFERENCES `classrooms` (`id`),
  CONSTRAINT `students_school_id_f7f2de45_fk_schools_id` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES
(1,'01','01','SAMRAT','RANA','2020-03-05','male','09802862560','shiv colony\nkaithal road','JOGINDER SINGH','9802862560','active','2025-11-13 05:35:25.108742','2025-11-13 05:35:25.108763',3,3,NULL,NULL),
(2,'68','1','Lavit','lavit','2020-11-22','male','7496808031','V.P.O - Gonder (Karnal)','Tinku','7496808031','active','2025-11-13 07:32:42.513378','2025-11-13 07:32:42.513397',18,4,NULL,NULL),
(4,'','6','Tejasvi','Tejasvi','2013-05-24','female','9306757602','VPO - Gonder (Karnal)','Joginder Singh','9306757602','active','2025-11-13 10:27:43.333054','2025-11-13 10:27:43.333074',27,4,NULL,NULL),
(6,'','6','Palak','Palak','2018-12-09','female','8950700113','Village Gullarpur (KARNAL)','Rajinder','8950700113','active','2025-11-14 05:40:45.148511','2025-11-14 05:40:45.148528',20,4,NULL,NULL),
(7,'','6','Aviraj','Aviraj','2021-01-20','male','9813972576','Village Peont (Karnal)','Samsher Singh','9813972576','active','2025-11-14 05:49:51.275039','2025-11-24 05:22:45.109850',18,4,16150.00,NULL),
(8,NULL,'7','Prachi','Prachi','2018-05-26','female','9729648110','Village - Gullarpur (KARNAL)','Omparkash','9729648110','active','2025-11-14 05:52:34.047351','2025-11-14 05:52:34.047382',21,4,NULL,NULL),
(9,'672','1','Yuvraj','Yuvraj','2011-03-25','male','9466517522','Village - Gullarpur (Karnal)','Ramniwas','9466517522','active','2025-11-14 06:06:40.038467','2025-11-14 06:06:40.038487',28,4,NULL,NULL),
(10,'675','2','Chirakshi','Rana','2012-09-04','female','9991980320','Village - Katlaheri (Karnal)','Sunny','9991980320','active','2025-11-14 06:08:40.694865','2025-11-14 06:08:40.694892',28,4,NULL,NULL),
(11,'678','03','Dilawar','Singh','2011-11-07','male','8307285110','Village - Gullarpur (Karnal)','Pala Ram','8307285110','active','2025-11-14 06:12:15.946936','2025-11-14 06:12:15.946958',28,4,NULL,NULL),
(18,NULL,'01','Diksha','Diksha','2012-12-20','female','8630284970','VPO Sitamai.Karnal','Rajiv Kumar','8630284970','active','2025-11-20 04:32:12.992916','2025-11-20 04:32:12.992942',105,13,12000.00,NULL),
(20,'345456','20','RAVINDER','KONDAL','1995-02-12','male','245454','KANGRA HP','RSFDSFD','24277','inactive','2025-11-21 04:33:53.092680','2025-11-21 04:37:34.520725',116,15,20000.00,NULL),
(21,NULL,'01','AABHA','ABHA','2010-12-20','female','9996165742','VPO.AMUPUR,TEH. NISSING,KARNAL','MR.KRISHAN','9996165742','active','2025-11-21 06:59:57.709878','2025-11-21 06:59:57.710976',107,13,NULL,NULL),
(22,NULL,'02','AANCHAL','AANCHAL','2011-05-21','female','9813665078','VPO.BRASS ,TEH.NISSING,KARNAL','MR.SHIV KUMAR','9813665078','active','2025-11-21 07:02:07.915936','2025-11-21 07:02:07.916143',107,13,NULL,NULL),
(23,'1102','03','AARJU','AARJU','2011-04-15','female','9991955590','VPO.AMUPUR,TEH.NISSING,KARNAL','MR.KARAN','9991955590','active','2025-11-21 07:06:00.281447','2025-11-21 07:06:00.281467',107,13,NULL,NULL),
(24,NULL,'04','ANJU','ANJU','2012-06-17','female','8295314906','VPO.BRASS,TEH.NISSING,KARNAL','MR.BITTU RAM','8295314906','active','2025-11-21 07:07:37.628633','2025-11-21 07:07:37.628663',107,13,NULL,NULL),
(25,'','05','CHAHAT','CHAHAT','2011-12-06','female','9050585127','VPO.SITAMAI,TEH.NIGDU,KARNAL','MR.VINOD','9050585127','active','2025-11-21 07:10:31.584777','2025-11-21 07:10:31.584799',107,13,NULL,NULL),
(26,'1064','06','KAVITA','KAVITA','2010-07-12','female','9813528397','VPO.AMUPUR,TEH.NISSING,KARNAL','MR.GURMUKH','9813528397','active','2025-11-21 07:12:21.381884','2025-11-21 07:12:21.381900',107,13,NULL,NULL),
(27,'1098','07','KHANAK','KHANAK','2010-09-17','female','7827434342','VPO.SITAMAI,TEH.NIGDU,KARNAL','MR.JAGMEET','7827434342','active','2025-11-21 07:13:47.624777','2025-11-21 07:13:47.624802',107,13,NULL,NULL),
(28,NULL,'08','MADU','MADU','2011-10-26','female','7357001081','VPO.BRASS,TEH.NISSING,KARNAL','MR.BALWINDER','7357001081','active','2025-11-21 07:15:21.804258','2025-11-21 07:15:21.804280',107,13,NULL,NULL),
(29,NULL,'09','MANSHI','MANSHI','2009-06-04','female','9671445519','VPO.DIKTANA,TEH.NIGDU,KARNAL','MR.SURESH','9671445519','active','2025-11-21 07:17:06.857323','2025-11-21 07:17:06.857340',107,13,NULL,NULL),
(30,NULL,'10','RIYA','RIYA','2012-01-18','female','8814820008','VPO.DIKTANA,TEH.NIGDU,KARNAL','MR.KIRANPAL','8814820008','active','2025-11-21 07:20:30.902715','2025-11-21 07:20:30.902754',107,13,NULL,NULL),
(31,NULL,'11','TAMANA','TAMANA','2012-03-13','female','7027256177','VPO.SITAMAI,TEH.NIGDU,KARNAL','MR.KAPTAIN','7027256177','active','2025-11-21 07:22:17.540358','2025-11-21 07:22:17.540378',107,13,NULL,NULL),
(32,NULL,'12','VARSHA','VARSHA','2012-07-15','female','8053784285','VPO.SITAMAI,TEH.NIGDU,KARNAL','MR.SURENDER','8053784285','active','2025-11-21 07:23:45.198335','2025-11-21 07:23:45.198356',107,13,NULL,NULL),
(33,NULL,'13','SULEKHA','SUEKHA','2012-11-04','female','8685815707','VPO.SITAMAI,TEH.NIGDU,KARNAL','MR.NARESH','8685815707','active','2025-11-21 07:25:28.946595','2025-11-21 07:25:28.946618',107,13,NULL,NULL),
(34,'529','14','ANKIT','ANKIT','2012-02-21','male','8930258665','VPO.BRASS,TEH.NISSING,KARNAL','MR.RAMPAL','8930258665','active','2025-11-21 07:27:00.779882','2025-11-21 07:27:00.779910',107,13,NULL,NULL),
(35,'575','15','ARUN','ARUN','2012-03-20','male','8813016011','VPO.DIKTANA,TEH.NIGDU,KARNAL','MR.SHARWAN','8813016011','active','2025-11-21 07:28:41.079979','2025-11-21 07:28:41.080000',107,13,NULL,NULL),
(36,'1101','16','ASHU','ASHU','2012-02-29','male','9896913273','VPO.BRASS,TEH.NISSING,KARNAL','MR.MAHINDER','9896913273','active','2025-11-21 07:30:30.417309','2025-11-21 07:30:30.417344',107,13,NULL,NULL),
(37,'1100','17','DEWANSH','DEWANSH','2010-09-22','male','8930284970','VPO.SITAMAI,TEH.NIGDU,KARNAL','MR.RAJIV','8930284970','active','2025-11-21 07:32:20.583137','2025-11-21 07:32:20.583153',107,13,NULL,NULL),
(38,NULL,'18','DUSHYANT','DUSHTYANT','2011-10-11','male','9812770812','VPO.SITAMAI,TEH.NIGDU,KARNAL','MR.RAVINDER','9812770812','active','2025-11-21 07:34:03.179176','2025-11-21 07:34:03.179196',107,13,NULL,NULL),
(39,NULL,'19','GOURAV','GOURAV','2009-05-13','male','7988411540','VPO.AMUPUR,TEH.NISSING,KARNAL','MR.ASHOK','7988411540','active','2025-11-21 07:35:40.595986','2025-11-21 07:35:40.596008',107,13,NULL,NULL),
(40,NULL,'20','HARSH','HARSH','2011-10-21','male','9992789085','VPO.SITAMAI,TEH.NIGDU,KARNAL','MR.DHARMPAL','9992789085','active','2025-11-21 07:41:27.489849','2025-11-21 07:41:27.489869',107,13,NULL,NULL),
(41,NULL,'21','JASHANPREET','JASHANPREET','2009-06-14','male','9518087231','VPO.BRASS,TEH.NISSING,KARNALL','MR.JARNAIL','9518087231','active','2025-11-21 07:44:30.823959','2025-11-21 07:44:30.823991',107,13,NULL,NULL),
(42,'1099','22','KARAN','KARAN','2010-02-13','male','8278453713','VPO.BRASS,TEH.NISSING,KARNAL','MR. DEV PRAKASH','8278453713','active','2025-11-21 07:47:22.875071','2025-11-21 07:47:22.875090',107,13,NULL,NULL),
(43,NULL,'23','MANOJ','MANOJ','2008-08-18','male','9813475356','VPO.SITAMAI,TEH.NIGDU,KARNAL','MR.BANSHI','9813475356','active','2025-11-21 07:49:20.147062','2025-11-21 07:49:20.147079',107,13,NULL,NULL),
(44,'1068','24','PAWAN','PAWAN','2008-08-06','male','9729387147','VPO.AMUPUR,TEH.NISSING,KARNAL','MR.LAKHWINDER','9729387147','active','2025-11-21 07:51:18.260437','2025-11-21 07:51:18.260453',107,13,NULL,NULL),
(45,'1011','25','RAJAT','RAJAT','2011-02-14','male','9896139935','VPO.BRASS,TEH.NISSING,KARNAL','MR.BILLU RAM','9896139935','active','2025-11-21 07:52:46.692411','2025-11-21 07:52:46.692449',107,13,NULL,NULL),
(49,NULL,'01','Mafi','Sirsi','2010-07-25','female','9050721929','Village Sirsi','Shishpal','9050721929','active','2025-11-25 06:49:48.086408','2025-11-25 06:49:48.086444',144,17,4770.00,NULL),
(61,'1516166','202023','Shashank','Kumar','2015-11-30','male','7651515151','Patna','Ishan','6151616161','active','2025-11-30 13:30:45.278000','2025-11-30 13:30:45.278030',217,25,25000.00,''),
(62,'123456','202','Shashank','Kumar','2010-12-01','male','5672626262','Patna','Ishan','56261616161','active','2025-12-01 02:10:27.916514','2025-12-01 02:10:27.916541',218,26,20000.00,''),
(63,'00001','001','MAHENDER','PUNIA','2024-02-02','male','9813727608','VPO AGONGH KARNAL','SOMPAL','9999999999','active','2025-12-02 04:59:48.440404','2025-12-02 04:59:48.440435',221,27,25000.00,'profiles/students/WhatsApp_Image_2025-11-13_at_9.44.31_AM_3.jpeg'),
(64,'605','20','TAMANA','TAMANA','2016-10-04','female','9671003896','JALALA VIRAN','KHEMCHAND','9671003896','active','2025-12-02 07:02:03.479325','2025-12-02 07:02:03.479342',237,28,20000.00,''),
(65,'Dummy','212','Anshi','Chaturvedi','2002-12-19','male','8318683717','No','Rajeev','8318683717','active','2025-12-03 01:12:51.870761','2025-12-03 01:12:51.870803',244,29,20000.00,'profiles/students/aryanshi-favicon.ico'),
(66,'0001','22','Mahender','Choudhary','2023-03-03','male','7027733053','Kaul','Somwati Devi','9935904676','active','2025-12-03 03:12:28.213899','2025-12-03 03:12:28.213921',180,8,35000.00,'profiles/students/WhatsApp_Image_2025-11-04_at_15_WU0lPNa.26.12_2bbbb93f.jpg'),
(67,'345','1','AA','jain','2015-03-08','male','9518163580','42 New Grain Market gharaunda','VIRENDER','9518163580','active','2025-12-03 06:13:53.704173','2025-12-03 06:13:53.704213',250,30,25000.00,'profiles/students/WhatsApp_Image_2024-02-26_at_8.42.07_PM-removebg-preview.png');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `monthly_subscription_amount` decimal(10,2) NOT NULL,
  `trial_period_days` int(11) NOT NULL,
  `payment_qr_code` varchar(100) DEFAULT NULL,
  `payment_upi_id` varchar(100) NOT NULL,
  `support_email` varchar(254) NOT NULL,
  `support_mobile` varchar(15) NOT NULL,
  `support_address` longtext NOT NULL,
  `tutorial_video` varchar(100) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  `updated_by_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_settings_updated_by_id_cf1dfbba_fk_users_id` (`updated_by_id`),
  CONSTRAINT `system_settings_updated_by_id_cf1dfbba_fk_users_id` FOREIGN KEY (`updated_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES
(1,299.00,7,'payment/IMG-20250714-WA0009_uuaEEx8.jpg','','mohinderpunia82@gmail.com','+91 95182 33053','Pal Nagar, Kachwa Road, Karnal, Haryana (India)','tutorial/BeautyPlusCam_20251201081248493_save_kis2GBW.mp4','2025-12-01 02:50:55.396411',4);
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token_blacklist_blacklistedtoken`
--

DROP TABLE IF EXISTS `token_blacklist_blacklistedtoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `token_blacklist_blacklistedtoken` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blacklisted_at` datetime(6) NOT NULL,
  `token_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_id` (`token_id`),
  CONSTRAINT `token_blacklist_blacklistedtoken_token_id_3cc7fe56_fk` FOREIGN KEY (`token_id`) REFERENCES `token_blacklist_outstandingtoken` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=322 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token_blacklist_blacklistedtoken`
--

LOCK TABLES `token_blacklist_blacklistedtoken` WRITE;
/*!40000 ALTER TABLE `token_blacklist_blacklistedtoken` DISABLE KEYS */;
INSERT INTO `token_blacklist_blacklistedtoken` VALUES
(1,'2025-11-13 03:17:06.045488',1),
(2,'2025-11-13 03:18:53.898313',2),
(3,'2025-11-13 03:41:26.221653',5),
(4,'2025-11-13 03:48:11.797226',7),
(5,'2025-11-13 04:20:46.305051',9),
(6,'2025-11-13 05:21:39.118477',13),
(7,'2025-11-13 05:22:13.984117',12),
(8,'2025-11-13 05:24:46.597909',14),
(9,'2025-11-13 05:29:41.507594',15),
(10,'2025-11-13 05:32:47.470704',16),
(11,'2025-11-13 05:43:12.514677',18),
(12,'2025-11-13 05:48:16.116113',20),
(13,'2025-11-13 07:51:45.691965',24),
(14,'2025-11-13 07:52:38.742752',25),
(16,'2025-11-13 07:55:13.155435',26),
(17,'2025-11-13 08:18:31.332899',27),
(18,'2025-11-13 08:33:43.777088',30),
(19,'2025-11-13 10:47:06.020179',33),
(20,'2025-11-13 10:58:34.611141',35),
(21,'2025-11-13 10:59:50.454338',36),
(22,'2025-11-13 13:38:05.402836',38),
(23,'2025-11-13 13:40:29.357542',39),
(24,'2025-11-13 13:41:03.253535',41),
(25,'2025-11-13 13:52:43.968835',40),
(26,'2025-11-14 01:29:21.290208',43),
(27,'2025-11-14 01:36:32.756364',45),
(28,'2025-11-14 01:38:00.192535',46),
(29,'2025-11-14 01:38:09.498626',44),
(30,'2025-11-14 02:19:33.811206',47),
(31,'2025-11-14 02:21:02.193786',48),
(32,'2025-11-14 05:05:13.731513',49),
(33,'2025-11-14 05:10:01.153748',50),
(34,'2025-11-14 06:00:03.491969',51),
(35,'2025-11-14 06:17:06.509300',52),
(36,'2025-11-14 10:49:47.722128',54),
(37,'2025-11-14 11:25:35.932631',55),
(38,'2025-11-14 11:26:36.263753',56),
(39,'2025-11-14 11:27:58.088683',57),
(40,'2025-11-14 12:51:46.148271',58),
(41,'2025-11-14 12:52:28.465485',59),
(42,'2025-11-14 14:36:20.106976',60),
(43,'2025-11-14 14:37:04.113154',61),
(44,'2025-11-15 01:38:06.036583',62),
(45,'2025-11-15 01:39:22.199746',63),
(46,'2025-11-15 03:12:27.950972',64),
(47,'2025-11-15 03:14:04.462070',65),
(48,'2025-11-15 04:53:29.453753',66),
(49,'2025-11-15 04:54:07.803229',67),
(50,'2025-11-15 04:59:20.769362',69),
(51,'2025-11-15 05:00:59.836511',70),
(52,'2025-11-15 05:15:38.576634',73),
(53,'2025-11-15 05:49:56.820197',72),
(54,'2025-11-15 05:56:12.573967',75),
(55,'2025-11-15 05:56:39.340967',76),
(56,'2025-11-15 05:57:45.064161',77),
(57,'2025-11-15 06:03:02.510422',78),
(58,'2025-11-15 06:05:18.033558',79),
(59,'2025-11-15 06:14:20.113240',81),
(60,'2025-11-15 07:52:42.369463',82),
(61,'2025-11-15 07:55:52.521051',83),
(62,'2025-11-15 08:11:51.264888',84),
(63,'2025-11-15 08:12:48.616806',85),
(64,'2025-11-15 11:44:21.444563',86),
(65,'2025-11-15 14:10:05.444999',87),
(66,'2025-11-15 14:10:57.959138',88),
(67,'2025-11-16 02:58:52.677024',90),
(68,'2025-11-16 04:00:38.453156',93),
(69,'2025-11-16 08:29:01.550277',98),
(70,'2025-11-16 08:29:18.991313',99),
(71,'2025-11-16 10:17:16.779241',101),
(72,'2025-11-16 10:46:09.017344',102),
(73,'2025-11-16 11:12:37.254120',103),
(74,'2025-11-16 12:53:36.552227',106),
(75,'2025-11-16 12:57:28.712619',107),
(76,'2025-11-16 12:58:54.070259',108),
(77,'2025-11-16 14:16:18.281319',109),
(78,'2025-11-16 14:41:15.363609',110),
(79,'2025-11-16 15:03:38.978898',111),
(80,'2025-11-16 18:37:02.839043',113),
(81,'2025-11-16 18:38:12.414378',114),
(82,'2025-11-17 01:07:25.349171',118),
(83,'2025-11-17 01:08:33.805016',120),
(84,'2025-11-17 01:10:41.322080',121),
(85,'2025-11-17 01:12:26.194562',122),
(86,'2025-11-17 01:15:31.489977',124),
(87,'2025-11-17 01:17:15.605431',125),
(88,'2025-11-17 01:24:40.822273',126),
(89,'2025-11-17 01:44:29.257606',129),
(90,'2025-11-17 03:41:01.940605',134),
(91,'2025-11-17 03:42:12.007891',135),
(92,'2025-11-17 05:17:14.865687',136),
(93,'2025-11-17 06:49:18.098816',137),
(94,'2025-11-17 07:42:14.248150',138),
(95,'2025-11-17 08:49:20.284386',139),
(96,'2025-11-17 12:40:28.445652',140),
(97,'2025-11-17 12:41:16.939376',141),
(98,'2025-11-17 13:25:50.590457',142),
(99,'2025-11-17 13:30:29.136419',143),
(100,'2025-11-17 13:48:01.575498',144),
(101,'2025-11-17 13:54:16.475465',146),
(102,'2025-11-17 14:16:46.408510',147),
(103,'2025-11-17 14:19:01.538891',148),
(104,'2025-11-17 14:19:13.323963',149),
(105,'2025-11-17 14:32:59.578018',150),
(106,'2025-11-18 01:13:35.650646',152),
(107,'2025-11-18 01:14:16.435390',153),
(108,'2025-11-18 03:03:52.536155',154),
(109,'2025-11-18 03:18:28.277884',158),
(110,'2025-11-18 03:19:14.488086',159),
(111,'2025-11-18 03:20:39.577283',160),
(112,'2025-11-18 03:27:25.065578',161),
(113,'2025-11-18 05:00:36.771145',162),
(114,'2025-11-18 06:36:47.817674',163),
(115,'2025-11-18 06:49:07.575735',165),
(116,'2025-11-18 07:56:10.568270',166),
(117,'2025-11-18 08:36:46.599262',167),
(118,'2025-11-18 10:55:02.471100',169),
(119,'2025-11-18 11:57:26.718451',170),
(120,'2025-11-18 21:43:08.439211',172),
(121,'2025-11-18 21:43:35.532759',173),
(122,'2025-11-19 00:36:34.462697',174),
(123,'2025-11-19 01:44:28.976798',175),
(124,'2025-11-19 01:54:42.126185',176),
(125,'2025-11-19 01:57:33.169892',177),
(126,'2025-11-19 02:37:05.693581',178),
(127,'2025-11-19 04:19:02.638769',180),
(128,'2025-11-19 04:31:12.355924',182),
(129,'2025-11-19 04:31:46.763350',183),
(130,'2025-11-19 06:56:47.240020',185),
(131,'2025-11-19 07:04:21.028772',187),
(132,'2025-11-19 07:31:12.616350',189),
(133,'2025-11-19 11:19:24.105540',190),
(134,'2025-11-19 12:15:35.076562',191),
(135,'2025-11-19 15:10:35.846550',193),
(136,'2025-11-19 16:11:34.953184',194),
(137,'2025-11-20 00:59:26.272784',196),
(138,'2025-11-20 01:32:21.818381',198),
(139,'2025-11-20 01:33:58.898875',199),
(140,'2025-11-20 04:36:24.261703',202),
(141,'2025-11-20 08:37:28.083813',205),
(142,'2025-11-20 12:39:09.735343',208),
(143,'2025-11-20 16:33:59.175476',213),
(144,'2025-11-21 01:45:47.968602',214),
(145,'2025-11-21 01:49:06.389378',215),
(146,'2025-11-21 02:28:36.179815',216),
(147,'2025-11-21 02:29:41.511593',217),
(148,'2025-11-21 07:35:58.466146',227),
(149,'2025-11-21 07:53:31.408335',224),
(150,'2025-11-21 10:41:55.508433',229),
(151,'2025-11-21 14:24:42.465234',230),
(152,'2025-11-21 15:29:25.014855',233),
(153,'2025-11-21 15:30:05.994920',234),
(154,'2025-11-22 02:12:04.807637',235),
(155,'2025-11-22 02:13:16.198980',236),
(156,'2025-11-22 02:24:03.246378',237),
(157,'2025-11-22 09:22:24.870600',238),
(158,'2025-11-22 11:16:24.964835',239),
(159,'2025-11-22 12:39:47.070815',240),
(160,'2025-11-23 00:39:43.083165',241),
(161,'2025-11-23 01:59:33.335996',242),
(162,'2025-11-23 09:45:22.791425',243),
(163,'2025-11-23 13:10:25.715094',245),
(164,'2025-11-24 03:19:28.535237',246),
(165,'2025-11-24 04:30:50.263969',247),
(166,'2025-11-24 05:44:04.895320',248),
(167,'2025-11-24 12:26:37.184301',249),
(168,'2025-11-24 13:13:59.706013',251),
(169,'2025-11-24 13:20:01.114598',252),
(170,'2025-11-24 14:47:50.620372',253),
(171,'2025-11-25 01:35:37.792387',254),
(172,'2025-11-25 06:28:37.035549',256),
(173,'2025-11-26 00:07:26.371902',258),
(174,'2025-11-26 00:09:27.208981',259),
(175,'2025-11-26 02:55:34.322609',261),
(176,'2025-11-26 04:03:28.240222',262),
(177,'2025-11-26 06:57:29.635305',264),
(178,'2025-11-26 06:58:41.903092',265),
(179,'2025-11-26 07:00:03.469499',266),
(180,'2025-11-26 07:04:10.957879',267),
(181,'2025-11-26 07:08:46.848997',268),
(182,'2025-11-26 07:09:59.835804',269),
(183,'2025-11-26 09:47:12.167231',270),
(184,'2025-11-26 09:49:17.486059',272),
(185,'2025-11-26 09:50:01.110058',271),
(186,'2025-11-26 09:50:22.424508',274),
(187,'2025-11-26 09:51:04.146461',273),
(188,'2025-11-26 09:51:25.465796',276),
(189,'2025-11-26 09:52:14.044525',275),
(190,'2025-11-26 09:52:30.563019',277),
(191,'2025-11-26 09:54:02.118935',278),
(192,'2025-11-26 10:22:06.151420',280),
(193,'2025-11-26 10:22:28.149911',281),
(194,'2025-11-26 10:23:03.695125',282),
(195,'2025-11-26 10:26:12.602077',283),
(196,'2025-11-26 10:26:38.797691',284),
(197,'2025-11-26 10:29:40.847138',285),
(198,'2025-11-26 12:49:34.723628',286),
(199,'2025-11-26 12:49:50.753250',287),
(200,'2025-11-26 12:52:43.617388',288),
(201,'2025-11-26 12:53:30.285796',289),
(202,'2025-11-27 01:05:54.435086',290),
(203,'2025-11-27 01:06:15.590744',291),
(204,'2025-11-27 01:12:14.866043',292),
(205,'2025-11-27 05:21:10.662459',293),
(206,'2025-11-27 05:22:16.340430',294),
(207,'2025-11-27 05:22:23.225969',295),
(208,'2025-11-27 05:33:17.803364',297),
(209,'2025-11-27 05:44:43.671767',298),
(210,'2025-11-27 06:03:01.298717',299),
(211,'2025-11-27 06:18:22.891695',300),
(212,'2025-11-27 07:43:27.919357',301),
(213,'2025-11-27 07:54:36.335683',303),
(214,'2025-11-27 07:57:29.277668',304),
(215,'2025-11-27 09:07:39.585432',306),
(216,'2025-11-27 10:15:59.032894',307),
(217,'2025-11-27 10:57:18.440208',308),
(218,'2025-11-27 10:59:45.276617',309),
(219,'2025-11-27 11:01:22.207776',310),
(220,'2025-11-27 11:08:26.798275',311),
(221,'2025-11-27 11:47:22.790488',312),
(222,'2025-11-27 11:48:31.406998',313),
(223,'2025-11-27 11:51:34.220046',314),
(224,'2025-11-27 11:51:59.483893',315),
(225,'2025-11-28 00:28:16.316885',316),
(226,'2025-11-28 02:16:45.712001',319),
(227,'2025-11-28 02:17:09.919129',318),
(228,'2025-11-28 02:19:37.700631',321),
(229,'2025-11-28 02:45:23.290474',325),
(230,'2025-11-28 02:45:49.430515',324),
(231,'2025-11-28 02:46:54.028371',326),
(232,'2025-11-28 02:50:50.352091',328),
(233,'2025-11-28 03:00:45.262041',327),
(234,'2025-11-28 03:05:00.621799',329),
(235,'2025-11-28 03:10:04.677532',332),
(236,'2025-11-28 03:12:34.067584',333),
(237,'2025-11-28 04:58:23.691660',335),
(238,'2025-11-28 05:08:18.588952',337),
(239,'2025-11-28 06:18:04.088080',339),
(240,'2025-11-28 06:18:33.273544',340),
(241,'2025-11-28 06:19:27.711517',341),
(242,'2025-11-28 06:20:29.604541',342),
(243,'2025-11-28 06:37:29.316897',344),
(244,'2025-11-28 06:37:43.680226',345),
(245,'2025-11-28 07:30:11.222878',347),
(246,'2025-11-28 07:31:27.478477',348),
(247,'2025-11-28 12:47:04.777835',353),
(248,'2025-11-28 12:47:38.561432',354),
(249,'2025-11-28 12:50:46.604984',356),
(250,'2025-11-28 13:02:24.376466',357),
(251,'2025-11-28 13:07:01.819718',358),
(252,'2025-11-28 13:08:34.504723',359),
(253,'2025-11-28 13:09:32.691638',360),
(254,'2025-11-29 00:56:01.664726',361),
(255,'2025-11-29 02:08:23.675247',362),
(256,'2025-11-29 04:49:46.360364',364),
(257,'2025-11-29 04:50:08.758312',365),
(258,'2025-11-29 04:52:30.668331',366),
(259,'2025-11-29 06:20:18.552036',368),
(260,'2025-11-29 11:23:49.406396',371),
(261,'2025-11-29 13:02:17.810634',374),
(262,'2025-11-30 00:12:04.267419',376),
(263,'2025-11-30 00:13:13.101016',377),
(264,'2025-11-30 02:08:56.519414',378),
(265,'2025-11-30 03:39:32.918038',379),
(266,'2025-11-30 08:36:38.832279',380),
(267,'2025-11-30 08:38:19.623493',381),
(268,'2025-11-30 08:39:47.506999',382),
(269,'2025-11-30 08:53:09.958937',383),
(270,'2025-11-30 12:59:33.393379',384),
(271,'2025-11-30 13:26:59.908671',388),
(272,'2025-11-30 15:49:00.334026',393),
(273,'2025-12-01 01:02:45.938683',394),
(274,'2025-12-01 01:13:20.412466',395),
(275,'2025-12-01 01:17:10.143130',396),
(276,'2025-12-01 01:17:43.751171',397),
(277,'2025-12-01 01:19:30.562561',398),
(278,'2025-12-01 01:39:21.808996',399),
(279,'2025-12-01 01:44:07.114969',400),
(280,'2025-12-01 01:45:38.977292',401),
(281,'2025-12-01 01:46:21.164320',402),
(282,'2025-12-01 02:05:59.662810',404),
(283,'2025-12-01 02:44:21.949465',407),
(284,'2025-12-01 02:45:10.063203',408),
(285,'2025-12-01 02:47:07.707767',409),
(286,'2025-12-01 02:51:36.087088',410),
(287,'2025-12-01 05:26:29.389413',411),
(288,'2025-12-01 11:22:35.889542',414),
(289,'2025-12-02 00:03:19.793711',418),
(290,'2025-12-02 00:20:47.578525',419),
(291,'2025-12-02 00:34:26.890624',420),
(292,'2025-12-02 01:16:40.719831',421),
(293,'2025-12-02 05:05:37.165772',425),
(294,'2025-12-02 05:23:28.739766',426),
(295,'2025-12-02 06:27:01.850050',427),
(296,'2025-12-02 06:27:20.046311',428),
(297,'2025-12-02 06:28:54.999040',429),
(298,'2025-12-02 06:31:05.297988',430),
(299,'2025-12-02 07:08:25.932266',433),
(300,'2025-12-02 07:22:22.813577',434),
(301,'2025-12-02 07:23:12.755481',435),
(302,'2025-12-02 12:43:11.475984',438),
(303,'2025-12-02 13:55:57.061369',439),
(304,'2025-12-03 02:08:47.768225',443),
(305,'2025-12-03 02:20:27.381936',444),
(306,'2025-12-03 02:32:46.155801',445),
(307,'2025-12-03 03:05:43.313680',447),
(308,'2025-12-03 03:08:27.982077',448),
(309,'2025-12-03 03:13:55.014387',449),
(310,'2025-12-03 06:06:53.231869',450),
(311,'2025-12-03 06:18:37.373331',452),
(312,'2025-12-03 06:19:36.647762',453),
(313,'2025-12-03 06:20:55.556666',454),
(314,'2025-12-03 06:21:38.938654',455),
(315,'2025-12-06 15:02:35.355159',456),
(316,'2025-12-06 15:06:03.217017',457),
(317,'2025-12-06 15:17:39.258051',458),
(318,'2025-12-06 16:45:51.627562',460),
(319,'2025-12-07 03:05:35.421250',461),
(320,'2025-12-07 04:11:10.807971',462),
(321,'2025-12-07 04:47:42.134848',463);
/*!40000 ALTER TABLE `token_blacklist_blacklistedtoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token_blacklist_outstandingtoken`
--

DROP TABLE IF EXISTS `token_blacklist_outstandingtoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `token_blacklist_outstandingtoken` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `token` longtext NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `expires_at` datetime(6) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `jti` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_blacklist_outstandingtoken_jti_hex_d9bdf6f7_uniq` (`jti`),
  KEY `token_blacklist_outstandingtoken_user_id_83bc629a_fk_users_id` (`user_id`),
  CONSTRAINT `token_blacklist_outstandingtoken_user_id_83bc629a_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=464 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token_blacklist_outstandingtoken`
--

LOCK TABLES `token_blacklist_outstandingtoken` WRITE;
/*!40000 ALTER TABLE `token_blacklist_outstandingtoken` DISABLE KEYS */;
INSERT INTO `token_blacklist_outstandingtoken` VALUES
(1,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYwODYxMCwiaWF0IjoxNzYzMDAzODEwLCJqdGkiOiJjODU4YWMyMmJmYjc0Y2YzYTQ0YjYyMjI1OTAyMzQwYSIsInVzZXJfaWQiOiIyIn0.8c79RNmB142SKgq3QW-lu6tmJVE8M25W1OTyhVzoXaQ','2025-11-13 03:16:50.049086','2025-11-20 03:16:50.000000',2,'c858ac22bfb74cf3a44b62225902340a'),
(2,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYwODcyMCwiaWF0IjoxNzYzMDAzOTIwLCJqdGkiOiJjY2MzZmY2MGVjMjA0NzA0YjM4YTZiOTdlM2MyNGJkYyIsInVzZXJfaWQiOiIyIn0.fUGtapQ4MWlEwyUo0_Tt-CaWKsc5JopI80e6S_s7fmg','2025-11-13 03:18:40.219518','2025-11-20 03:18:40.000000',2,'ccc3ff60ec204704b38a6b97e3c24bdc'),
(3,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYwOTA5NywiaWF0IjoxNzYzMDA0Mjk3LCJqdGkiOiI5NWY2ZmU1MjhiOTc0ZTExYjY4ZDViNWY0YWRhYjZhOCIsInVzZXJfaWQiOiIzIn0.bq82FceGg9C5wCVKBSUWMuciLSpIDdJqxV9DFaf-pZg','2025-11-13 03:24:57.707488','2025-11-20 03:24:57.000000',NULL,'95f6fe528b974e11b68d5b5f4adab6a8'),
(4,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYwOTExOSwiaWF0IjoxNzYzMDA0MzE5LCJqdGkiOiI1NWEzMjFiMzZjNGI0M2Q5ODM1ODhlNWY5ZDRjODAyNCIsInVzZXJfaWQiOiIzIn0.U2BCZWsNwMioPK3yhdzwmMTDxDioMkeccrITkhQ2d2Y','2025-11-13 03:25:19.740529','2025-11-20 03:25:19.000000',NULL,'55a321b36c4b43d983588e5f9d4c8024'),
(5,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYwOTkzNywiaWF0IjoxNzYzMDA1MTM3LCJqdGkiOiIyODZmZTBiMDAxMGI0MjE1YmJlMGJhOGE1MDBkNGE3YSIsInVzZXJfaWQiOiIxIn0.bz_4VP7-mv0Qy6nNgphJvQrfGZzfnX5ckfjBBi9fuBY','2025-11-13 03:38:57.023579','2025-11-20 03:38:57.000000',1,'286fe0b0010b4215bbe0ba8a500d4a7a'),
(6,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYxMDA5MywiaWF0IjoxNzYzMDA1MjkzLCJqdGkiOiI4MTg0YzcxNjJkNDU0ZDUyYWNiZGVmNmJiMWI1ZGVlYiIsInVzZXJfaWQiOiI0In0.RwmV5E9OIFDiNuKORAVzbwsowe8O87ZdBGfaUSbjMNM','2025-11-13 03:41:33.907189','2025-11-20 03:41:33.000000',4,'8184c7162d454d52acbdef6bb1b5deeb'),
(7,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYxMDE0MSwiaWF0IjoxNzYzMDA1MzQxLCJqdGkiOiI0MjY2NzQ4MzFiYzM0MWFhOGJlZDEwZTNhOGMzZjU0ZSIsInVzZXJfaWQiOiIyIn0.VZnvKRJ6e8IopycrU9uI43pzh-ApR2BX7zN_RVRTX_c','2025-11-13 03:42:21.736460','2025-11-20 03:42:21.000000',2,'426674831bc341aa8bed10e3a8c3f54e'),
(8,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYxMjEwOSwiaWF0IjoxNzYzMDA3MzA5LCJqdGkiOiJkNGVkYTMxMTQ5NDg0NTk1YjBjYjdkMzAxNTc3NTZlOCIsInVzZXJfaWQiOiI1In0.mzHF87JiLzWxmocLYlQw2TSL3wbsHD31qDIcOwtyPlc','2025-11-13 04:15:09.996240','2025-11-20 04:15:09.000000',NULL,'d4eda31149484595b0cb7d30157756e8'),
(9,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYxMjExNCwiaWF0IjoxNzYzMDA3MzE0LCJqdGkiOiI0Mjg0YzFmMDdmNmM0MTE0YTAzNWFjYmMxY2VmMTg5YiIsInVzZXJfaWQiOiI1In0.K7JmDTDOi-POOsmsacE6biApFeJnpWbZbFDihKHERPM','2025-11-13 04:15:14.839189','2025-11-20 04:15:14.000000',NULL,'4284c1f07f6c4114a035acbc1cef189b'),
(10,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYxMzMxNCwiaWF0IjoxNzYzMDA4NTE0LCJqdGkiOiJmNGJlM2RmZjQ3MzM0ODRkOWZjZDI3YmFmZjgyMmFjYiIsInVzZXJfaWQiOiIyIn0.NurqMJ9FxqiJHq4NnRS35o7OPzJotFdSjrf1EKLkTO8','2025-11-13 04:35:14.558008','2025-11-20 04:35:14.000000',2,'f4be3dff4733484d9fcd27baff822acb'),
(11,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYxNTY4NiwiaWF0IjoxNzYzMDEwODg2LCJqdGkiOiIzMmM3N2I2ZDY2MGI0MWM5YjFlYzkyZmM5YmM0M2UzZCIsInVzZXJfaWQiOiI0In0.6YctlPH7W1j4ApplmconYbSdq0Czv75jDgLtZSYe-fw','2025-11-13 05:14:46.481220','2025-11-20 05:14:46.000000',4,'32c77b6d660b41c9b1ec92fc9bc43e3d'),
(12,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYxNjA2NCwiaWF0IjoxNzYzMDExMjY0LCJqdGkiOiI1NDdkMTRjZWJhNzI0NmI3OWVmYmJkMWUwY2ViN2ZiNyIsInVzZXJfaWQiOiI0In0.8yrMsLPPqaFxNMvgDhUJ0vKm8fs6g1EKKKJd1WjB8Z8','2025-11-13 05:21:04.558430','2025-11-20 05:21:04.000000',4,'547d14ceba7246b79efbbd1e0ceb7fb7'),
(13,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYxNjA4MSwiaWF0IjoxNzYzMDExMjgxLCJqdGkiOiJiOTI2OTE0OTEwNGE0N2Q2OTBiZWE2NTMzODExZjNkNSIsInVzZXJfaWQiOiIyIn0.-Pi0jnS8RP0GgC6DE_7qQIBGNVhea5Z35C7EtFe71Js','2025-11-13 05:21:21.515455','2025-11-20 05:21:21.000000',2,'b9269149104a47d690bea6533811f3d5'),
(14,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYxNjE0MiwiaWF0IjoxNzYzMDExMzQyLCJqdGkiOiI0ZDA1YzExMDNhMDM0NDRjOGI5ZmExM2E4NTVmOTNiNiIsInVzZXJfaWQiOiIxIn0.5qH7TkZk6aFqz__SaTdpuo1jnMYq0wgrFsunPFb3-f8','2025-11-13 05:22:22.620787','2025-11-20 05:22:22.000000',1,'4d05c1103a03444c8b9fa13a855f93b6'),
(15,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYxNjMzMiwiaWF0IjoxNzYzMDExNTMyLCJqdGkiOiI0NThlNWI5NGUzMDM0M2I1OTJkYzA2NmVjM2E5Zjg0NiIsInVzZXJfaWQiOiI0In0.ZqgnMGfI-KEa0Nzl0Jcxpt7ys9w_GcdyOHnZqTKP1vM','2025-11-13 05:25:32.712871','2025-11-20 05:25:32.000000',4,'458e5b94e30343b592dc066ec3a9f846'),
(16,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYxNjYxOCwiaWF0IjoxNzYzMDExODE4LCJqdGkiOiI1OGJiYjlkMjY1ZDc0MzgzYTc4YWI5MDBkOWMxZDg3MCIsInVzZXJfaWQiOiI0In0.qUxIWuiOeQv6jJkSnYWbLm5Emu2F9OLsJOWgGfp7p5I','2025-11-13 05:30:18.366907','2025-11-20 05:30:18.000000',4,'58bbb9d265d74383a78ab900d9c1d870'),
(17,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYxNjY1NSwiaWF0IjoxNzYzMDExODU1LCJqdGkiOiI0NWI1OGQ2YWJmMjM0ODRiOGYxMDQxZTRjZDI0Y2FjMSIsInVzZXJfaWQiOiI2In0.zoYBr_uXG-E3uobfKpNPOL9kfqn1_qnuzsl1sSz_8YU','2025-11-13 05:30:55.658838','2025-11-20 05:30:55.000000',6,'45b58d6abf23484b8f1041e4cd24cac1'),
(18,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYxNjY4MiwiaWF0IjoxNzYzMDExODgyLCJqdGkiOiI5NWFhYTMxMWMxNGQ0MDk4OGY1YTRmNWRiZGRjMGU2NCIsInVzZXJfaWQiOiI2In0.yKEF_yyFTpekCDEEiF2leLlXopXvQXUlLEh-p6If-jk','2025-11-13 05:31:22.900386','2025-11-20 05:31:22.000000',6,'95aaa311c14d40988f5a4f5dbddc0e64'),
(19,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYxNjc5MSwiaWF0IjoxNzYzMDExOTkxLCJqdGkiOiIzNGQ5NGE3Y2U4ODE0YzFkOGU5MzJhZmM3NDg4ZGQ4OCIsInVzZXJfaWQiOiI0In0.LetijxIkLRhuKCxgoE2hwoix11QK8ceR_qlkLXGkUlM','2025-11-13 05:33:11.715739','2025-11-20 05:33:11.000000',4,'34d94a7ce8814c1d8e932afc7488dd88'),
(20,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYxNzQzMiwiaWF0IjoxNzYzMDEyNjMyLCJqdGkiOiI3ZDc0ZDU4YjIzNDE0ODE4YWRkZWJjOTQwYjc4MDU2NiIsInVzZXJfaWQiOiI3In0.0ushTNAz5YSjnYnPazfIL1sWHRVJm-ZSqfknnDkRUYQ','2025-11-13 05:43:52.059880','2025-11-20 05:43:52.000000',7,'7d74d58b23414818addebc940b780566'),
(21,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYxNzcxOSwiaWF0IjoxNzYzMDEyOTE5LCJqdGkiOiJmY2MxZDlmODZlZjU0M2IwYTRmNThmNDJlMWRjMjAxNyIsInVzZXJfaWQiOiI2In0.VHG4qkuGdyP5pcK5CZOvDChULHFVJKNuynj_c6IdH8s','2025-11-13 05:48:39.438670','2025-11-20 05:48:39.000000',6,'fcc1d9f86ef543b0a4f58f42e1dc2017'),
(22,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYyMDg3OSwiaWF0IjoxNzYzMDE2MDc5LCJqdGkiOiI3NzY0OGQxZTA5ZDI0YjliOWUwNDE0MjU3YTcwMDE3NyIsInVzZXJfaWQiOiI0In0.sNIf-znk2YQJTHz2sDZbyiNXV9dniceFzgc0w7MPPc4','2025-11-13 06:41:19.993008','2025-11-20 06:41:19.000000',4,'77648d1e09d24b9b9e0414257a700177'),
(23,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYyMzUyOSwiaWF0IjoxNzYzMDE4NzI5LCJqdGkiOiJhYjhjMzY1YWI1ZTE0NGVkYjg3NzM4OTIzMzMzMjU2ZSIsInVzZXJfaWQiOiI4In0.t1sgTaUwVhCv2lI13m9DVQl0CfIk3tQvtDWZg0vCmb0','2025-11-13 07:25:29.885435','2025-11-20 07:25:29.000000',8,'ab8c365ab5e144edb87738923333256e'),
(24,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYyMzUzNiwiaWF0IjoxNzYzMDE4NzM2LCJqdGkiOiJiYTliMDg0MzZlNzk0ZTdhOWMwYTM2MGQ4NzNkZGZjYyIsInVzZXJfaWQiOiI4In0.9YlxxBRtv5ISxNl5ZkKtMfT-heuwEz6WhPn772EDcFo','2025-11-13 07:25:36.402723','2025-11-20 07:25:36.000000',8,'ba9b08436e794e7a9c0a360d873ddfcc'),
(25,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYyNTExMSwiaWF0IjoxNzYzMDIwMzExLCJqdGkiOiI1ZTcwNTIzZDBkMzY0MWMwOWIxN2MwNTU4YzMyZGFjMiIsInVzZXJfaWQiOiI5In0.8AaF8JBWljbzsS08J_sDhofKWAIKNd25orDbSweCj6Y','2025-11-13 07:51:51.032291','2025-11-20 07:51:51.000000',9,'5e70523d0d3641c09b17c0558c32dac2'),
(26,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYyNTE2NCwiaWF0IjoxNzYzMDIwMzY0LCJqdGkiOiI1OWIyNzgzMzFkNWU0MTg3YTJjYTk5NTZhMjMzMzkwNyIsInVzZXJfaWQiOiI4In0.gU8f4mnBvyaoYAgYQX7AGqg8jTYpCJt4tIK7BZcBk-k','2025-11-13 07:52:44.140427','2025-11-20 07:52:44.000000',8,'59b278331d5e4187a2ca9956a2333907'),
(27,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYyNTMzNCwiaWF0IjoxNzYzMDIwNTM0LCJqdGkiOiJhODdjNWJhOTkwMmE0ODEwYThmNDVlOWRhNTZlY2RkOSIsInVzZXJfaWQiOiI4In0.A9jPiHMH3ryzaFsx8ZyNsvE-WLhy3s2tQp70dY09KPw','2025-11-13 07:55:34.602869','2025-11-20 07:55:34.000000',8,'a87c5ba9902a4810a8f45e9da56ecdd9'),
(28,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYyNTQyNSwiaWF0IjoxNzYzMDIwNjI1LCJqdGkiOiI2NTg0OTAzMmY3Mjc0MGI5YWMwZWZkOTc2MzI5MzI5ZCIsInVzZXJfaWQiOiIyIn0.C1OmR29ey5fbypM7rg35goAWJGHOlGW0BczeRa-pZsw','2025-11-13 07:57:05.004694','2025-11-20 07:57:05.000000',2,'65849032f72740b9ac0efd976329329d'),
(29,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYyNTQzMywiaWF0IjoxNzYzMDIwNjMzLCJqdGkiOiJkMDBlZWJjMTk0Njg0NDk3ODIxNThhYWI1MDVlNmViNCIsInVzZXJfaWQiOiIyIn0.Mr4hxJjQnCRnas8P9KiLr4uwaS3VSoIq_g_V1gwwM0c','2025-11-13 07:57:13.405032','2025-11-20 07:57:13.000000',2,'d00eebc19468449782158aab505e6eb4'),
(30,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYyNjc4NCwiaWF0IjoxNzYzMDIxOTg0LCJqdGkiOiJlMmJkNmMxYjFiOWU0MWRkOTEzN2NkYjEyNTAwZjViNiIsInVzZXJfaWQiOiI4In0.ppmSIyp410sl-Y9Pfgvxt1kgM4BaKqjXur362c6Byx4','2025-11-13 08:19:44.169534','2025-11-20 08:19:44.000000',8,'e2bd6c1b1b9e41dd9137cdb12500f5b6'),
(31,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYzMTQ1MiwiaWF0IjoxNzYzMDI2NjUyLCJqdGkiOiJmZWQ5MjcxOTgwN2Q0NzcxYTc2MWM3YTVhODk4NTBlNiIsInVzZXJfaWQiOiIxMCJ9.COCS4_VTnWbL76Pln0OPyEbbbqSZalELLMBN4bJjREE','2025-11-13 09:37:32.075236','2025-11-20 09:37:32.000000',NULL,'fed92719807d4771a761c7a5a89850e6'),
(32,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYzMTQ2NiwiaWF0IjoxNzYzMDI2NjY2LCJqdGkiOiI5ZDgxZTY1ODNlNWQ0NzExOWMyOWVkNjFjOWFiYTYzNiIsInVzZXJfaWQiOiIxMCJ9.jOGB_hYSSPvFq8DVCo4x3VLeDu0fqYHGGwQb_vBChEo','2025-11-13 09:37:46.079877','2025-11-20 09:37:46.000000',NULL,'9d81e6583e5d47119c29ed61c9aba636'),
(33,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYzMzE3MiwiaWF0IjoxNzYzMDI4MzcyLCJqdGkiOiIwM2I5MWRlOGRiYzg0NzZmODQ1ZTdiNjRlNmI2ODQyNCIsInVzZXJfaWQiOiI4In0.gB7EYX2VngX6ETFBcdl2AD6sfcpFUse-ccTJOYuPyBE','2025-11-13 10:06:12.223252','2025-11-20 10:06:12.000000',8,'03b91de8dbc8476f845e7b64e6b68424'),
(34,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYzNDQxOSwiaWF0IjoxNzYzMDI5NjE5LCJqdGkiOiI3MzhmZThlYTY2ODk0MzNmYjgxNzZhYjZjYzk3MDY5NSIsInVzZXJfaWQiOiIyIn0.D9esmnjgNSWqIXoXDaDQ_OjWjpGRWez7-Yjb_vF6VZc','2025-11-13 10:26:59.290743','2025-11-20 10:26:59.000000',2,'738fe8ea6689433fb8176ab6cc970695'),
(35,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYzNjEzNywiaWF0IjoxNzYzMDMxMzM3LCJqdGkiOiI3YWUwNzQyOTk0NDc0MGFkYWVkZTU4MjQ3ODQxMzJlZCIsInVzZXJfaWQiOiI0In0.4cROhVutZQTg-Sq2_f1u8_1JTxSGAd1MV_Z9_l0E9pE','2025-11-13 10:55:37.129554','2025-11-20 10:55:37.000000',4,'7ae07429944740adaede5824784132ed'),
(36,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYzNjMzMCwiaWF0IjoxNzYzMDMxNTMwLCJqdGkiOiJkNmE1N2JjY2MyZmQ0OGNhYTkzMmFhMDAyNTk3OTZjMiIsInVzZXJfaWQiOiI1In0.vASNxXkDesr4MnX-3f96Y7AtameOE1y7L-0W8eCu2L0','2025-11-13 10:58:50.122597','2025-11-20 10:58:50.000000',NULL,'d6a57bccc2fd48caa932aa00259796c2'),
(37,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzYzNzQ5MywiaWF0IjoxNzYzMDMyNjkzLCJqdGkiOiIyNDI0NzkyOTVlMDc0NWVjOGQzNzNhNTliZjRmMTdjYSIsInVzZXJfaWQiOiIyIn0.SV0GxwNhMOeo5ywZCW24cEbQ6qS29PD2MhCdylokw1c','2025-11-13 11:18:13.159579','2025-11-20 11:18:13.000000',2,'242479295e0745ec8d373a59bf4f17ca'),
(38,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzY0NTg1OCwiaWF0IjoxNzYzMDQxMDU4LCJqdGkiOiI3ZGYwMTgzOTMyODM0MjA0YWU3NGIxMTBiODVjYmYxNCIsInVzZXJfaWQiOiI1In0.mUC2Qolqlne6E74aSTL5vREMdzaRaXvmxAM1cYJB99s','2025-11-13 13:37:38.816630','2025-11-20 13:37:38.000000',NULL,'7df0183932834204ae74b110b85cbf14'),
(39,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzY0NTg4OSwiaWF0IjoxNzYzMDQxMDg5LCJqdGkiOiI1NDlmOGNlZDk2ZGM0MjZmOGE4MzdlZTcyYjA5NjIwOCIsInVzZXJfaWQiOiI0In0.6e_gn2IKNCQBCmJbPFNtZ6crY_LXikGThFXk3Ug4Hfo','2025-11-13 13:38:09.120668','2025-11-20 13:38:09.000000',4,'549f8ced96dc426f8a837ee72b096208'),
(40,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzY0NTk1NSwiaWF0IjoxNzYzMDQxMTU1LCJqdGkiOiIzMWIxMDgzZmEwODA0YjFjODA4NTM3MzVjMmRlNTZmZCIsInVzZXJfaWQiOiI0In0.qg7tKCWNYkuSog_UGrltHwaMH3U7pbQDmQkTmN1lPuw','2025-11-13 13:39:15.376298','2025-11-20 13:39:15.000000',4,'31b1083fa0804b1c80853735c2de56fd'),
(41,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzY0NjAzMiwiaWF0IjoxNzYzMDQxMjMyLCJqdGkiOiI1MWI5MDA1ODIwMzE0OGI1ODExNTZhMjk4ZGVhYTBjOSIsInVzZXJfaWQiOiI1In0.kJQ13jiZIg-z3IEjWrcyD7De943VCflBfQZ122Jx4UY','2025-11-13 13:40:32.990734','2025-11-20 13:40:32.000000',NULL,'51b90058203148b581156a298deaa0c9'),
(42,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzY0Njc5NiwiaWF0IjoxNzYzMDQxOTk2LCJqdGkiOiJhZTgwNzVlZDE4YjY0MzEwOGZhNmVhMDlkYTkwZTFjMCIsInVzZXJfaWQiOiIxMCJ9.KXw4bTet3h2wwEc8U8Zb5pZ8liYIJNxPaCkmI2AboI8','2025-11-13 13:53:16.893433','2025-11-20 13:53:16.000000',NULL,'ae8075ed18b643108fa6ea09da90e1c0'),
(43,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzY4ODE4NiwiaWF0IjoxNzYzMDgzMzg2LCJqdGkiOiIyN2M2MjljNjU4ZWM0OTE3OGY3NmQwYTU3YzgzOGM3MyIsInVzZXJfaWQiOiI1In0._0140waZTdr8D0diBEx5W4_gXPg6xcEL7312wVwMVC8','2025-11-14 01:23:06.470150','2025-11-21 01:23:06.000000',NULL,'27c629c658ec49178f76d0a57c838c73'),
(44,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzY4ODY5NiwiaWF0IjoxNzYzMDgzODk2LCJqdGkiOiJkZWNhZjc0YTc2YjQ0M2M3OWQxZWU3YjhhNmIwNjQ1NCIsInVzZXJfaWQiOiI0In0.BE8_1LtNUW5UDkKJQFI2AP1qSYOhzsIUruaXD9c42HA','2025-11-14 01:31:36.948154','2025-11-21 01:31:36.000000',4,'decaf74a76b443c79d1ee7b8a6b06454'),
(45,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzY4ODk4MSwiaWF0IjoxNzYzMDg0MTgxLCJqdGkiOiI0MzlhZjk3ZmZiMmQ0YjVlYWE5NjRlOWM2NjQ0ZTE0ZiIsInVzZXJfaWQiOiI0In0.vKaSe-O1LcW0p9kbHKCYrezsHuJd931jCWeGg6z6RAM','2025-11-14 01:36:21.799520','2025-11-21 01:36:21.000000',4,'439af97ffb2d4b5eaa964e9c6644e14f'),
(46,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzY4OTAwOCwiaWF0IjoxNzYzMDg0MjA4LCJqdGkiOiIzYzM3ZTFkNjNlMTE0NWViODcxZTFhYTc1OTUyNzVmZiIsInVzZXJfaWQiOiI0In0.KWy-amoqZ4w11yd5Z-aOaIXdAHv47JHwhf7NIJmgN1M','2025-11-14 01:36:48.069205','2025-11-21 01:36:48.000000',4,'3c37e1d63e1145eb871e1aa7595275ff'),
(47,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzY4OTA5NiwiaWF0IjoxNzYzMDg0Mjk2LCJqdGkiOiI3Zjk0MGFiNmZhMDY0NTU5OGQyM2RlZTI0ODgyNTU2NyIsInVzZXJfaWQiOiI1In0.4hPmKNEcn5QDta38gJ5_GMYhcMkZHenLjB7hlsnWn2c','2025-11-14 01:38:16.759907','2025-11-21 01:38:16.000000',NULL,'7f940ab6fa0645598d23dee248825567'),
(48,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzY5MTY1MiwiaWF0IjoxNzYzMDg2ODUyLCJqdGkiOiI5YThkNmI2YTFhMjA0NDUxOGYzYzE3YmFkZDYyM2UyMyIsInVzZXJfaWQiOiI0In0._Qbl-F8yICSIEdBvYxPp7uX9E_JiKSWsBf5BET91KY4','2025-11-14 02:20:52.094288','2025-11-21 02:20:52.000000',4,'9a8d6b6a1a2044518f3c17badd623e23'),
(49,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzcwMDk0MCwiaWF0IjoxNzYzMDk2MTQwLCJqdGkiOiJmMzdhMWI2MDRmZGY0ZTBhOWJlYWEyMDY5NDQ2NjJiYSIsInVzZXJfaWQiOiI4In0.8zxKxZaHuCQ8ZRnGkc4xkppChsJTKqrffoP1qZpq1PY','2025-11-14 04:55:40.471881','2025-11-21 04:55:40.000000',8,'f37a1b604fdf4e0a9beaa206944662ba'),
(50,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzcwMTEwNiwiaWF0IjoxNzYzMDk2MzA2LCJqdGkiOiJhMmZiYTM1ZTYyNzE0NmUyYTdiZTljNjMzMTY2NmJkMyIsInVzZXJfaWQiOiI1In0.KFvegOcNud8BF_rnoGC61TH6o0i_t4U63IpkB08wUfs','2025-11-14 04:58:26.292848','2025-11-21 04:58:26.000000',NULL,'a2fba35e627146e2a7be9c6331666bd3'),
(51,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzcwMTY3NCwiaWF0IjoxNzYzMDk2ODc0LCJqdGkiOiJjMDMyMDJiYTgzZGU0MDFjYjYxNjM5NDM1Y2MzM2Q2OCIsInVzZXJfaWQiOiI4In0.mOdw-Ny930cig7Gdz3YOd7ZYmrwsz7rACNtNjo04UT4','2025-11-14 05:07:54.995388','2025-11-21 05:07:54.000000',8,'c03202ba83de401cb61639435cc33d68'),
(52,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzcwNDk1MywiaWF0IjoxNzYzMTAwMTUzLCJqdGkiOiI0Yjc0NWIxNmVmZmQ0ZWExYjBmOTA5MTJmMTk4ZjNhNSIsInVzZXJfaWQiOiI4In0.9RoTVwmP2Xci8j9HG6mD2OrA7trYyQw9xV-mKdiAx2M','2025-11-14 06:02:33.549358','2025-11-21 06:02:33.000000',8,'4b745b16effd4ea1b0f90912f198f3a5'),
(53,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzcwNzQyNiwiaWF0IjoxNzYzMTAyNjI2LCJqdGkiOiI0MGMzNmU0ZjIxNDk0NDZmYjZiYWM2MzcxYjFiMzk4NCIsInVzZXJfaWQiOiIxMCJ9.uyE8idjQ5sDbYBpaBbUnu3XhiXG6RkkfJL9odr8xheQ','2025-11-14 06:43:46.937438','2025-11-21 06:43:46.000000',NULL,'40c36e4f2149446fb6bac6371b1b3984'),
(54,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzcyMjE1MCwiaWF0IjoxNzYzMTE3MzUwLCJqdGkiOiJiZTk1NmYyZTIwZTg0ZDkzOGJhYThjZWI4MDk1NGJmNSIsInVzZXJfaWQiOiI0In0.y5PP_qghahFgh6GznHB5N3q6kiLW-KSaTEkERf2iZpM','2025-11-14 10:49:10.316273','2025-11-21 10:49:10.000000',4,'be956f2e20e84d938baa8ceb80954bf5'),
(55,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzcyNDMwNywiaWF0IjoxNzYzMTE5NTA3LCJqdGkiOiI3MzI3OTg1MGU1NDA0ZjViOTcwYjk1MTkxY2YzYzBhMiIsInVzZXJfaWQiOiI0In0.lF7LQtBoiQWXZ8lB8hhvFvMf7ihE8TqDfPjGFO6RhdY','2025-11-14 11:25:07.759441','2025-11-21 11:25:07.000000',4,'73279850e5404f5b970b95191cf3c0a2'),
(56,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzcyNDM4MSwiaWF0IjoxNzYzMTE5NTgxLCJqdGkiOiJhNWM2ZWQ0ZmZiNDA0ZWM1ODkyMjE3OWFjZGY3NmE0NSIsInVzZXJfaWQiOiI1In0.tFVL_39dmwWjuntX4HTkYFuVXFU31ZdpTvuagLuGpEs','2025-11-14 11:26:21.364916','2025-11-21 11:26:21.000000',NULL,'a5c6ed4ffb404ec58922179acdf76a45'),
(57,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzcyNDQzOSwiaWF0IjoxNzYzMTE5NjM5LCJqdGkiOiIxMGI2NjU2MzFmMDE0ZGY4OTJiNjMyNmZhZDAxMDA0MCIsInVzZXJfaWQiOiI0In0.XIU_NQwh2P_Rc68hQXaophvf6Tst5w75wD1ICOBtLEA','2025-11-14 11:27:19.846117','2025-11-21 11:27:19.000000',4,'10b665631f014df892b6326fad010040'),
(58,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzcyODAyMSwiaWF0IjoxNzYzMTIzMjIxLCJqdGkiOiIxNTYwOTBmMzJmYmE0M2RjODdhYjEyOTBhNDFjN2E2NCIsInVzZXJfaWQiOiI1In0.Qe_mF5DVGmfSGoDep-ACrdRDsqCvDfMp_NMCU9h5X6s','2025-11-14 12:27:01.914339','2025-11-21 12:27:01.000000',NULL,'156090f32fba43dc87ab1290a41c7a64'),
(59,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzcyOTUxMSwiaWF0IjoxNzYzMTI0NzExLCJqdGkiOiI1M2Q5NmM4YTczY2U0Njk1YWFiODBhZWMxMDgwMDhjMyIsInVzZXJfaWQiOiI0In0.2O7ULfcv-mUHpoJ0LK236kRDoUzdaUUhgJOqQEWcAYQ','2025-11-14 12:51:51.256442','2025-11-21 12:51:51.000000',4,'53d96c8a73ce4695aab80aec108008c3'),
(60,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzczNTc0MywiaWF0IjoxNzYzMTMwOTQzLCJqdGkiOiJlNWU3MGM5YWRhZDc0NDNhYTlmNTdjMTdhY2JkYTc3OCIsInVzZXJfaWQiOiI0In0.VFGma6fihD-0f-W_i8L6zRPkr9YdYBs0-E_I_wh4dec','2025-11-14 14:35:43.247872','2025-11-21 14:35:43.000000',4,'e5e70c9adad7443aa9f57c17acbda778'),
(61,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzczNTgwOCwiaWF0IjoxNzYzMTMxMDA4LCJqdGkiOiIxMTQ1ZjAxYTViY2E0NjlkYjZmNmUzMjgxMzBiYjUxZiIsInVzZXJfaWQiOiI0In0.pjSsRZ3D7PK8bgI8V8FegSSHoKT3bq50EL4qHCHkFeo','2025-11-14 14:36:48.076552','2025-11-21 14:36:48.000000',4,'1145f01a5bca469db6f6e328130bb51f'),
(62,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc3NTI2OCwiaWF0IjoxNzYzMTcwNDY4LCJqdGkiOiIzMDQ2MmNmZWYyNmM0MzViODc3YmIxNjBhMDAzNmY2NSIsInVzZXJfaWQiOiI0In0.Vpzk9qAWHTwIaWFt-HnEbKN9PVLaNdCe5EPNwX3b0ro','2025-11-15 01:34:28.404415','2025-11-22 01:34:28.000000',4,'30462cfef26c435b877bb160a0036f65'),
(63,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc3NTQ5NSwiaWF0IjoxNzYzMTcwNjk1LCJqdGkiOiJiZTViMzFiODczYzc0Njk4YThkMGI2MzQ1ZGNmNzliMyIsInVzZXJfaWQiOiI1In0.3v1GWCQbZAPo5AbcARsqSUj5vdjPZye6LHNhpKdREBE','2025-11-15 01:38:15.427837','2025-11-22 01:38:15.000000',NULL,'be5b31b873c74698a8d0b6345dcf79b3'),
(64,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc4MTEyMSwiaWF0IjoxNzYzMTc2MzIxLCJqdGkiOiIyMjc4ZGY0ZWJjYTY0ZjhlODAxZWQxYzQ4MTc4MjZlMCIsInVzZXJfaWQiOiI0In0.yMDUGN5kIfv3QDJngCBZQXHK2-vmTbGo25KN5Q6iO-o','2025-11-15 03:12:01.022242','2025-11-22 03:12:01.000000',4,'2278df4ebca64f8e801ed1c4817826e0'),
(65,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc4MTE1NCwiaWF0IjoxNzYzMTc2MzU0LCJqdGkiOiIyZTU2NGRiZGYzMmY0YTgzOTFiMTBiMTQwODNjYzJlOSIsInVzZXJfaWQiOiI1In0.nJZXH02LwpqnBWq1qoZi2Uimp02Kjf2LSSeBLk_sGig','2025-11-15 03:12:34.437927','2025-11-22 03:12:34.000000',NULL,'2e564dbdf32f4a8391b10b14083cc2e9'),
(66,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc4NjgyOSwiaWF0IjoxNzYzMTgyMDI5LCJqdGkiOiJjNWQ2YTExMTI0YzU0ZTU4YTlmMGQyNzFiYTljYWY4YiIsInVzZXJfaWQiOiI1In0.OO2POrlW4sYgYaQhDFErzHQKtKnhP6KO8gkQeb1K0QM','2025-11-15 04:47:09.568151','2025-11-22 04:47:09.000000',NULL,'c5d6a11124c54e58a9f0d271ba9caf8b'),
(67,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc4NzIxNSwiaWF0IjoxNzYzMTgyNDE1LCJqdGkiOiIzMTY1OTAyNmY2YmY0NTg3ODY0YmRjZDIzMmI3ZjAxOCIsInVzZXJfaWQiOiI0In0.PnAzY_CBz3ckND31bMXSqXXih3bKS_MVeGsyacCh1uI','2025-11-15 04:53:35.093308','2025-11-22 04:53:35.000000',4,'31659026f6bf4587864bdcd232b7f018'),
(68,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc4NzQyNywiaWF0IjoxNzYzMTgyNjI3LCJqdGkiOiI2YmU3NmMwY2E0OGI0YWZmODY4ZjNiYTBkZGY0ODRlMyIsInVzZXJfaWQiOiIxMSJ9.jSElbMxJNobpCvKQm4jkt3q9ifZEDslMDebroMQADd4','2025-11-15 04:57:07.218686','2025-11-22 04:57:07.000000',NULL,'6be76c0ca48b4aff868f3ba0ddf484e3'),
(69,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc4NzUzNiwiaWF0IjoxNzYzMTgyNzM2LCJqdGkiOiIyNjVhZmQ5OTY3OGU0ZmVmOGI4YzE3MmVmNTE4ZjNmMiIsInVzZXJfaWQiOiI0In0.QkUMUc79fv5WXl1-Ylg37WYAn_vXyCoszV0gg9smKGk','2025-11-15 04:58:56.439239','2025-11-22 04:58:56.000000',4,'265afd99678e4fef8b8c172ef518f3f2'),
(70,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc4NzYwOCwiaWF0IjoxNzYzMTgyODA4LCJqdGkiOiI0ZjAwODI4MDVlNjc0YzlhOGI2NzZjOTE0Yzc4ZTI0YSIsInVzZXJfaWQiOiI0In0.zOHVcg4Y9fI-z7ZDYJ2P12eB1HbCq6yywTDhiyxP64M','2025-11-15 05:00:08.922612','2025-11-22 05:00:08.000000',4,'4f0082805e674c9a8b676c914c78e24a'),
(71,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc4Nzc0NiwiaWF0IjoxNzYzMTgyOTQ2LCJqdGkiOiI0YzcyMGExNzNmM2M0ZTM5YWQ0MTc1OWRkZjkyOGQ5NSIsInVzZXJfaWQiOiI0In0.wXkv5pfgYopfLZvtMXFt99yHq9dPiNHeFquk1kfxKX4','2025-11-15 05:02:26.982721','2025-11-22 05:02:26.000000',4,'4c720a173f3c4e39ad41759ddf928d95'),
(72,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc4Nzg0NywiaWF0IjoxNzYzMTgzMDQ3LCJqdGkiOiIwN2Y0YTNkYzc0YzE0N2UxYjVlNmE5NzRkOWE4MjA2YyIsInVzZXJfaWQiOiIxMSJ9.g3NQArD-ZE9zF73vSqSEpbPY7P08Vy9-VrX5mI7doAs','2025-11-15 05:04:07.060100','2025-11-22 05:04:07.000000',NULL,'07f4a3dc74c147e1b5e6a974d9a8206c'),
(73,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc4NzkxMSwiaWF0IjoxNzYzMTgzMTExLCJqdGkiOiI2ZDU4ZWM5M2NiYWY0ZWZkODhhODQxN2VlMTkwNDBjMSIsInVzZXJfaWQiOiIxMSJ9.070y2y245QIqoU7vBv9CJZEjlnOxs3F5O6teETHrc-Q','2025-11-15 05:05:11.604355','2025-11-22 05:05:11.000000',NULL,'6d58ec93cbaf4efd88a8417ee19040c1'),
(74,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc4OTE0MywiaWF0IjoxNzYzMTg0MzQzLCJqdGkiOiI2MjYxZTEzZDdiMDc0OGM1OGY0NzY5MTllNDQxYzZkNCIsInVzZXJfaWQiOiIxMSJ9.6pg26QkU-ult8fyqO6E7LyNgThCh77alVmih4vgH1-8','2025-11-15 05:25:43.542250','2025-11-22 05:25:43.000000',NULL,'6261e13d7b0748c58f476919e441c6d4'),
(75,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc5MDkxNiwiaWF0IjoxNzYzMTg2MTE2LCJqdGkiOiJiMWRlMTg0YTI4M2Q0YmU2YjY5NjkxYzUwOTQyOTgxYyIsInVzZXJfaWQiOiI1In0.AovJQi6lFu45J1AlsH18qsoGZhcgHMGw62k-v8IkbXk','2025-11-15 05:55:16.202728','2025-11-22 05:55:16.000000',NULL,'b1de184a283d4be6b69691c50942981c'),
(76,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc5MDk4MywiaWF0IjoxNzYzMTg2MTgzLCJqdGkiOiI1OGY5Y2ZiYmFlMmM0MzIxODMyZTc4NjkyYWNkZDJkZCIsInVzZXJfaWQiOiI1In0.qluBUSRcQJPNsJSc1_ozhCsPZm2S2Y0jrKVyh3SdM88','2025-11-15 05:56:23.890060','2025-11-22 05:56:23.000000',NULL,'58f9cfbbae2c4321832e78692acdd2dd'),
(77,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc5MTAwNywiaWF0IjoxNzYzMTg2MjA3LCJqdGkiOiI4NTA2NWRkNTFlN2E0MDk2YmE4ZDA1YmY5YjIzZGZmNCIsInVzZXJfaWQiOiI1In0.kBanH28VWTujPL_Rih1KEv77AuHf4C7kUNYshvKy4FQ','2025-11-15 05:56:47.092381','2025-11-22 05:56:47.000000',NULL,'85065dd51e7a4096ba8d05bf9b23dff4'),
(78,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc5MTA3NCwiaWF0IjoxNzYzMTg2Mjc0LCJqdGkiOiIxYTAxNTAxMzAwNWE0MGJlOGM2MDdhYjUyMjZiZmE1MiIsInVzZXJfaWQiOiIxMCJ9.m4T31K4DBcCpuqogOT-Jy3J2w3SvvIP2kthrWXxw6t8','2025-11-15 05:57:54.133978','2025-11-22 05:57:54.000000',NULL,'1a015013005a40be8c607ab5226bfa52'),
(79,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc5MTM4OCwiaWF0IjoxNzYzMTg2NTg4LCJqdGkiOiJmZDQwMjJjNzA4ODQ0Y2U5YjYxYjIwNzdhOTJhOTg0OSIsInVzZXJfaWQiOiI0In0.IkQLHDbahYuvLbvMfzd6L8OzWhKggm65ofluTLXtqd8','2025-11-15 06:03:08.933309','2025-11-22 06:03:08.000000',4,'fd4022c708844ce9b61b2077a92a9849'),
(80,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc5MTYwMywiaWF0IjoxNzYzMTg2ODAzLCJqdGkiOiJmYmM5NGI4MjUxYzM0NDA5YThjNWE4YWZjYmZlNzZhMyIsInVzZXJfaWQiOiIxMCJ9.QidX3H8uUHDXcG4EfZJgFtQpbHRRGlNxlkpfqP7koMI','2025-11-15 06:06:43.871338','2025-11-22 06:06:43.000000',NULL,'fbc94b8251c34409a8c5a8afcbfe76a3'),
(81,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc5MjAzMywiaWF0IjoxNzYzMTg3MjMzLCJqdGkiOiI3MWM0NzZkYmU2MWE0NzFkOTg1ZjUyZjRkZjIyZWU0OSIsInVzZXJfaWQiOiIyIn0.NKy6kvPXTeyhHzQCZSJSEFQvlrGMuEjJH5f-nKYX-_A','2025-11-15 06:13:53.855173','2025-11-22 06:13:53.000000',2,'71c476dbe61a471d985f52f4df22ee49'),
(82,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc5Nzk1MiwiaWF0IjoxNzYzMTkzMTUyLCJqdGkiOiJmMTg3ZGY4NzYxNzg0MzdlYjZiMTk1ZDJjMjM2ZjgxNyIsInVzZXJfaWQiOiI1In0.yTQ2SJBDPpIGwuE8oaryPAvujWJa1klFJcRytwOx78Q','2025-11-15 07:52:32.470119','2025-11-22 07:52:32.000000',NULL,'f187df876178437eb6b195d2c236f817'),
(83,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc5Nzk2OCwiaWF0IjoxNzYzMTkzMTY4LCJqdGkiOiJiMGNiYmRiNjMyY2Q0ZDBlOGU5MDNlNDJlNjkxZDA0MiIsInVzZXJfaWQiOiI0In0.kKERJtIa6fJMTCBONFGLjIXVZ8IQCzZPOJcKal1FOXk','2025-11-15 07:52:48.402907','2025-11-22 07:52:48.000000',4,'b0cbbdb632cd4d0e8e903e42e691d042'),
(84,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc5OTA4MCwiaWF0IjoxNzYzMTk0MjgwLCJqdGkiOiJkMWJmNjg0YWJmZDk0YTE1ODk1YmZhYjhkNmVhYmNmOSIsInVzZXJfaWQiOiI0In0.b_pNt7uGvC6cuCmuczN0W9qTW3a4HtOZ1eMng-yOHSo','2025-11-15 08:11:20.256746','2025-11-22 08:11:20.000000',4,'d1bf684abfd94a15895bfab8d6eabcf9'),
(85,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzc5OTEyMiwiaWF0IjoxNzYzMTk0MzIyLCJqdGkiOiIxMTE5NGJiNjlmOGQ0MWM2OGY5MmY2ZjU5NTY4YWM1YSIsInVzZXJfaWQiOiI1In0.ts-i5HjmgIM2zYGGg9wU2NtdWyLUyf_zk1Pkw2hCEt4','2025-11-15 08:12:02.006023','2025-11-22 08:12:02.000000',NULL,'11194bb69f8d41c68f92f6f59568ac5a'),
(86,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzgxMTczNiwiaWF0IjoxNzYzMjA2OTM2LCJqdGkiOiJiZjQ1NTNjYjY5NGM0ZWRmODQ3NjVjMjkzNzVlYTE2NyIsInVzZXJfaWQiOiI1In0.IDuosg62ubfIxraKX0ps9emBoJrjAGEytjy4_k6cUBk','2025-11-15 11:42:16.623677','2025-11-22 11:42:16.000000',NULL,'bf4553cb694c4edf84765c29375ea167'),
(87,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzgyMDUxNSwiaWF0IjoxNzYzMjE1NzE1LCJqdGkiOiIwNTI2MjE5NDhhNGY0YThjYjlkOThhOTUxMTgzODFiZiIsInVzZXJfaWQiOiI0In0.oHTX-wX8l0eXQiGzL5RbOdg1C8vHxF_zGNTv-vYKkNg','2025-11-15 14:08:35.878814','2025-11-22 14:08:35.000000',4,'052621948a4f4a8cb9d98a95118381bf'),
(88,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzgyMDYwOCwiaWF0IjoxNzYzMjE1ODA4LCJqdGkiOiI2MjVhODA1ZTkyMjc0ZjAxODBmMzA5YTQ1MjVmMjJiNSIsInVzZXJfaWQiOiI1In0._bAqXQSw0iAFvqC75zfnexx6F6BFV6JnncX1fPNSRug','2025-11-15 14:10:08.725012','2025-11-22 14:10:08.000000',NULL,'625a805e92274f0180f309a4525f22b5'),
(89,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzg1MzUwNSwiaWF0IjoxNzYzMjQ4NzA1LCJqdGkiOiJmMTVlM2JhY2NkMTI0ODkyYmU5Mzg0MGY0OThlZTcwMSIsInVzZXJfaWQiOiI1In0.0tp0kN3H8uOk39hYn3OS7hZwg9hrjWsPkcYtajcElyc','2025-11-15 23:18:25.552926','2025-11-22 23:18:25.000000',NULL,'f15e3baccd124892be93840f498ee701'),
(90,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzg2NjY3MiwiaWF0IjoxNzYzMjYxODcyLCJqdGkiOiI4ZDM0ZGM4ZTkyYmI0YjFmYjQyYzRhNTcyZmExNzNkZCIsInVzZXJfaWQiOiI1In0.CvXKX75942-W7LeMofeRlWLU_QhtitpWTr5Bzj85644','2025-11-16 02:57:52.090837','2025-11-23 02:57:52.000000',NULL,'8d34dc8e92bb4b1fb42c4a572fa173dd'),
(91,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzg2OTkzMywiaWF0IjoxNzYzMjY1MTMzLCJqdGkiOiJlOTMwNzJkNTAyZTQ0ODNiOGM1YTVjYjAzYjU4ODVlYiIsInVzZXJfaWQiOiIxMiJ9.I_2N2olpxI3SR--pr0sH_H61L5GXu5GZIK6v2JGBltU','2025-11-16 03:52:13.793455','2025-11-23 03:52:13.000000',12,'e93072d502e4483b8c5a5cb03b5885eb'),
(92,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzg2OTk2NiwiaWF0IjoxNzYzMjY1MTY2LCJqdGkiOiI2OWJhMWQxMzAwZWU0MDQyYjVlZTFiNmU0MGE0MTY2YyIsInVzZXJfaWQiOiIxMiJ9.1br1UgW0zTP-OFeNYlS1Wrjt7vrH88Yan3am-ilMB7M','2025-11-16 03:52:46.364635','2025-11-23 03:52:46.000000',12,'69ba1d1300ee4042b5ee1b6e40a4166c'),
(93,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzg3MDM5NSwiaWF0IjoxNzYzMjY1NTk1LCJqdGkiOiIxZmQwM2I5MzU5Mjc0NGRlOTE4MTU5MGE1NjAyYjg3MSIsInVzZXJfaWQiOiI0In0.tXwVjI5U1yP2gYuSM36Fv0x3ZuE-EpwuEzoSLM0rGiI','2025-11-16 03:59:55.737931','2025-11-23 03:59:55.000000',4,'1fd03b93592744de9181590a5602b871'),
(94,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzg3ODE1MCwiaWF0IjoxNzYzMjczMzUwLCJqdGkiOiJhYWRkMGJmY2IyZWE0YjI5YjE3YzM0ZmY3YzM2NTkxYSIsInVzZXJfaWQiOiIxMiJ9.5uCprg6zgSL_9SF9WZvqjEUV3yJCgiuldnBlx0RVF8w','2025-11-16 06:09:10.985265','2025-11-23 06:09:10.000000',12,'aadd0bfcb2ea4b29b17c34ff7c36591a'),
(95,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzg3ODE1NCwiaWF0IjoxNzYzMjczMzU0LCJqdGkiOiI3YTUzNWEyZTQ4NDU0ODExODI4ODYyNmQ5MjM4ZjBhNSIsInVzZXJfaWQiOiIxMiJ9.Ngcm7vzv4JDfvKCnfGbO8_AQGTTv0T5LU1X9kAg3CQc','2025-11-16 06:09:14.045722','2025-11-23 06:09:14.000000',12,'7a535a2e484548118288626d9238f0a5'),
(96,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzg3ODIyOCwiaWF0IjoxNzYzMjczNDI4LCJqdGkiOiJjZjIwNzZjOTcxZDk0ZjQ2YWJiMWNjZmQ0MjU0MmViYiIsInVzZXJfaWQiOiIxMiJ9.SzzsVVIf7D2SfLoBrxHqTZJjrEI6tyqHvdKFbtboAmw','2025-11-16 06:10:28.255367','2025-11-23 06:10:28.000000',12,'cf2076c971d94f46abb1ccfd42542ebb'),
(97,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzg3ODM4NywiaWF0IjoxNzYzMjczNTg3LCJqdGkiOiI1YzI0N2Y2ZDhlOGQ0YmRkYjk3M2NlNDU3N2Y4Y2ViOCIsInVzZXJfaWQiOiIxMCJ9.ZL_ZiBEYRvryC7ZG_OJ5prBN2tcsBrjr3KVg1nxCNSE','2025-11-16 06:13:07.920332','2025-11-23 06:13:07.000000',NULL,'5c247f6d8e8d4bddb973ce4577f8ceb8'),
(98,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzg4NjUwMywiaWF0IjoxNzYzMjgxNzAzLCJqdGkiOiJlZWJlN2MwZWU1NTQ0ZWVkYjA0MjBiZGEzZjU2N2I1MSIsInVzZXJfaWQiOiI1In0.1bFZzcYvFZti7l_2T-ph4wGqPoi7jBJzBjgNOsNxWdU','2025-11-16 08:28:23.651640','2025-11-23 08:28:23.000000',NULL,'eebe7c0ee5544eedb0420bda3f567b51'),
(99,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzg4NjU1MSwiaWF0IjoxNzYzMjgxNzUxLCJqdGkiOiJmZDEwY2ExYjQ1MWE0NmJkOTVhMzI1MmEzM2E3Y2E3MiIsInVzZXJfaWQiOiI0In0.zXT9LazJ8SKPKIy6PG0pH1Lsm8jOZ_TS5V4ballancA','2025-11-16 08:29:11.893307','2025-11-23 08:29:11.000000',4,'fd10ca1b451a46bd95a3252a33a7ca72'),
(100,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzg4NjU3OCwiaWF0IjoxNzYzMjgxNzc4LCJqdGkiOiJiNDRiNTJkMjUyMTI0MDdjOTY3ZTdmZmE1YmM1NDc1ZSIsInVzZXJfaWQiOiIxMiJ9.TZMdUHGU4LP6nzrK_D7ZpFj751c8ul5-fqAsuCIrMv0','2025-11-16 08:29:38.593589','2025-11-23 08:29:38.000000',12,'b44b52d25212407c967e7ffa5bc5475e'),
(101,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzg5MzAxNCwiaWF0IjoxNzYzMjg4MjE0LCJqdGkiOiI2YjBjNTdhZGYxNmU0MmYzODg2ZWVmM2YxZDAzM2Y0MSIsInVzZXJfaWQiOiI1In0.aoIHMgGvKYuA5oLh72E3tEdvfozThSedVjErHYZ94IU','2025-11-16 10:16:54.695272','2025-11-23 10:16:54.000000',NULL,'6b0c57adf16e42f3886eef3f1d033f41'),
(102,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzg5NDcwMiwiaWF0IjoxNzYzMjg5OTAyLCJqdGkiOiI4YzkyYzBhNTZlODM0ZTRhOGM4Y2E5YjExNTE4YjlmOCIsInVzZXJfaWQiOiI4In0.RoreEXJngE9Md_VBoc8EdDJUKXzNqegVvVyeShTgE6U','2025-11-16 10:45:02.692297','2025-11-23 10:45:02.000000',8,'8c92c0a56e834e4a8c8ca9b11518b9f8'),
(103,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzg5NjM0MiwiaWF0IjoxNzYzMjkxNTQyLCJqdGkiOiI4M2E5ZTU5MzhhM2Y0YzdkYWZjNDA1ZWRjYzUxZjgwYiIsInVzZXJfaWQiOiIzIn0._ZBNzDI0_lL8HhOcj7gSSu8yF-dPSvOUMwITxFcrFWw','2025-11-16 11:12:22.156379','2025-11-23 11:12:22.000000',NULL,'83a9e5938a3f4c7dafc405edcc51f80b'),
(104,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzg5NjM3NiwiaWF0IjoxNzYzMjkxNTc2LCJqdGkiOiJlOTJiNjgxNmYxNDg0ZTQ1OTJhNjkwMTM0YmU1OWY5YyIsInVzZXJfaWQiOiIyIn0.0KumGCJzqPt-K-CO51gNemivkYXzm4UhkYyIffTWLtQ','2025-11-16 11:12:56.832488','2025-11-23 11:12:56.000000',2,'e92b6816f1484e4592a690134be59f9c'),
(105,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzg5Nzc4NywiaWF0IjoxNzYzMjkyOTg3LCJqdGkiOiI0OWM2NDQyNTVjNjk0MGFlODBhZTQ4YmFlNWM1ZjFkOCIsInVzZXJfaWQiOiIyIn0.nzOsxSAKf7HOwLUtkzmahmTykruauTVAXmpm_nW0RYg','2025-11-16 11:36:27.349280','2025-11-23 11:36:27.000000',2,'49c644255c6940ae80ae48bae5c5f1d8'),
(106,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzkwMjM3MywiaWF0IjoxNzYzMjk3NTczLCJqdGkiOiJiNjYwN2YzYjY3ZjY0N2MxODA1ZmU0NzM3NDc5MjcxZSIsInVzZXJfaWQiOiI1In0.KR9uwWwwKg1fY5gV5S2as_lQVYAH6_oxoWnjZLZ_Jg8','2025-11-16 12:52:53.211360','2025-11-23 12:52:53.000000',NULL,'b6607f3b67f647c1805fe4737479271e'),
(107,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzkwMjQzMiwiaWF0IjoxNzYzMjk3NjMyLCJqdGkiOiJkNjBjNGM5OGIxNTk0OTAyYTEyMmMwOWI0NWU0YjIzZiIsInVzZXJfaWQiOiI0In0.2OHlR76iaYpoD3Iawcauh-_P7NqSIbsX9LPQuRMnNPw','2025-11-16 12:53:52.783947','2025-11-23 12:53:52.000000',4,'d60c4c98b1594902a122c09b45e4b23f'),
(108,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzkwMjY1NSwiaWF0IjoxNzYzMjk3ODU1LCJqdGkiOiJmZDVlNWU0MWZkMTI0Y2ZjOWViY2UwZTc5OTM2NjA0MyIsInVzZXJfaWQiOiI1In0.7YV_I_dZgzneOZ8avl0GQ8ohwprbVQ9cb6oYkg0smQo','2025-11-16 12:57:35.779131','2025-11-23 12:57:35.000000',NULL,'fd5e5e41fd124cfc9ebce0e799366043'),
(109,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzkwNzM1OCwiaWF0IjoxNzYzMzAyNTU4LCJqdGkiOiJiMDU4M2EyMTU4Y2U0YjhhYWEyMmYyZmIwMGI2Y2ZjZiIsInVzZXJfaWQiOiI1In0.yQ4gQtOEBkhoRPSAcDxDTG1q7qkK5XecVdvnDzdLbnA','2025-11-16 14:15:58.075513','2025-11-23 14:15:58.000000',NULL,'b0583a2158ce4b8aaa22f2fb00b6cfcf'),
(110,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzkwNzk4NCwiaWF0IjoxNzYzMzAzMTg0LCJqdGkiOiIyNTU1NzRmODhkZGQ0YzkxYWZiMDNiZDI2NzJkYjQzYSIsInVzZXJfaWQiOiI1In0.VsshnVM3gFHcJw4ZaHX3425ZW8c8fkaSJ9zDcqs1fo0','2025-11-16 14:26:24.084267','2025-11-23 14:26:24.000000',NULL,'255574f88ddd4c91afb03bd2672db43a'),
(111,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzkxMDE5OCwiaWF0IjoxNzYzMzA1Mzk4LCJqdGkiOiJjYWNkYzE0M2ZmMjI0MjFkOGM1NjZkMDgxNDJhY2Y5YiIsInVzZXJfaWQiOiI1In0.8_T8rCfUkMDvn0IuP2qBmInSPqUHcJbubJwF2JorR2A','2025-11-16 15:03:18.317514','2025-11-23 15:03:18.000000',NULL,'cacdc143ff22421d8c566d08142acf9b'),
(112,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzkxMjAyMSwiaWF0IjoxNzYzMzA3MjIxLCJqdGkiOiIzYzNmODAxNWM1YmQ0ZGVlYjZkNGY0YjA0OWU3N2NkMiIsInVzZXJfaWQiOiI1In0.DTYjUfYs0MhYznlBz4yvSVWfsyPpIexbjXklBM5pGzU','2025-11-16 15:33:41.828492','2025-11-23 15:33:41.000000',NULL,'3c3f8015c5bd4deeb6d4f4b049e77cd2'),
(113,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzkyMjkyNSwiaWF0IjoxNzYzMzE4MTI1LCJqdGkiOiIyYWYwM2E0NTEzNGQ0NTIxYWRiNDAzYjg1MzY5NzI1MyIsInVzZXJfaWQiOiI1In0.Sgflvwh3bOasgPAezoc2UwKTyjy-PVCdqtt_AF_LatA','2025-11-16 18:35:25.020041','2025-11-23 18:35:25.000000',NULL,'2af03a45134d4521adb403b853697253'),
(114,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzkyMzA2NiwiaWF0IjoxNzYzMzE4MjY2LCJqdGkiOiI3NTMwNGNlMWY0NmM0ZTBkYWQzMWZiMjA5OGIyZjcwMiIsInVzZXJfaWQiOiI0In0.iDdDlNu58NZJm_7IUF7D6jewqR9UBCTuU7NlyZs-ISk','2025-11-16 18:37:46.659063','2025-11-23 18:37:46.000000',4,'75304ce1f46c4e0dad31fb2098b2f702'),
(115,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzkyNDI4NSwiaWF0IjoxNzYzMzE5NDg1LCJqdGkiOiJlNDVjZTEyZGIzN2I0NGI4OTRjOGEzMDkyZWU2NjdhNiIsInVzZXJfaWQiOiI1In0.vC042zDnIiR8-4iBoegfcyQEPPoBxqm2vzXGoDU3IHA','2025-11-16 18:58:05.992721','2025-11-23 18:58:05.000000',NULL,'e45ce12db37b44b894c8a3092ee667a6'),
(116,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2MzkyNTU0MywiaWF0IjoxNzYzMzIwNzQzLCJqdGkiOiJiMmQ0MTRlM2FhMWY0NTM2ODhhOGE0MjdiZjkwM2QyNyIsInVzZXJfaWQiOiIxMCJ9.LHLey-p35nZf9_1-aaVkJx8XPkYpcdhhnoJH5Qf7djE','2025-11-16 19:19:03.205001','2025-11-23 19:19:03.000000',NULL,'b2d414e3aa1f453688a8a427bf903d27'),
(117,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk0NTM1OCwiaWF0IjoxNzYzMzQwNTU4LCJqdGkiOiIxMzBhZGI2MDU0OWM0MDRlYTM3ZjI0OTdmYjY0OThlNyIsInVzZXJfaWQiOiI1In0.w2NqWfrDzFtt4EES3FypLwpaVaiPHffZ7tDKkWkvQZk','2025-11-17 00:49:18.531968','2025-11-24 00:49:18.000000',NULL,'130adb60549c404ea37f2497fb6498e7'),
(118,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk0NjIxMSwiaWF0IjoxNzYzMzQxNDExLCJqdGkiOiI1NzgzMDFkM2RhOWE0MThiODU4OTZjMjJkOGRiZDU1MSIsInVzZXJfaWQiOiI1In0.YHTfYK9dR_bfoKaNhYrH5bw_CE3zGbqokGmqFJneOEY','2025-11-17 01:03:31.026510','2025-11-24 01:03:31.000000',NULL,'578301d3da9a418b85896c22d8dbd551'),
(119,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk0NjQxNywiaWF0IjoxNzYzMzQxNjE3LCJqdGkiOiJmNzA5ZDQ1YmMwYzM0YjVhOGIyNjcxNmRhZDI2ZTg5YiIsInVzZXJfaWQiOiIxMCJ9.nInEcJnb01ir269LEENqEJcv3Ubc4vqO_DJVneLJGMc','2025-11-17 01:06:57.993382','2025-11-24 01:06:57.000000',NULL,'f709d45bc0c34b5a8b26716dad26e89b'),
(120,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk0NjQ2NiwiaWF0IjoxNzYzMzQxNjY2LCJqdGkiOiI0YzUxNjZhODg2NjE0MGYyOGRmYTQyNjkzNGM4M2Y5OCIsInVzZXJfaWQiOiI0In0.k35pNR_dIOPsj0iIo7MXpoAeJrOtY1u-8AaZGa0M7QY','2025-11-17 01:07:46.799036','2025-11-24 01:07:46.000000',4,'4c5166a8866140f28dfa426934c83f98'),
(121,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk0NjUyNCwiaWF0IjoxNzYzMzQxNzI0LCJqdGkiOiI0MTU5YzMyYjU5Yzk0MWFkYjRkMmU2ZTI4M2Y3NTBmOSIsInVzZXJfaWQiOiI1In0.VCqXI-i1BNZed4wfDeK5iqb_UbjOVy5BEQh8VgKCiuU','2025-11-17 01:08:44.715010','2025-11-24 01:08:44.000000',NULL,'4159c32b59c941adb4d2e6e283f750f9'),
(122,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk0NjY0NiwiaWF0IjoxNzYzMzQxODQ2LCJqdGkiOiJjZjg5YjFhMjRhOTA0MWZmYTJjOGFlYjZjYzA2MjgzMSIsInVzZXJfaWQiOiI0In0.yhPBLdxYTiQw8XwZMpKCMg-jcSiBLK3PJMHNeRzUyVQ','2025-11-17 01:10:46.649290','2025-11-24 01:10:46.000000',4,'cf89b1a24a9041ffa2c8aeb6cc062831'),
(123,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk0Njg3NSwiaWF0IjoxNzYzMzQyMDc1LCJqdGkiOiI4ZWI2MTY2MTVkMjU0Njk5YmZjYjJmYTE3MWQ0MzRkZCIsInVzZXJfaWQiOiIxMyJ9.sgpVUzW7MkLWiLzlE7csIGnLnqvfpzlpAzH3KLzIMko','2025-11-17 01:14:35.838760','2025-11-24 01:14:35.000000',13,'8eb616615d254699bfcb2fa171d434dd'),
(124,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk0Njg4NCwiaWF0IjoxNzYzMzQyMDg0LCJqdGkiOiI5NjIzNzI3MzlmNzc0M2YwOTA2MTdlODIxYTUyNGFlNSIsInVzZXJfaWQiOiI0In0.UDB2veZR8_6D0ZEVrd9eNaSERrchiz8KZeJMahk1bfw','2025-11-17 01:14:44.297647','2025-11-24 01:14:44.000000',4,'962372739f7743f090617e821a524ae5'),
(125,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk0NjkzNSwiaWF0IjoxNzYzMzQyMTM1LCJqdGkiOiIyOGYyYmQ1YmFhNzE0MTMwOGJjNWVmYWIxNmEwODU3ZCIsInVzZXJfaWQiOiIxMyJ9.iso1Yu5QajyJKAxPwEX4oSFpAGyaT9tyYUOevH3asO4','2025-11-17 01:15:35.225948','2025-11-24 01:15:35.000000',13,'28f2bd5baa7141308bc5efab16a0857d'),
(126,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk0NzE3NSwiaWF0IjoxNzYzMzQyMzc1LCJqdGkiOiI1YWQ5YjhhOTdhOWI0NzhmYmZlNTk2ZDhhMGU5MWQ4ZSIsInVzZXJfaWQiOiIyIn0.sl5j9cRi_P8F1fABS3rDqKsd6Dhp7WM0NPt-K2_LryY','2025-11-17 01:19:35.407089','2025-11-24 01:19:35.000000',2,'5ad9b8a97a9b478fbfe596d8a0e91d8e'),
(127,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk0NzY2NywiaWF0IjoxNzYzMzQyODY3LCJqdGkiOiI4MjlhMDQ1OGZmODI0NTQ4YmFmZWY3NTNjNjJhMmI2YSIsInVzZXJfaWQiOiIzIn0.AfUEhpxED2PQkNGJx5IggK1VauYsfQh95q4KP8Xuri4','2025-11-17 01:27:47.349824','2025-11-24 01:27:47.000000',NULL,'829a0458ff824548bafef753c62a2b6a'),
(128,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk0ODE4NiwiaWF0IjoxNzYzMzQzMzg2LCJqdGkiOiI4ZmFjMjNlNzUxMjU0NzY3YTQ5NzAyNTBiYThjODAzNyIsInVzZXJfaWQiOiIyIn0.QKXli9298PyKMigxtIDtrr8ZK8unpfGoKh4iPrWz_9k','2025-11-17 01:36:26.509974','2025-11-24 01:36:26.000000',2,'8fac23e751254767a4970250ba8c8037'),
(129,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk0ODY1MSwiaWF0IjoxNzYzMzQzODUxLCJqdGkiOiIyYjZmMDhjMzdlYjQ0NmNkYmFjYzg2ZDAxMzg5MDYxMSIsInVzZXJfaWQiOiIyIn0.ic2umchocx-S0j665JBsNzxR60hCJm34wHniga8GHYY','2025-11-17 01:44:11.384375','2025-11-24 01:44:11.000000',2,'2b6f08c37eb446cdbacc86d013890611'),
(130,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk0ODY3OSwiaWF0IjoxNzYzMzQzODc5LCJqdGkiOiI0MDM2ZjZkM2RkZjk0MzFkYWE5OTQ1NGIyYWU2N2QxNSIsInVzZXJfaWQiOiIzIn0.mfrKBKc-JVobAvg02evtfM8Thg0oybr9jl93p0VGJBk','2025-11-17 01:44:39.891287','2025-11-24 01:44:39.000000',NULL,'4036f6d3ddf9431daa99454b2ae67d15'),
(131,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk0ODg1NiwiaWF0IjoxNzYzMzQ0MDU2LCJqdGkiOiIzYzYxY2I2MTliYzA0MmM1OGNhNmRiNTEyNzg4ZTM5NiIsInVzZXJfaWQiOiIyIn0.3P71X2tlGhGXnHkpStbtVlt6ay9PPj2KZImab-oUwmE','2025-11-17 01:47:36.140772','2025-11-24 01:47:36.000000',2,'3c61cb619bc042c58ca6db512788e396'),
(132,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk1MjQ3NiwiaWF0IjoxNzYzMzQ3Njc2LCJqdGkiOiI4NTU3YjVmMjhhODA0ZjQyYTU4MGU1MDg5MGY0ZTBiMSIsInVzZXJfaWQiOiIzIn0.pTk0UhL8YwUnZiPaTu6bdDPJYgPhfzXcPh8WDrnoE2Y','2025-11-17 02:47:56.588128','2025-11-24 02:47:56.000000',NULL,'8557b5f28a804f42a580e50890f4e0b1'),
(133,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk1MzIyNCwiaWF0IjoxNzYzMzQ4NDI0LCJqdGkiOiIyODdjM2I4YWRkYmY0YjkzOGU1MmRkOGZmM2U0MzNmMyIsInVzZXJfaWQiOiIxMCJ9.GqpQRABK1jikGMSCElFa0-iZ7CKR279WjthUp8Pe2eo','2025-11-17 03:00:24.395004','2025-11-24 03:00:24.000000',NULL,'287c3b8addbf4b938e52dd8ff3e433f3'),
(134,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk1NTA5MywiaWF0IjoxNzYzMzUwMjkzLCJqdGkiOiJjYTA0ZDM1NmE0ZDI0MTQ3YThkYWEzYjA2YmFkMWNkMiIsInVzZXJfaWQiOiIxMyJ9.TY4gLBh3wIryzIMicACmUw7zFVukfQbGwsjI5_okEMY','2025-11-17 03:31:33.232482','2025-11-24 03:31:33.000000',13,'ca04d356a4d24147a8daa3b06bad1cd2'),
(135,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk1NTY3MCwiaWF0IjoxNzYzMzUwODcwLCJqdGkiOiI4ODE1NWU2ZmVjMWQ0YmI5OWQyOGFjZjEwYmU5MTlhZSIsInVzZXJfaWQiOiI0In0.cx6tcd0MhucbxF8zNUR6-EJVcJCY07CNuF7O1rv9qyM','2025-11-17 03:41:10.059788','2025-11-24 03:41:10.000000',4,'88155e6fec1d4bb99d28acf10be919ae'),
(136,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk2MTA3OCwiaWF0IjoxNzYzMzU2Mjc4LCJqdGkiOiI4ZTFkNGZmY2VhNWM0YzM4OGQyOTVhOWZhYzgwMzNiNiIsInVzZXJfaWQiOiIxMyJ9.VAydK0aQLyw7ioOsnn97N2C3VmG_7o4iNZOk7h-GgUY','2025-11-17 05:11:18.296284','2025-11-24 05:11:18.000000',13,'8e1d4ffcea5c4c388d295a9fac8033b6'),
(137,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk2NjY0MywiaWF0IjoxNzYzMzYxODQzLCJqdGkiOiI3MjZmOGNjYmM4YTI0YzYyOTIzOTA1NzcyMDM2N2FjNyIsInVzZXJfaWQiOiIxMyJ9.WlD1NShu3p44fqq3JBxWGYANe-f5JsxAKlb6_ineosM','2025-11-17 06:44:03.699697','2025-11-24 06:44:03.000000',13,'726f8ccbc8a24c629239057720367ac7'),
(138,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk2OTg1MywiaWF0IjoxNzYzMzY1MDUzLCJqdGkiOiJkNWQ2NDBjMmJjZWU0YjZmYWIwMmY3NWMxYzg2NTc4NiIsInVzZXJfaWQiOiIxMyJ9.gOpEWPUmFyUwbSOQ0dZjWPE9CJTtKgkhooep2yZiHEg','2025-11-17 07:37:33.696201','2025-11-24 07:37:33.000000',13,'d5d640c2bcee4b6fab02f75c1c865786'),
(139,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk3Mzk3NiwiaWF0IjoxNzYzMzY5MTc2LCJqdGkiOiJiNGQ5ZDNkZTAyNmE0ZGQ3ODg1Mzc4MzQ1MjQzYjU4NCIsInVzZXJfaWQiOiIxMyJ9.0Sr0ndqEGFivNqMTduvOwowX51ahhqHCIleHWsqTonM','2025-11-17 08:46:16.371811','2025-11-24 08:46:16.000000',13,'b4d9d3de026a4dd7885378345243b584'),
(140,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk4Nzg4NCwiaWF0IjoxNzYzMzgzMDg0LCJqdGkiOiJjOTIzOTNhY2IxNGI0ODA4OGIyMjJiNmQ0NDQ0ZWZiNCIsInVzZXJfaWQiOiIxMyJ9.Ergsx_Y9SPtlJODt2AlCzrA8IY6h897ebJG9VwGtiQQ','2025-11-17 12:38:04.486488','2025-11-24 12:38:04.000000',13,'c92393acb14b48088b222b6d4444efb4'),
(141,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk4ODAzMywiaWF0IjoxNzYzMzgzMjMzLCJqdGkiOiI3N2U1MWZmYWUwZGM0YmVkYmNlMmZmNjJiMjNkN2QyOSIsInVzZXJfaWQiOiI0In0.gf0-SpGyKid-sUV-cyEBX1Atj4PjnUsrqETKBKGniu4','2025-11-17 12:40:33.822463','2025-11-24 12:40:33.000000',4,'77e51ffae0dc4bedbce2ff62b23d7d29'),
(142,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk5MDczNywiaWF0IjoxNzYzMzg1OTM3LCJqdGkiOiIxY2Q0Mjc2MzViODU0NjNhODJkOTExZGMyOWRkZDk4OSIsInVzZXJfaWQiOiIxMyJ9.lnfsT8_hrpWTGWMj_gLMLKoH9ec6qha8Rw0YUpRlAME','2025-11-17 13:25:37.044085','2025-11-24 13:25:37.000000',13,'1cd427635b85463a82d911dc29ddd989'),
(143,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk5MDc1MiwiaWF0IjoxNzYzMzg1OTUyLCJqdGkiOiJjYTFhOTY0OTNlNzY0NDlmOTIxOThhMTM0Yzc3ZGMwMCIsInVzZXJfaWQiOiIxMyJ9.9YxPh_lKpQYzc4gur0Gn-VN9bSpkDnXgjLZ4e6zVuCc','2025-11-17 13:25:52.917199','2025-11-24 13:25:52.000000',13,'ca1a96493e76449f92198a134c77dc00'),
(144,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk5MTAzMiwiaWF0IjoxNzYzMzg2MjMyLCJqdGkiOiIyMmE5ZDExZGYxNjc0ZWMzODAxMGU1YzQ0OGY0OWE1ZSIsInVzZXJfaWQiOiI0In0.DMMWCElyrL4_zZoPi2SKhxE0Q_UFPif07JZxm-YkzME','2025-11-17 13:30:32.577459','2025-11-24 13:30:32.000000',4,'22a9d11df1674ec38010e5c448f49a5e'),
(145,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk5MjI4MywiaWF0IjoxNzYzMzg3NDgzLCJqdGkiOiI0NGYyNDczNDZhZDg0YjAyOGZhZGEwNWIxZjExZjk1OSIsInVzZXJfaWQiOiIxNCJ9.q36yMHxMljQcLnPeA56ZM9FAq19dogT2gYEMtUvwysk','2025-11-17 13:51:23.568409','2025-11-24 13:51:23.000000',NULL,'44f247346ad84b028fada05b1f11f959'),
(146,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk5MjI5NSwiaWF0IjoxNzYzMzg3NDk1LCJqdGkiOiJiMDdhOTFlMjE1Njg0MzRhYmM5MDdmYzRiMDdiMjUxNCIsInVzZXJfaWQiOiIxMyJ9.zHGCDrMLcUVFL-nZICVhQ7ublVoKvzhZA49R_V9LqEo','2025-11-17 13:51:35.913480','2025-11-24 13:51:35.000000',13,'b07a91e21568434abc907fc4b07b2514'),
(147,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk5MzA1OCwiaWF0IjoxNzYzMzg4MjU4LCJqdGkiOiJkM2EwYWViMGIzNGU0N2RiYjc0OGQzODg2N2UzMTIwZSIsInVzZXJfaWQiOiIxMyJ9.zc8NDVW4dPQag3E4MWYhj07rxFgVaMV3SNitoZHVoU4','2025-11-17 14:04:18.185590','2025-11-24 14:04:18.000000',13,'d3a0aeb0b34e47dbb748d38867e3120e'),
(148,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk5MzgxNSwiaWF0IjoxNzYzMzg5MDE1LCJqdGkiOiJlNThjYzNhYjVlYjQ0ODRiYjhhMDczODM0MmNmZGMxNyIsInVzZXJfaWQiOiI0In0.e6fMQSw-92TssMlk2NiaWryWtAR3nTkTiBJTb3-Rdrg','2025-11-17 14:16:55.397707','2025-11-24 14:16:55.000000',4,'e58cc3ab5eb4484bb8a0738342cfdc17'),
(149,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk5Mzk0OCwiaWF0IjoxNzYzMzg5MTQ4LCJqdGkiOiIzNGFkYTg5YTYwZjc0NTJmODYyM2M4YWVhMDRhNWE2OCIsInVzZXJfaWQiOiIxMyJ9.dPtFTMP0-K1OqwWOXRDdN04s9IMSzg1sYB8WhocZqa4','2025-11-17 14:19:08.138367','2025-11-24 14:19:08.000000',13,'34ada89a60f7452f8623c8aea04a5a68'),
(150,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Mzk5NDY4NiwiaWF0IjoxNzYzMzg5ODg2LCJqdGkiOiJjNTUwMTgzNDg1YjA0NzVmYTk2ZjlhZGUxMzI0NmZjMSIsInVzZXJfaWQiOiIxMyJ9.L-yv41JhVfACsEEAv6D-aY5jvlrH-tQBDymCUlBaSGs','2025-11-17 14:31:26.810834','2025-11-24 14:31:26.000000',13,'c550183485b0475fa96f9ade13246fc1'),
(151,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDAwMTIxOCwiaWF0IjoxNzYzMzk2NDE4LCJqdGkiOiI1MTM1MGJiZDFmZTc0Y2YyOWZiMjQxNzZiYTNjMTFlZiIsInVzZXJfaWQiOiIxMyJ9.Qii8wUWJtlgmxAwt_0r0_o_u-RiuFhhx_zQ_UH_0mVs','2025-11-17 16:20:18.976007','2025-11-24 16:20:18.000000',13,'51350bbd1fe74cf29fb24176ba3c11ef'),
(152,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDAzMjczMCwiaWF0IjoxNzYzNDI3OTMwLCJqdGkiOiIzZjIyOWY0MzYzMjg0YTUzYTZjZGZhNTk5ODVjZWM4ZiIsInVzZXJfaWQiOiIxMyJ9.xtTARlBE23AQoGkfElrSw9I4NsDS7Y85Bz_rs7xld3U','2025-11-18 01:05:30.469544','2025-11-25 01:05:30.000000',13,'3f229f4363284a53a6cdfa59985cec8f'),
(153,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDAzMzIxOSwiaWF0IjoxNzYzNDI4NDE5LCJqdGkiOiIyMzg4YTBmMWMxZGY0ZTExOTRhY2Q0YTEyNjFiOGQ1NyIsInVzZXJfaWQiOiI0In0.s0wYugCsLbXcvZyrG_WcL6QFU5Ublksm7V-STt9MgfU','2025-11-18 01:13:39.601168','2025-11-25 01:13:39.000000',4,'2388a0f1c1df4e1194acd4a1261b8d57'),
(154,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDAzMzI2MCwiaWF0IjoxNzYzNDI4NDYwLCJqdGkiOiIyODQyMzg1Y2ViYTQ0MGI0YjYzYTVhMjU5NjYwNmQyMyIsInVzZXJfaWQiOiIxMyJ9.Vg7mfuJcODnIVTTryGu_1tCQWxn3L8YLy-00jJ4W2Jk','2025-11-18 01:14:20.089496','2025-11-25 01:14:20.000000',13,'2842385ceba440b4b63a5a2596606d23'),
(155,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDAzNTA2NSwiaWF0IjoxNzYzNDMwMjY1LCJqdGkiOiI0MDk2MWZiODM3M2M0NGQzOTQ1OTIyNjM1YzkxNzQ1YyIsInVzZXJfaWQiOiIxMCJ9.lmo_Z49_KJzVkP_gkVxMpoPsmQUpWHHifmWMFhZNLks','2025-11-18 01:44:25.655301','2025-11-25 01:44:25.000000',NULL,'40961fb8373c44d3945922635c91745c'),
(156,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDAzNzU1MiwiaWF0IjoxNzYzNDMyNzUyLCJqdGkiOiI0ZDVmNDZlMTY1MjA0NmY4OWQ5OGU5OTBiMTRhN2QxZSIsInVzZXJfaWQiOiIzIn0.vHR_nEtRKUmUWHLgf7YEVc1_Xdh7xWOXjbywmgGpPWE','2025-11-18 02:25:52.046096','2025-11-25 02:25:52.000000',NULL,'4d5f46e1652046f89d98e990b14a7d1e'),
(157,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDAzOTgzMiwiaWF0IjoxNzYzNDM1MDMyLCJqdGkiOiJlY2Y0OGFmYTY0MzM0MDg2OWVjMjc1MmIxY2NmODQwNSIsInVzZXJfaWQiOiIxMyJ9.S2B2qfeBErrXxclJXqZGx8MN2hI1uS_w3dhin5RHTGs','2025-11-18 03:03:52.529825','2025-11-25 03:03:52.000000',13,'ecf48afa643340869ec2752b1ccf8405'),
(158,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDAzOTg0NCwiaWF0IjoxNzYzNDM1MDQ0LCJqdGkiOiIwZjQ3YWZiYjU5Nzg0OGMxYjM0ZGQzOGU5NDAwMDczNSIsInVzZXJfaWQiOiIxMyJ9.hbE4pY_ZlV89oqLzui4n3FX590P9tqI8N1AAxw-8vnY','2025-11-18 03:04:04.314700','2025-11-25 03:04:04.000000',13,'0f47afbb597848c1b34dd38e94000735'),
(159,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDA0MDcxMiwiaWF0IjoxNzYzNDM1OTEyLCJqdGkiOiI0N2M5ZmMxOTJlYTA0MzJjYjg4ZWE2YmEzYTMxYzZhMiIsInVzZXJfaWQiOiI0In0.SZyJxh01YdCzcJWoDb3rMASYtJ5uo8RCJE9z88jdSrM','2025-11-18 03:18:32.030034','2025-11-25 03:18:32.000000',4,'47c9fc192ea0432cb88ea6ba3a31c6a2'),
(160,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDA0MDc5MiwiaWF0IjoxNzYzNDM1OTkyLCJqdGkiOiIxZTlhYmMwMmU0MTY0YjEyODk5NDkzZGQ4YjAzNmM0NiIsInVzZXJfaWQiOiIxMyJ9.uc6lolKYBwuqI_JWxe4H0m8D5C5IBaXngwtRJDJtI4U','2025-11-18 03:19:52.958179','2025-11-25 03:19:52.000000',13,'1e9abc02e4164b12899493dd8b036c46'),
(161,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDA0MTE0NCwiaWF0IjoxNzYzNDM2MzQ0LCJqdGkiOiIwNzY3MDA0M2ZlM2M0YzI2OGQyZGNhMzczZWRlNjBmOSIsInVzZXJfaWQiOiIxMyJ9.--ZcwHqYfII2uCj_MMQ2g-gcLZ6H9XXwI_IKMYSoTKA','2025-11-18 03:25:44.268468','2025-11-25 03:25:44.000000',13,'07670043fe3c4c268d2dca373ede60f9'),
(162,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDA0NjU5NiwiaWF0IjoxNzYzNDQxNzk2LCJqdGkiOiJhYzk0NmE1ZjE5NzA0YmJhOTA0MTc4YzBmNDdlZGQwYiIsInVzZXJfaWQiOiIxMyJ9.WPmW9qqsADin9FjpQexAfrzNe0R_Pimi7KPo-qpyjRY','2025-11-18 04:56:36.241270','2025-11-25 04:56:36.000000',13,'ac946a5f19704bba904178c0f47edd0b'),
(163,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDA1MjMyMywiaWF0IjoxNzYzNDQ3NTIzLCJqdGkiOiIxYzEzZTViYzYyYTI0MDM3YTcyOTYwOWJmMTQ1MmQyNyIsInVzZXJfaWQiOiIxMyJ9.n4zw4xuPgxBMxBQpN8CzCp_U0yTsnR_wM3hIB40S-s4','2025-11-18 06:32:03.709663','2025-11-25 06:32:03.000000',13,'1c13e5bc62a24037a729609bf1452d27'),
(164,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDA1Mjg4MCwiaWF0IjoxNzYzNDQ4MDgwLCJqdGkiOiIxNGFjODAyYjhiNGQ0YTBhYWRjYWNiOWI5MzQ3ZmQwNyIsInVzZXJfaWQiOiIxNSJ9.3VkRq7pIHDI4GE0jOFYlaq5r3qgahwQEsuIZx2sBt6A','2025-11-18 06:41:20.517359','2025-11-25 06:41:20.000000',NULL,'14ac802b8b4d4a0aadcacb9b9347fd07'),
(165,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDA1MjkxMSwiaWF0IjoxNzYzNDQ4MTExLCJqdGkiOiI0YzY3OWI5Y2JiMWQ0NjNlYTRhZWM5NWM5MjkzMGNiOSIsInVzZXJfaWQiOiIxNSJ9.u_x_UKWzAImx9o1AieH0_s8jGYCEJMf2JpzbMcEGXlc','2025-11-18 06:41:51.813813','2025-11-25 06:41:51.000000',NULL,'4c679b9cbb1d463ea4aec95c92930cb9'),
(166,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDA1NzMxMSwiaWF0IjoxNzYzNDUyNTExLCJqdGkiOiJkZWViNjFhYmZkMmI0YWE5YmU2ODE1NDRiMjNjYjEwMyIsInVzZXJfaWQiOiI0In0.sV4D0W3Vo2eFmoYeSy4hP0UvCfWJJSZGLfS4VCWT2qQ','2025-11-18 07:55:11.872850','2025-11-25 07:55:11.000000',4,'deeb61abfd2b4aa9be681544b23cb103'),
(167,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDA1OTczMSwiaWF0IjoxNzYzNDU0OTMxLCJqdGkiOiJlMjZmNTE1ZmQwNTg0Zjk3YTI4NDU5NDA5NTJmNGE4ZiIsInVzZXJfaWQiOiI4In0.4qJWx9S_Qbp06JvVhYw-JLdJtN1gfv4LZBHI3V2KjrE','2025-11-18 08:35:31.269441','2025-11-25 08:35:31.000000',8,'e26f515fd0584f97a2845940952f4a8f'),
(168,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDA2NTEwNiwiaWF0IjoxNzYzNDYwMzA2LCJqdGkiOiIwMDY2ZWVjMjBhZGQ0OWQyYmU5NjAwMjkwNzUxY2EzYiIsInVzZXJfaWQiOiI0In0.BIl6GPqpFBgT9ihsEch0klWrtz0Uutic9do4bXpAZZI','2025-11-18 10:05:06.033018','2025-11-25 10:05:06.000000',4,'0066eec20add49d2be9600290751ca3b'),
(169,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDA2ODA4NywiaWF0IjoxNzYzNDYzMjg3LCJqdGkiOiI1MjM2YjgzMThjNmY0MGIwYjY4Y2ZjNGY2NjQwNTMyZiIsInVzZXJfaWQiOiI0In0.rwJOTLEce9IITGtAB31KY1ET3yGEUGnJqDKiubLYUiM','2025-11-18 10:54:47.731731','2025-11-25 10:54:47.000000',4,'5236b8318c6f40b0b68cfc4f6640532f'),
(170,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDA3MTc5NiwiaWF0IjoxNzYzNDY2OTk2LCJqdGkiOiJkOWFiZGE4ZGY4ZWU0ZmRiOTRmYjQ2YTU4N2FhYzFhZCIsInVzZXJfaWQiOiIxMyJ9.KweQfS_XtVyAc7LFsgUZpnrgsYI_jXKSb9jQ8kveEKg','2025-11-18 11:56:36.755820','2025-11-25 11:56:36.000000',13,'d9abda8df8ee4fdb94fb46a587aac1ad'),
(171,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDA3OTMzOCwiaWF0IjoxNzYzNDc0NTM4LCJqdGkiOiIzY2Q0YTJmYjdkMzY0M2Y4OTBjZDVjMDFlZGY4YTI4OSIsInVzZXJfaWQiOiI0In0.k2Tn4z81kOVgAkS7reojHryA_BaENYUbiAuIGcbQm5U','2025-11-18 14:02:18.061605','2025-11-25 14:02:18.000000',4,'3cd4a2fb7d3643f890cd5c01edf8a289'),
(172,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDEwNjkwNCwiaWF0IjoxNzYzNTAyMTA0LCJqdGkiOiJlNDBkZDFjNTYwOTE0NzIwODQyNzRiOTBlNTYzNTM4ZiIsInVzZXJfaWQiOiIxMyJ9.HnO8ucujerqz_JNsCdvUJc8rI-29Am06fkoFhrr-ors','2025-11-18 21:41:44.120505','2025-11-25 21:41:44.000000',13,'e40dd1c56091472084274b90e563538f'),
(173,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDEwNjk5MiwiaWF0IjoxNzYzNTAyMTkyLCJqdGkiOiJiMGMxYjQwMGNlNzQ0MTMxOGFlNDhhM2MxZjhjMTZhNiIsInVzZXJfaWQiOiI0In0.ag5wT_uTyQQYHRWn9ML1YxEoX0NS9NmfolGeYMBxoFU','2025-11-18 21:43:12.029643','2025-11-25 21:43:12.000000',4,'b0c1b400ce7441318ae48a3c1f8c16a6'),
(174,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDExNzI1OSwiaWF0IjoxNzYzNTEyNDU5LCJqdGkiOiJhYmIyYmU0ZWM5YmM0ZGFmODAyOTczMjU3NTU0Zjk3MiIsInVzZXJfaWQiOiIxMyJ9.dA_rwKkdJ24ZV4NZUGdYMMC2JGpvKuC-DOUpAYlhWSY','2025-11-19 00:34:19.601979','2025-11-26 00:34:19.000000',13,'abb2be4ec9bc4daf802973257554f972'),
(175,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDEyMTM4OSwiaWF0IjoxNzYzNTE2NTg5LCJqdGkiOiI0ZTFhMGM2NmRiMWI0NDZlODMxMTkxOTZkY2ZkZWRiNSIsInVzZXJfaWQiOiI0In0.nNqlfh6xPmEOwzs9eSQSV-9jWKmznZ0Kb5TWRZfY1SY','2025-11-19 01:43:09.223736','2025-11-26 01:43:09.000000',4,'4e1a0c66db1b446e83119196dcfdedb5'),
(176,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDEyMjA1NiwiaWF0IjoxNzYzNTE3MjU2LCJqdGkiOiJiMzk1MzYxMDllZDc0OGVjYTQ5NzZhZWFiYzUzYzBiYiIsInVzZXJfaWQiOiI0In0.pTIvPy6KeWhyb-3HdYm2u6ghQ42Ga-3L6yM6I_JKb4w','2025-11-19 01:54:16.200319','2025-11-26 01:54:16.000000',4,'b39536109ed748eca4976aeabc53c0bb'),
(177,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDEyMjI0NCwiaWF0IjoxNzYzNTE3NDQ0LCJqdGkiOiI5NDI4MjQzMGViODI0NGM4OGM3ODgyYWVjMWUyZDc2ZiIsInVzZXJfaWQiOiIxMyJ9.Rew9evTqvXj4KxaY5iGb5tzigMU2yPXG7DS5ItN9mkg','2025-11-19 01:57:24.366820','2025-11-26 01:57:24.000000',13,'94282430eb8244c88c7882aec1e2d76f'),
(178,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDEyNDAwNiwiaWF0IjoxNzYzNTE5MjA2LCJqdGkiOiI0M2NiNGZkYWU5ZjE0YWY1YmQ1MDk2NTEwYmNkMmZlNyIsInVzZXJfaWQiOiIxMyJ9.T_CvcX0L7JjPiQijdspsd7sxf5HjyXrhoM_n9Pf5AQM','2025-11-19 02:26:46.551231','2025-11-26 02:26:46.000000',13,'43cb4fdae9f14af5bd5096510bcd2fe7'),
(179,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDEzMDQzMiwiaWF0IjoxNzYzNTI1NjMyLCJqdGkiOiJhZmIyODI4MzBkOGU0ZjZhODdmYzhmZGM5YjE3Y2I3OCIsInVzZXJfaWQiOiIxMCJ9.SgFtyN7tmQ-gWgcdhXNX_KesWQzsnSJbe6WrMqdv7jA','2025-11-19 04:13:52.885589','2025-11-26 04:13:52.000000',NULL,'afb282830d8e4f6a87fc8fdc9b17cb78'),
(180,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDEzMDU3MCwiaWF0IjoxNzYzNTI1NzcwLCJqdGkiOiIzMTU4YjVhY2IyMTY0ZjZkYTIwM2IyNzIyODVkZDI5YyIsInVzZXJfaWQiOiIxMyJ9.gYzjcbOUrp_O3NTICoeeg9mUGudMkabK36bL8o8iYNc','2025-11-19 04:16:10.065927','2025-11-26 04:16:10.000000',13,'3158b5acb2164f6da203b272285dd29c'),
(181,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDEzMDg4NywiaWF0IjoxNzYzNTI2MDg3LCJqdGkiOiIyNTdhMmQzMDFmNjY0NjBhODRiMDFmMDEzNzA3MzhlZCIsInVzZXJfaWQiOiIxNiJ9.jpA-qOWHZamUpjc8g65Ol4u9ESvLE0AqERP19K-9Ros','2025-11-19 04:21:27.569628','2025-11-26 04:21:27.000000',16,'257a2d301f66460a84b01f01370738ed'),
(182,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDEzMDkwOSwiaWF0IjoxNzYzNTI2MTA5LCJqdGkiOiI4MTA1OTVmN2Y2NGI0MDk1YWU0NDFmMzhkYTc0ZTk0NCIsInVzZXJfaWQiOiIxNiJ9.DvGcdgY_T57Ip4QV_br0wkP6XxsawY1kMeEBXRxKNvs','2025-11-19 04:21:49.062146','2025-11-26 04:21:49.000000',16,'810595f7f64b4095ae441f38da74e944'),
(183,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDEzMTQ5OSwiaWF0IjoxNzYzNTI2Njk5LCJqdGkiOiI2NWM0ZGE0OTMyNTE0NDdmYTk5YjRkNjM4ZTNlZDkyOCIsInVzZXJfaWQiOiIxMyJ9.lihCQl3q-pK_-H66Hw9-ouWRb8tSg0ivxjzVTr5S27s','2025-11-19 04:31:39.213857','2025-11-26 04:31:39.000000',13,'65c4da493251447fa99b4d638e3ed928'),
(184,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDEzMTYxNiwiaWF0IjoxNzYzNTI2ODE2LCJqdGkiOiIwNGI3NzNlMjgxMzY0OWUxOWE1MjY0ZjllODY2N2JhMSIsInVzZXJfaWQiOiIxNiJ9.oglhlSOkNcoqhyRtA0Y8kzugfkvBdSR2qAf36kqtM3w','2025-11-19 04:33:36.457037','2025-11-26 04:33:36.000000',16,'04b773e2813649e19a5264f9e8667ba1'),
(185,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDEzOTY4OCwiaWF0IjoxNzYzNTM0ODg4LCJqdGkiOiIyNDNiOWYwYzBlMWI0OWZhYWE0MmIzODhhNzE4NjNmNyIsInVzZXJfaWQiOiIxMyJ9.0bOj1vL-0HDxdN0cBt4PVRMeCy95PfvY2si60JVHJ-M','2025-11-19 06:48:08.389452','2025-11-26 06:48:08.000000',13,'243b9f0c0e1b49faaa42b388a71863f7'),
(186,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDE0MDQzNiwiaWF0IjoxNzYzNTM1NjM2LCJqdGkiOiI5YzcyMDI5ZDlkZmU0OWMxYmI0NTA5YjUzMzA1NzkxNSIsInVzZXJfaWQiOiIxNyJ9.vpDaAPACcIbdQbgvzOv5fqbq_ppanXfKyOwVK_LoZ8s','2025-11-19 07:00:36.381339','2025-11-26 07:00:36.000000',NULL,'9c72029d9dfe49c1bb4509b533057915'),
(187,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDE0MDQ2NiwiaWF0IjoxNzYzNTM1NjY2LCJqdGkiOiI1NmRkNTdmZTEwYzc0N2ZjYmViMmI0YWY2YTU1ZGRiOCIsInVzZXJfaWQiOiIxNyJ9.OjrL4imT219pm4hJ1uT2lTR6nAiXV-UFZKq2qnm5Jz4','2025-11-19 07:01:06.997970','2025-11-26 07:01:06.000000',NULL,'56dd57fe10c747fcbeb2b4af6a55ddb8'),
(188,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDE0MDcxNSwiaWF0IjoxNzYzNTM1OTE1LCJqdGkiOiJkZGJkOGUzMDRmODM0N2NmYmVjNTJhMmMzZWMxMGIwMyIsInVzZXJfaWQiOiIxNyJ9.9uMJ78yAIA5dD9KkM66i_sC0SEDhz1ZP6r3pUrrTImY','2025-11-19 07:05:15.223698','2025-11-26 07:05:15.000000',NULL,'ddbd8e304f8347cfbec52a2c3ec10b03'),
(189,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDE0MjIzOCwiaWF0IjoxNzYzNTM3NDM4LCJqdGkiOiI1MmQ4MjI2YWZhYjQ0NDkxYjgzMjlkZDI1ZDlhNzMyNSIsInVzZXJfaWQiOiI0In0.ed2MAPSsjhTEmwgQ0nlOhaOIthg5kDFfpIvXJaoqjXo','2025-11-19 07:30:38.806008','2025-11-26 07:30:38.000000',4,'52d8226afab44491b8329dd25d9a7325'),
(190,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDE1NTkxOCwiaWF0IjoxNzYzNTUxMTE4LCJqdGkiOiJjYWI2MTJjNThkZjQ0NDY2OWU3YmJjMmM4NGY2OTMwZCIsInVzZXJfaWQiOiIxMyJ9.6aSPKgP2yLJeRLOCEsv41dzkRzIXgbOf_7N7GrTZxZs','2025-11-19 11:18:38.792980','2025-11-26 11:18:38.000000',13,'cab612c58df444669e7bbc2c84f6930d'),
(191,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDE1OTI5NywiaWF0IjoxNzYzNTU0NDk3LCJqdGkiOiIwYjM5MzFlMWJmNDg0NGNlODRkMDViNzRjYWUyNmJhMyIsInVzZXJfaWQiOiIxMyJ9.WR7fyrYkCMoJobnx_uSAl2EXwj65TOZFtEgCWwtvERM','2025-11-19 12:14:57.233532','2025-11-26 12:14:57.000000',13,'0b3931e1bf4844ce84d05b74cae26ba3'),
(192,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDE2NDM2NSwiaWF0IjoxNzYzNTU5NTY1LCJqdGkiOiJkM2UyMjQ3YzQ5Mjk0ZDZkYjkyYzE3ZjEwYmI1Yjc1YyIsInVzZXJfaWQiOiI0In0.y-vkNcXVaKjyHwPlvHYQ13VV11HrfH2h2GFR88oCg2o','2025-11-19 13:39:25.575531','2025-11-26 13:39:25.000000',4,'d3e2247c49294d6db92c17f10bb5b75c'),
(193,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDE2OTc5MiwiaWF0IjoxNzYzNTY0OTkyLCJqdGkiOiJmMWQwZTBjZmNiYjc0MjkxYmY1Mjk4MGE4ZDllYzkwOCIsInVzZXJfaWQiOiIxNiJ9.3QQ6q9-KulzdWUvFLzXqEUFKWD1dcD3wySL_BZq2tpI','2025-11-19 15:09:52.066641','2025-11-26 15:09:52.000000',16,'f1d0e0cfcbb74291bf52980a8d9ec908'),
(194,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDE3MTk4OCwiaWF0IjoxNzYzNTY3MTg4LCJqdGkiOiI3YzE1MGE4ZTNiODI0YjhmYjBjN2FiMTFjODdmNGY5NyIsInVzZXJfaWQiOiIxMyJ9.K1vrw4Z9hQH4j9QmyQywZ4IpH-QI5_yDHj1x856YDP8','2025-11-19 15:46:28.650451','2025-11-26 15:46:28.000000',13,'7c150a8e3b824b8fb0c7ab11c87f4f97'),
(195,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDIwMTU4MSwiaWF0IjoxNzYzNTk2NzgxLCJqdGkiOiI2NDNkZGNhM2VlN2U0ZmNjYjJmOGRmODA0NzkwZmFlYiIsInVzZXJfaWQiOiIxMyJ9.oGtPuj0Mkh5smiLfaZ6v6fSwC3rnEhoBlxYzFH2jgRc','2025-11-19 23:59:41.017540','2025-11-26 23:59:41.000000',13,'643ddca3ee7e4fccb2f8df804790faeb'),
(196,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDIwNTE1MSwiaWF0IjoxNzYzNjAwMzUxLCJqdGkiOiJkODRiYmRkZTg1YWI0YTQ3ODY5MjBhMDA5Njg3YjBkYSIsInVzZXJfaWQiOiI0In0.7oAyVNLz_Uk19Ep_xYReq63XyV08RfkRYVTOn1PvKM8','2025-11-20 00:59:11.334611','2025-11-27 00:59:11.000000',4,'d84bbdde85ab4a4786920a009687b0da'),
(197,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDIwNTIwMSwiaWF0IjoxNzYzNjAwNDAxLCJqdGkiOiI2MzRiZWNhYzRlMDU0ZDNmYTI1YzBjODQ4M2U1NjM4NyIsInVzZXJfaWQiOiIxMCJ9.rRwYwFN-kEkI55-afXEU-B-84DABymqdNbAOx029JAc','2025-11-20 01:00:01.769872','2025-11-27 01:00:01.000000',NULL,'634becac4e054d3fa25c0c8483e56387'),
(198,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDIwNjg1MywiaWF0IjoxNzYzNjAyMDUzLCJqdGkiOiJlNjA1ZWM2NzViOWU0NDFiOWIwZmI3OGFkYzA2NTQ0OCIsInVzZXJfaWQiOiIxMyJ9.5kWJ6T3IawsUQ2Y5XZ6pdt1AqJAVB30Mx6-9YDMcIeo','2025-11-20 01:27:33.593083','2025-11-27 01:27:33.000000',13,'e605ec675b9e441b9b0fb78adc065448'),
(199,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDIwNzE0NiwiaWF0IjoxNzYzNjAyMzQ2LCJqdGkiOiJkYTVlMWRhNGQ2MTU0MTcxODNlNmYxOTJmYmQwNzU0ZiIsInVzZXJfaWQiOiI0In0.A108JHesDJ0XHFnKOTItsR9OL2cB-gGTzs40D5TmcMY','2025-11-20 01:32:26.063807','2025-11-27 01:32:26.000000',4,'da5e1da4d615417183e6f192fbd0754f'),
(200,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDIxMjU0NCwiaWF0IjoxNzYzNjA3NzQ0LCJqdGkiOiI3ZTdkMmI0NTE1NGE0MGNiYmM0MWRiZDJkMWQ0NGEwYyIsInVzZXJfaWQiOiIxMCJ9.ewqYMUrHdtpPXGZqO0qb3w-e0hIhKvsS2lUyLK6c4HE','2025-11-20 03:02:24.560355','2025-11-27 03:02:24.000000',NULL,'7e7d2b45154a40cbbc41dbd2d1d44a0c'),
(201,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDIxNzMwMSwiaWF0IjoxNzYzNjEyNTAxLCJqdGkiOiIwM2E2NzBkOWIwNzM0OGQ2OTBlOTZjNzdkZGMyMTgyNCIsInVzZXJfaWQiOiIxOCJ9.uYD9NwhDoospha7pEgoEEvlkgDZC0Ti8bvt3FO804bs','2025-11-20 04:21:41.927344','2025-11-27 04:21:41.000000',18,'03a670d9b07348d690e96c77ddc21824'),
(202,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDIxNzM1OCwiaWF0IjoxNzYzNjEyNTU4LCJqdGkiOiI1NjUzNTdhYzUwYmQ0NTZmODQxMTcxMGMwZTdhNmY1YyIsInVzZXJfaWQiOiIxOCJ9.CsGkPjfBWge89CsASvFqZydMiUtJ4CmeK2KFHf1SqPM','2025-11-20 04:22:38.656189','2025-11-27 04:22:38.000000',18,'565357ac50bd456f8411710c0e7a6f5c'),
(203,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDIyNTM0MiwiaWF0IjoxNzYzNjIwNTQyLCJqdGkiOiIxNjYxMWNmMDhjNjc0NWJmODY3M2NkMGFiZWFhNTBkMiIsInVzZXJfaWQiOiIxOSJ9.TDZ0t7fm9VlotYtRVTsvArP2XxAJDGTBHuybUgPMdgs','2025-11-20 06:35:42.143931','2025-11-27 06:35:42.000000',NULL,'16611cf08c6745bf8673cd0abeaa50d2'),
(204,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDIyNTM0OCwiaWF0IjoxNzYzNjIwNTQ4LCJqdGkiOiI0NzcyYzUyOTVkZDk0MzdlYmFlNWU5OTRhNWM5YWRiZCIsInVzZXJfaWQiOiIxOSJ9.zeVtBj-m8VOomjPr5ZCPVVvEwONP8tGRTWkfoZ13tZ4','2025-11-20 06:35:48.513399','2025-11-27 06:35:48.000000',NULL,'4772c5295dd9437ebae5e994a5c9adbd'),
(205,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDIzMjQ0MSwiaWF0IjoxNzYzNjI3NjQxLCJqdGkiOiI5ZTIwZWRhMzE3YWQ0ZGQ5YTFlNWJlYjY4MjU4NzliYiIsInVzZXJfaWQiOiIxMyJ9.-8TVv1dKQnBwNUywGCfflBwdVZaEU8O423ApNfgiPbQ','2025-11-20 08:34:01.601001','2025-11-27 08:34:01.000000',13,'9e20eda317ad4dd9a1e5beb6825879bb'),
(206,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDIzMzcwMywiaWF0IjoxNzYzNjI4OTAzLCJqdGkiOiJhZTI1OGIwMDE2YTA0NDMyYjcyNjBlZjY0MzM0NTZjYSIsInVzZXJfaWQiOiIxMyJ9.9MrGo0nH4YNmRXCG4nzKphisTmhRaiVXSedcb6NYa1k','2025-11-20 08:55:03.717125','2025-11-27 08:55:03.000000',13,'ae258b0016a04432b7260ef6433456ca'),
(207,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDI0MzkyOSwiaWF0IjoxNzYzNjM5MTI5LCJqdGkiOiJiM2Q4NmM1MGJhYTg0NTYwYjAwYTUyYTMyZTdiOGM1YSIsInVzZXJfaWQiOiIxMCJ9.R3x8Rfjy88A-F5uwfxT8V8aTSP1yHQvj068I0WR63SM','2025-11-20 11:45:29.076601','2025-11-27 11:45:29.000000',NULL,'b3d86c50baa84560b00a52a32e7b8c5a'),
(208,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDI0NzExNCwiaWF0IjoxNzYzNjQyMzE0LCJqdGkiOiI4MzEyOGRhMDRhMWI0OTA0YWY3Mzc4YjEzNTY3NTM3OCIsInVzZXJfaWQiOiI4In0.s3KipFp199zaTU63gnzWbjKGQ-sCM1sH5vWkAsJOQZ0','2025-11-20 12:38:34.306925','2025-11-27 12:38:34.000000',8,'83128da04a1b4904af7378b135675378'),
(209,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDI0OTQxNCwiaWF0IjoxNzYzNjQ0NjE0LCJqdGkiOiIzOGJmZjAzYWNmMGU0YjQ5OWY3YzQzYTFlZGE3NWFkOCIsInVzZXJfaWQiOiIxOCJ9.1CJfnawmsXKlL3tIhP3PbQhNdTzbpeGJQ9AvkzjyUME','2025-11-20 13:16:54.420042','2025-11-27 13:16:54.000000',18,'38bff03acf0e4b499f7c43a1eda75ad8'),
(210,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDI1NDMwMSwiaWF0IjoxNzYzNjQ5NTAxLCJqdGkiOiJmZGY0MDYzZmU0YTg0YjdkYWRhYWM0MDhmZjgxODU5OCIsInVzZXJfaWQiOiIxOCJ9.5rM62OZ9cuCAPboshVMM0OHbGfv2DbmJhXNa5Fi1sUQ','2025-11-20 14:38:21.632847','2025-11-27 14:38:21.000000',18,'fdf4063fe4a84b7dadaac408ff818598'),
(211,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDI1NDMwNiwiaWF0IjoxNzYzNjQ5NTA2LCJqdGkiOiJlNGY0ZmJiYmQ1ODU0NDIwYTlmYzRiOWE4OGZiNDcxNyIsInVzZXJfaWQiOiIxOCJ9.zW6XV7cWKef5H8nSbh07HffIM3uGNa7cOGci-6EocqY','2025-11-20 14:38:26.563893','2025-11-27 14:38:26.000000',18,'e4f4fbbbd5854420a9fc4b9a88fb4717'),
(212,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDI1NjA5MSwiaWF0IjoxNzYzNjUxMjkxLCJqdGkiOiI0Nzg0NDFmMDEwZTE0ZDE2YTAwZWZhNWZjMmEwYWQ4OSIsInVzZXJfaWQiOiIxOCJ9.qRFzdEiCZSHSzzsN-GHUWb4Z_BJ_w9AnT3zg7IRYR4s','2025-11-20 15:08:11.567703','2025-11-27 15:08:11.000000',18,'478441f010e14d16a00efa5fc2a0ad89'),
(213,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDI2MDMzOSwiaWF0IjoxNzYzNjU1NTM5LCJqdGkiOiIxNDBjOGIwZjg5YTU0MjUyODNkNmQ0NzEzZTdhNWNiNSIsInVzZXJfaWQiOiIxOCJ9.GoAOYYJXs4Dj-7WkcSXaMe1ucmMofjjoF40Oyk7w5NA','2025-11-20 16:18:59.873124','2025-11-27 16:18:59.000000',18,'140c8b0f89a5425283d6d4713e7a5cb5'),
(214,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDI5NDI2MywiaWF0IjoxNzYzNjg5NDYzLCJqdGkiOiI3ODhlYTQ4MDFhOTE0ZDI4ODU2NGNmNTdkYjU4NDM4YyIsInVzZXJfaWQiOiI0In0.e7QOz8R8QZwHs3_BwUAMZ8vtzHOnlhqeV40XeT7HokE','2025-11-21 01:44:23.619817','2025-11-28 01:44:23.000000',4,'788ea4801a914d288564cf57db58438c'),
(215,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDI5NDM1MCwiaWF0IjoxNzYzNjg5NTUwLCJqdGkiOiI2Mzg1MjE2MjExM2I0MzJjYWY5ZGNkZThlZGM4Mzc5YiIsInVzZXJfaWQiOiI0In0.Mnzqzh-mpgyqVatDf1edb4rA4VPwlDD6RUOgPdWnsZc','2025-11-21 01:45:50.574592','2025-11-28 01:45:50.000000',4,'63852162113b432caf9dcde8edc8379b'),
(216,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDI5NDgwOCwiaWF0IjoxNzYzNjkwMDA4LCJqdGkiOiI1YzQwN2YxZjg5MzM0ODQ0OGU4MTRkMWZiMDEwMTYwMyIsInVzZXJfaWQiOiI0In0.pJ0z13WsZ-NXDFsA1zTEv4l1pR_DZlQECRqz20LSd64','2025-11-21 01:53:28.851983','2025-11-28 01:53:28.000000',4,'5c407f1f893348448e814d1fb0101603'),
(217,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDI5Njk2MCwiaWF0IjoxNzYzNjkyMTYwLCJqdGkiOiI0NWY0MTI3MmFjZjc0OTViODg1MzkzNDdiZjA2MDE3NCIsInVzZXJfaWQiOiI0In0.UQNccNrPLGsVUm5UmF8WagJ-_G1g4EZe-U_G7GlJ1bg','2025-11-21 02:29:20.054975','2025-11-28 02:29:20.000000',4,'45f41272acf7495b88539347bf060174'),
(218,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDMwMzk0MCwiaWF0IjoxNzYzNjk5MTQwLCJqdGkiOiJiZmJjZmE0ZmI2Y2Q0M2M5OWU3MjMwMzdmZmU0ODhmNyIsInVzZXJfaWQiOiIyMCJ9.-iojxVo-Z9K5Y58l8mAqaHHygaN9Qc38F8uoUCSRy6A','2025-11-21 04:25:40.390489','2025-11-28 04:25:40.000000',20,'bfbcfa4fb6cd43c99e723037ffe488f7'),
(219,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDMwMzk1NSwiaWF0IjoxNzYzNjk5MTU1LCJqdGkiOiI3OTY4ODNiNjQ0M2E0MGQ3OTYzZmU4MGNlOTI1OWU0ZCIsInVzZXJfaWQiOiIyMCJ9.XRjb_70yRV828tYz_RRBHLGzHyzSjjpVCLf3WGlzXLM','2025-11-21 04:25:55.736750','2025-11-28 04:25:55.000000',20,'796883b6443a40d7963fe80ce9259e4d'),
(220,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDMwNDAzMCwiaWF0IjoxNzYzNjk5MjMwLCJqdGkiOiI5Y2ZlMTJlZWQ0ODE0Y2YwYjNjOWE0MDFkZDljYzQ4MiIsInVzZXJfaWQiOiIyMCJ9.LHInFZzYWa0jip6PPfXFciQ7as-TUOMav-HxLgDRYOc','2025-11-21 04:27:10.841316','2025-11-28 04:27:10.000000',20,'9cfe12eed4814cf0b3c9a401dd9cc482'),
(221,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDMwNDE0OCwiaWF0IjoxNzYzNjk5MzQ4LCJqdGkiOiIxYThiMTY3ZTM3OWE0NjQ2YjdlNzVmNDE2MWRhZjUyMyIsInVzZXJfaWQiOiIxOCJ9.dn-H9YmQoWU7Z80nYBJDTbHQf5EAGcqXubCZzt-6guU','2025-11-21 04:29:08.363633','2025-11-28 04:29:08.000000',18,'1a8b167e379a4646b7e75f4161daf523'),
(222,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDMwODU4MCwiaWF0IjoxNzYzNzAzNzgwLCJqdGkiOiIxZjM4NWQxNTkzYTc0ODNhODA4MzFlZDU2ZTA1ZDRiNCIsInVzZXJfaWQiOiIyMSJ9.6uRfn7oDKfQNY5OvX5oqKaaTlCcq2qvE4wP5--5G6WQ','2025-11-21 05:43:00.387023','2025-11-28 05:43:00.000000',21,'1f385d1593a7483a80831ed56e05d4b4'),
(223,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDMwODYwNiwiaWF0IjoxNzYzNzAzODA2LCJqdGkiOiIxNWU3MGIzM2QxMDE0ZTU4YjI2NWJiYzIzMDI3ODAxZSIsInVzZXJfaWQiOiIyMSJ9.MqEwopeq96Xy-w_p1DZlqTGl-3wyjHPyUQTLJvqtpoQ','2025-11-21 05:43:26.695092','2025-11-28 05:43:26.000000',21,'15e70b33d1014e58b265bbc23027801e'),
(224,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDMxMjgzOCwiaWF0IjoxNzYzNzA4MDM4LCJqdGkiOiI0ODI5Y2QzYjE2NjI0Y2U2YjZiZDY1OWI1NGM5NWM0MyIsInVzZXJfaWQiOiIxOCJ9.rNhPIV7TblwhZhwTsJFqSws_AIASsL30XwetUA1Z1gE','2025-11-21 06:53:58.277244','2025-11-28 06:53:58.000000',18,'4829cd3b16624ce6b6bd659b54c95c43'),
(225,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDMxMzkzMCwiaWF0IjoxNzYzNzA5MTMwLCJqdGkiOiJhNDNiMmUwNzUzYzA0ZjlmYWRjZGJkZjUwMWI4NDc2YiIsInVzZXJfaWQiOiIxMyJ9.3iRCB2LreRnmM7J1n1VkOOPT4DESAisLrjDD8bu0yi8','2025-11-21 07:12:10.000030','2025-11-28 07:12:10.000000',13,'a43b2e0753c04f9fadcdbdf501b8476b'),
(226,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDMxNTI3NCwiaWF0IjoxNzYzNzEwNDc0LCJqdGkiOiJlMTFkNjBhMDVhNzI0YjdkYjYzYzdmODY4MWU1ZjkwMCIsInVzZXJfaWQiOiIxMCJ9.z5IFrmfUe0NKVLczJdEJ11kmENyjqhej8NYYPt9sv9E','2025-11-21 07:34:34.103384','2025-11-28 07:34:34.000000',NULL,'e11d60a05a724b7db63c7f8681e5f900'),
(227,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDMxNTI4NywiaWF0IjoxNzYzNzEwNDg3LCJqdGkiOiJjYWEyOTIzZDNiNGM0ODM2YmJhNWU5NjcyYjAwYzc0OSIsInVzZXJfaWQiOiI0In0.oSctK8p6O2-0J4aBg9cgfKCpklPgrn8fndLdHBDLavc','2025-11-21 07:34:47.833468','2025-11-28 07:34:47.000000',4,'caa2923d3b4c4836bba5e9672b00c749'),
(228,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDMxNTM2NSwiaWF0IjoxNzYzNzEwNTY1LCJqdGkiOiI3NmE0ZGE2YjQ3YjI0YWM2YWIwMTJhYTk0NmJmOTIwYyIsInVzZXJfaWQiOiIxMCJ9.YePCLxc6XyVDoEBSFjOGoFcuJ2Y7PoMYgapcASJPrtI','2025-11-21 07:36:05.697592','2025-11-28 07:36:05.000000',NULL,'76a4da6b47b24ac6ab012aa946bf920c'),
(229,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDMyNjQzMSwiaWF0IjoxNzYzNzIxNjMxLCJqdGkiOiI1ZmY2MDdhYTJiOGM0NzAyYTUwMzEwMWFhYzEyY2Q4YyIsInVzZXJfaWQiOiI0In0.cT_Ds5eEA167d5ztTTz8w6jtRWP7S21ubrfE9qhDsI0','2025-11-21 10:40:31.845284','2025-11-28 10:40:31.000000',4,'5ff607aa2b8c4702a503101aac12cd8c'),
(230,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDMzNTc0NCwiaWF0IjoxNzYzNzMwOTQ0LCJqdGkiOiI3ZGUzY2ZmZDhlZTM0NjA1YjBjZTU2ZTNjNzBmN2Y0YiIsInVzZXJfaWQiOiIxOCJ9.8yo1ufOboDtRxwSUkjim9R6syqD9pq-0USxtexA5gQE','2025-11-21 13:15:44.076468','2025-11-28 13:15:44.000000',18,'7de3cffd8ee34605b0ce56e3c70f7f4b'),
(231,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDMzOTg4MiwiaWF0IjoxNzYzNzM1MDgyLCJqdGkiOiI5ZGZkMzY4N2NhMDE0NDhhYTM0OTk4OGNlNTU0NDQ5ZSIsInVzZXJfaWQiOiIxOCJ9.SYkiXTrrPPwVSwxkybocGG5oc2zO-8RIN5gvShp82n4','2025-11-21 14:24:42.438749','2025-11-28 14:24:42.000000',18,'9dfd3687ca01448aa349988ce554449e'),
(232,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDM0MDkyMiwiaWF0IjoxNzYzNzM2MTIyLCJqdGkiOiI1MTQ4M2Q2MTMyMGI0M2MxYWQ2OGVhMzkyMDI2NmMxOSIsInVzZXJfaWQiOiIxOCJ9.d_EnkROMpBQHqIpzWgfyXkrDkT9Sl_eKuo-Jup52eP8','2025-11-21 14:42:02.635575','2025-11-28 14:42:02.000000',18,'51483d61320b43c1ad68ea3920266c19'),
(233,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDM0MzY3MSwiaWF0IjoxNzYzNzM4ODcxLCJqdGkiOiIwZGMyN2M4ODFmM2I0MzI3OGU5OGY1OGUxOTBmOTQ5MiIsInVzZXJfaWQiOiI0In0.ZBgEy8S8OuV1uSK4p4JDpVeHLm_mLeaN4y-Dp5j5myA','2025-11-21 15:27:51.966651','2025-11-28 15:27:51.000000',4,'0dc27c881f3b43278e98f58e190f9492'),
(234,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDM0Mzc2OCwiaWF0IjoxNzYzNzM4OTY4LCJqdGkiOiI4ZGQ5ODljMGQyN2M0ZTBhYjkzMjRiZmU1OTc3YzNkNSIsInVzZXJfaWQiOiIxMyJ9.TBXnqTZTdHVM2heUCSZeS7HvCcOYM8Ws_ZvoXGckdVw','2025-11-21 15:29:28.277267','2025-11-28 15:29:28.000000',13,'8dd989c0d27c4e0ab9324bfe5977c3d5'),
(235,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDM4MjMxNywiaWF0IjoxNzYzNzc3NTE3LCJqdGkiOiIwYmEzYjQzOGYwZDM0MDE4OWE3NjcwZjkwNTMwMGM1OSIsInVzZXJfaWQiOiIxMyJ9.Bxb3Po77YYXJaWtAN3KyhEobavqYQYb0WxUEEWWUGWg','2025-11-22 02:11:57.847047','2025-11-29 02:11:57.000000',13,'0ba3b438f0d340189a7670f905300c59'),
(236,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDM4MjMyOCwiaWF0IjoxNzYzNzc3NTI4LCJqdGkiOiIwNDU0MmIzMWNkNDU0YmM0OTc2NTliZGQ0MjA2M2MwMCIsInVzZXJfaWQiOiI0In0.YgL0Sn0oOAPsIM7q-5YHkSAIyR1RalB4BrXJPt8erqA','2025-11-22 02:12:08.433004','2025-11-29 02:12:08.000000',4,'04542b31cd454bc497659bdd42063c00'),
(237,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDM4MzAwNywiaWF0IjoxNzYzNzc4MjA3LCJqdGkiOiI2NDEyMWU1MjQwYjc0MzJhOGI2YTEzNDdhZjIzMjA3MSIsInVzZXJfaWQiOiI0In0.D8VM5kgDT43Pf1KAqeK0pXnLe07MKTTACb7UszMvsCM','2025-11-22 02:23:27.221348','2025-11-29 02:23:27.000000',4,'64121e5240b7432a8b6a1347af232071'),
(238,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDQwODA4NywiaWF0IjoxNzYzODAzMjg3LCJqdGkiOiIzYmZmYzFhMDQ1MzI0ZDZkODQ4ODkwMmVkMTQ5NjY4MSIsInVzZXJfaWQiOiIxMyJ9.VFF2uBpQ2KggBC9dVT6HJPpvzjxjTvPm4mbZ-uQiwxM','2025-11-22 09:21:27.847563','2025-11-29 09:21:27.000000',13,'3bffc1a045324d6d8488902ed1496681'),
(239,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDQxNDk0MCwiaWF0IjoxNzYzODEwMTQwLCJqdGkiOiJjYTBmNzJkOTMxZmQ0YTM3OTljNTU5Njc0MmVkNTEzZCIsInVzZXJfaWQiOiI0In0.SK-9uFwpxwCNMkeM0l0vAP-wTuVO7iRpadAEYFyAfAg','2025-11-22 11:15:40.654933','2025-11-29 11:15:40.000000',4,'ca0f72d931fd4a3799c5596742ed513d'),
(240,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDQxOTk3NSwiaWF0IjoxNzYzODE1MTc1LCJqdGkiOiIyM2U5ZDE5MWJjMmU0NjViOTlhNmRjNWIxYTM0N2ZjYiIsInVzZXJfaWQiOiIxMyJ9.H66IHyYD4u3H1yx_c7S1lWMzf5CS6Jl9YaitWU03NKU','2025-11-22 12:39:35.670881','2025-11-29 12:39:35.000000',13,'23e9d191bc2e465b99a6dc5b1a347fcb'),
(241,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDQ2MzE3NywiaWF0IjoxNzYzODU4Mzc3LCJqdGkiOiJmMDU5ZjU2NDA4YjQ0ZTE5Yjk0MTNjN2VmN2FmMjEwMyIsInVzZXJfaWQiOiIxMyJ9.M4xH67JrCyQw0MkbLC4NAdmP9EG5obYWrL3dlZ-_2w8','2025-11-23 00:39:37.256639','2025-11-30 00:39:37.000000',13,'f059f56408b44e19b9413c7ef7af2103'),
(242,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDQ2NzkyMSwiaWF0IjoxNzYzODYzMTIxLCJqdGkiOiJjYzBlYmEwNjRhNGY0YWIyYjVjYWY3N2ViYjg0NmRlNyIsInVzZXJfaWQiOiI0In0.u9ppKcU3O4nnrpedG6J-5A2XrSNjanTen6l13qhx1k8','2025-11-23 01:58:41.364194','2025-11-30 01:58:41.000000',4,'cc0eba064a4f4ab2b5caf77ebb846de7'),
(243,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDQ5NTkxNywiaWF0IjoxNzYzODkxMTE3LCJqdGkiOiJkZmY2NGEyNzQ2ZDU0MGYzODZmYjk5MjkxMjRjNDczNyIsInVzZXJfaWQiOiIxMyJ9.qFNZYdVpb-n79rwmQKEVDRkufDkC3sXPkgx1AroXp4g','2025-11-23 09:45:17.355122','2025-11-30 09:45:17.000000',13,'dff64a2746d540f386fb9929124c4737'),
(244,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDUwNTI3NCwiaWF0IjoxNzYzOTAwNDc0LCJqdGkiOiI0YjQzM2YyMjVmNmQ0NWM4OWUxMDM0MGQzNmE3ODgwYiIsInVzZXJfaWQiOiI0In0.drfpdbb5fWbHLqUzTGMEkz7x1BYebPbPCo0auZgX89A','2025-11-23 12:21:14.839969','2025-11-30 12:21:14.000000',4,'4b433f225f6d45c89e10340d36a7880b'),
(245,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDUwODE4OSwiaWF0IjoxNzYzOTAzMzg5LCJqdGkiOiJjOWY1NTkwNmUxOGY0MzAzODM3Yzg1NmZmOWE4YWE3MyIsInVzZXJfaWQiOiI0In0.Doy1HicEWYCwZY3nCGrKDwhCVGwJw1NxuhrWfIzidX0','2025-11-23 13:09:49.870180','2025-11-30 13:09:49.000000',4,'c9f55906e18f4303837c856ff9a8aa73'),
(246,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDU1OTE1OSwiaWF0IjoxNzYzOTU0MzU5LCJqdGkiOiJhYTM2Y2E1NTNmY2U0NWM2YTY4MmI2NmM4OTM5MTNmOSIsInVzZXJfaWQiOiIxMyJ9.U9v4dcIJUT2yjuG1axxsGarjkuvdcTxPMdUpCger8hE','2025-11-24 03:19:19.779013','2025-12-01 03:19:19.000000',13,'aa36ca553fce45c6a682b66c893913f9'),
(247,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDU2Mjg4NiwiaWF0IjoxNzYzOTU4MDg2LCJqdGkiOiIyNWJlZDUwZWJhNDI0MDBiYWJmYzAyZTFmN2FmNDZmNCIsInVzZXJfaWQiOiI4In0.dC2nRXpEZHDgoYJTc2Es9tpWFkEY3g5omFNCa_eHyZE','2025-11-24 04:21:26.333549','2025-12-01 04:21:26.000000',8,'25bed50eba42400babfc02e1f7af46f4'),
(248,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDU2NjQ5OCwiaWF0IjoxNzYzOTYxNjk4LCJqdGkiOiJhMjE3NTgzMjlmYjY0MmVjODNlZDY1NGZmM2JiY2UxZCIsInVzZXJfaWQiOiI4In0.TbKLpI12FTE1EkRX8M__ejnia-g24eG3kGnkCb-BRYM','2025-11-24 05:21:38.707800','2025-12-01 05:21:38.000000',8,'a21758329fb642ec83ed654ff3bbce1d'),
(249,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDU5MTk4OSwiaWF0IjoxNzYzOTg3MTg5LCJqdGkiOiI2N2FjODEyZDk0ODQ0ZWZjOGFhODIyMTIzMDcwMzI2YSIsInVzZXJfaWQiOiIxMyJ9.TTwKPNJNJk2vkKKgIN_TO80T4yDL1eY7sy0JPccltHM','2025-11-24 12:26:29.713982','2025-12-01 12:26:29.000000',13,'67ac812d94844efc8aa822123070326a'),
(250,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDU5MjAwMiwiaWF0IjoxNzYzOTg3MjAyLCJqdGkiOiIyY2UwZTdjZWVjYmE0MmE3OWUyYmU0OGIyMmZlZThiMyIsInVzZXJfaWQiOiI0In0.Wve9etZwGlKXkWs0cHvlKGmdgyilom99_BQzJCHy5OA','2025-11-24 12:26:42.322617','2025-12-01 12:26:42.000000',4,'2ce0e7ceecba42a79e2be48b22fee8b3'),
(251,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDU5NDc2NSwiaWF0IjoxNzYzOTg5OTY1LCJqdGkiOiJiYzJmNGFlYTZlNTU0ZGEzOWRkYzZiM2U5MWY4ZGNmOSIsInVzZXJfaWQiOiI0In0.dhexM5YYHOk86vTnyMlphHTJztPyHR7DmVzfJiprRVk','2025-11-24 13:12:45.944500','2025-12-01 13:12:45.000000',4,'bc2f4aea6e554da39ddc6b3e91f8dcf9'),
(252,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDU5NDg0MiwiaWF0IjoxNzYzOTkwMDQyLCJqdGkiOiJhMmQ3YTQ3N2Y1NWM0Y2FhYWY1ZjE1NDAxZjA4MzkxYSIsInVzZXJfaWQiOiIxMyJ9.Mzq_S_9xDPJOVQPGPW1E4jBLTf_GNb4rgfydugap3r8','2025-11-24 13:14:02.969949','2025-12-01 13:14:02.000000',13,'a2d7a477f55c4caaaf5f15401f08391a'),
(253,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDYwMDM3OSwiaWF0IjoxNzYzOTk1NTc5LCJqdGkiOiI2YjVhYWYwZjhmNzQ0NGQ3ODBmOGM5YTlkYmI1M2VjMCIsInVzZXJfaWQiOiI0In0.4MIyfy2H9ousL9lpXd9woti8Ny0UxvE1kxiS1024In8','2025-11-24 14:46:19.524694','2025-12-01 14:46:19.000000',4,'6b5aaf0f8f7444d780f8c9a9dbb53ec0'),
(254,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDYzOTMwOCwiaWF0IjoxNzY0MDM0NTA4LCJqdGkiOiIwNjUzODgwNGU1YTc0MGJlYmU3NjliYTY4MTIyYjBiNyIsInVzZXJfaWQiOiI0In0.6VQPyC3gIV_TCYXk-Yc6j8zGjyKqHV6c-O1UUNkfcso','2025-11-25 01:35:08.558462','2025-12-02 01:35:08.000000',4,'06538804e5a740bebe769ba68122b0b7'),
(255,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDY1NDc1MSwiaWF0IjoxNzY0MDQ5OTUxLCJqdGkiOiJjYWE0OTljZDM0YWE0MzAzOWM3MGI3ZjdmYTI0YWFjNSIsInVzZXJfaWQiOiIyMiJ9.Nl8PulYYio3hIDk41SYXlZV1na9PRiNattjUzCjTWgY','2025-11-25 05:52:31.929900','2025-12-02 05:52:31.000000',22,'caa499cd34aa43039c70b7f7fa24aac5'),
(256,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDY1NDgwMCwiaWF0IjoxNzY0MDUwMDAwLCJqdGkiOiI2MDBjZjM2ZDc3Njk0MDIzOGZmNmUzYWI1N2FmZTYxMyIsInVzZXJfaWQiOiIyMiJ9.KLuvT3rblsQLCZwm-JuUfHCB0d7kwdK3gBefzioA4rM','2025-11-25 05:53:20.697999','2025-12-02 05:53:20.000000',22,'600cf36d776940238ff6e3ab57afe613'),
(257,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDY1Nzc4NywiaWF0IjoxNzY0MDUyOTg3LCJqdGkiOiJiZWZmYmM3ZTg0ZTU0YWQ4ODFhNWFkMTQxNjMzZTU2ZSIsInVzZXJfaWQiOiIyMiJ9.AtgZOllgP4PODJ2DN3xo030M8W7HSX4MsCdGavdMMGk','2025-11-25 06:43:07.416275','2025-12-02 06:43:07.000000',22,'beffbc7e84e54ad881a5ad141633e56e'),
(258,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDcyMDQzOSwiaWF0IjoxNzY0MTE1NjM5LCJqdGkiOiJhMjkyOWQ3NTA1YzE0NzVhOTBiNWZhNTQxMDU4MGVmNiIsInVzZXJfaWQiOiIxMyJ9.8ZIlDIkgT300uMUqDKVYH6sOKO6NH361tRMWa6xrJzA','2025-11-26 00:07:19.983993','2025-12-03 00:07:19.000000',13,'a2929d7505c1475a90b5fa5410580ef6'),
(259,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDcyMDQ1MCwiaWF0IjoxNzY0MTE1NjUwLCJqdGkiOiI4ZDA0YmRmZmVmNDg0MTU3ODE0ODZhYTA2YzI0MWZjZiIsInVzZXJfaWQiOiI0In0.t3cHZkkyXiPz4NgjKvTI3L6x2cx_zc90F2nxzN9WdY0','2025-11-26 00:07:30.532789','2025-12-03 00:07:30.000000',4,'8d04bdffef48415781486aa06c241fcf'),
(260,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDcyNDU2OCwiaWF0IjoxNzY0MTE5NzY4LCJqdGkiOiJkOTQ2NTNmNTNiMzI0N2U4OGI5NjkyYTMwZDQwOTRjYSIsInVzZXJfaWQiOiIxMCJ9.0XuHGXPv-uBLjhf1ar8oLutbGo9mS-RQ9vcGgjWZ9bU','2025-11-26 01:16:08.129695','2025-12-03 01:16:08.000000',NULL,'d94653f53b3247e88b9692a30d4094ca'),
(261,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDczMDQ1NiwiaWF0IjoxNzY0MTI1NjU2LCJqdGkiOiJhYTI3NmJkNmJkMTk0YjhlYWQ4MDhjOTk5ZTk5ZjgwYSIsInVzZXJfaWQiOiI0In0.Ywm-juYxA2AlZU9psQrgLBCEuFQpHhw2W1ubXnk66uY','2025-11-26 02:54:16.003689','2025-12-03 02:54:16.000000',4,'aa276bd6bd194b8ead808c999e99f80a'),
(262,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDczMzA0MSwiaWF0IjoxNzY0MTI4MjQxLCJqdGkiOiIwZDg4MWJkZDQzZjU0NGUwYWM1N2JmYTBlMjQxYjM5NCIsInVzZXJfaWQiOiIxMCJ9.H5ruZpYhJrlg9sUzMo17VpAzniE7_bJRvUMP4A7cPwE','2025-11-26 03:37:21.327540','2025-12-03 03:37:21.000000',NULL,'0d881bdd43f544e0ac57bfa0e241b394'),
(263,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDczNDYzNSwiaWF0IjoxNzY0MTI5ODM1LCJqdGkiOiI3ZjhmOTA1MjNkNzU0YWQ1OTU1YzY1ZTBlYmQyZDQwNiIsInVzZXJfaWQiOiIyMyJ9.TtI0QQCMMdQxUMiS5PPo0vxE-N0W0KH_KnI-4y84N4A','2025-11-26 04:03:55.852088','2025-12-03 04:03:55.000000',NULL,'7f8f90523d754ad5955c65e0ebd2d406'),
(264,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc0NDI5MiwiaWF0IjoxNzY0MTM5NDkyLCJqdGkiOiJlNDVkYTVjZjM1NzA0NmQ3OTNhYzc0ZDc4NmY1NTc2ZCIsInVzZXJfaWQiOiIxMyJ9.49L7bEoeAjE91izBBOvU63EpXThDA0LJob48eKC5owk','2025-11-26 06:44:52.640188','2025-12-03 06:44:52.000000',13,'e45da5cf357046d793ac74d786f5576d'),
(265,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc0NTA1NSwiaWF0IjoxNzY0MTQwMjU1LCJqdGkiOiI0ZTk0YmQzYjU1ZmI0NzM1OThkMWE2NzIwNGU4ZDI2YSIsInVzZXJfaWQiOiIxMyJ9.m8aK1NRKmYJQIp8IIWOTzKhaa-sRuBfhuCljlY7Jp3Q','2025-11-26 06:57:35.872824','2025-12-03 06:57:35.000000',13,'4e94bd3b55fb473598d1a67204e8d26a'),
(266,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc0NTE2MiwiaWF0IjoxNzY0MTQwMzYyLCJqdGkiOiJhNTkxOTFlYjUzMDk0NzY1OGM1MDU2MjI2MmU4MzE3YSIsInVzZXJfaWQiOiIxMyJ9.Ov1IfVvW8HhvBflS8fCabln_8hS3l-4YP-76BszNGH4','2025-11-26 06:59:22.128459','2025-12-03 06:59:22.000000',13,'a59191eb530947658c50562262e8317a'),
(267,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc0NTM1MCwiaWF0IjoxNzY0MTQwNTUwLCJqdGkiOiI5NDMwZTMxODQwY2Q0Y2Y5YTYyM2U2ODlhNWRkZTczYSIsInVzZXJfaWQiOiIxMyJ9.xibh4Oh6x4XVwOpMGSAIiTTpKR1jcR7Sb_Oy9ubzEIk','2025-11-26 07:02:30.429052','2025-12-03 07:02:30.000000',13,'9430e31840cd4cf9a623e689a5dde73a'),
(268,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc0NTUwMCwiaWF0IjoxNzY0MTQwNzAwLCJqdGkiOiIxYmFjYjYwZmVmMjY0NjlmOWExZmExMWZlMmVkODNhNyIsInVzZXJfaWQiOiIxMyJ9.qdZCwNVcSmKDfaevdl6tKrMsWzjK7XUOzs96YyNHFeQ','2025-11-26 07:05:00.276798','2025-12-03 07:05:00.000000',13,'1bacb60fef26469f9a1fa11fe2ed83a7'),
(269,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc0NTczMSwiaWF0IjoxNzY0MTQwOTMxLCJqdGkiOiJmNzE0MjVlYmEwMmU0MWMzOWEzNmY3ODkxZGRkMDM5MiIsInVzZXJfaWQiOiIxMyJ9.ruH-0hLN3B2rPne6FXC0VzniQKIk1X_VdsAZHzWbXXs','2025-11-26 07:08:51.517822','2025-12-03 07:08:51.000000',13,'f71425eba02e41c39a36f7891ddd0392'),
(270,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc1NDU0MCwiaWF0IjoxNzY0MTQ5NzQwLCJqdGkiOiJhY2IwODg2ZDA1N2U0ZGM2YjE2Y2E2NTNjMWUzZDIyMyIsInVzZXJfaWQiOiIxMyJ9.7gJ-Q7Xhr7QIdnRhqqOw7GvzuiJLx43VrTXhu0eOWyQ','2025-11-26 09:35:40.000535','2025-12-03 09:35:40.000000',13,'acb0886d057e4dc6b16ca653c1e3d223'),
(271,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc1NTI2MywiaWF0IjoxNzY0MTUwNDYzLCJqdGkiOiJlYzRkNjZkYWRhMzY0OGFhODcyNjJjMDVjN2E4N2M1YyIsInVzZXJfaWQiOiIxMCJ9.pQ0UDYzFtJv3FHl_Bg00ljJEaoF4mcsg16iamRftXVs','2025-11-26 09:47:43.441954','2025-12-03 09:47:43.000000',NULL,'ec4d66dada3648aa87262c05c7a87c5c'),
(272,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc1NTI4OCwiaWF0IjoxNzY0MTUwNDg4LCJqdGkiOiJlNWFkMTRiZGRjNTg0NmJkYjUyNmI0ZGZhZjgzZWFmZiIsInVzZXJfaWQiOiIxMyJ9.0x9QVpXMsE2flP0C2qgsfsIi8ODPztTRCAGXaRDe8Bg','2025-11-26 09:48:08.456341','2025-12-03 09:48:08.000000',13,'e5ad14bddc5846bdb526b4dfaf83eaff'),
(273,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc1NTM5NSwiaWF0IjoxNzY0MTUwNTk1LCJqdGkiOiJkMTVkN2M1MDJiMmU0YTYzYWE1Y2JhMTI2OTBlMWY4MCIsInVzZXJfaWQiOiIxMyJ9.JlQ74ZvdJw9xKAkH6eaJsoQaHVc3z98-EZdmtuFPxDE','2025-11-26 09:49:55.483515','2025-12-03 09:49:55.000000',13,'d15d7c502b2e4a63aa5cba12690e1f80'),
(274,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc1NTQxMywiaWF0IjoxNzY0MTUwNjEzLCJqdGkiOiJlYjNhMGMyMjU2YzA0YjFkYTZkYmU2YjFmMDZmZTZmMyIsInVzZXJfaWQiOiIyMyJ9.QrjywNnqb75drGFLEOAgDvAOJeNuyvN13JeKpUr38FI','2025-11-26 09:50:13.338863','2025-12-03 09:50:13.000000',NULL,'eb3a0c2256c04b1da6dbe6b1f06fe6f3'),
(275,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc1NTQzMSwiaWF0IjoxNzY0MTUwNjMxLCJqdGkiOiI4Y2Y2NDA5ZmZiMTU0NmMwYWMxZWI1MDQ3YzMxZWY1ZiIsInVzZXJfaWQiOiIxMCJ9.flangR94AY3SeW4V5ourpm1EP0Fbx0kNeCoPtD97ciY','2025-11-26 09:50:31.747460','2025-12-03 09:50:31.000000',NULL,'8cf6409ffb1546c0ac1eb5047c31ef5f'),
(276,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc1NTQ3MywiaWF0IjoxNzY0MTUwNjczLCJqdGkiOiJmNzlkNDhhNDNmMzI0MmI2YjIyZjA5YThlZTIxN2NkMyIsInVzZXJfaWQiOiIxMyJ9.4usj77eep3dumJo8ll50DzXR5a3DrR1tDzm3_lyRpwk','2025-11-26 09:51:13.543847','2025-12-03 09:51:13.000000',13,'f79d48a43f3242b6b22f09a8ee217cd3'),
(277,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc1NTUzMSwiaWF0IjoxNzY0MTUwNzMxLCJqdGkiOiI3YjkwZjg4ZDdjMTE0MzdkYTFlZDBhM2E4ZThmMzAxMyIsInVzZXJfaWQiOiIyOCJ9.71uDf_dEr4k42WVV5uD7YP1hyzGXVROCjnHx1S-v2Vc','2025-11-26 09:52:11.336133','2025-12-03 09:52:11.000000',28,'7b90f88d7c11437da1ed0a3a8e8f3013'),
(278,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc1NTU1NiwiaWF0IjoxNzY0MTUwNzU2LCJqdGkiOiIzNWU4ZmQzNTNhYzA0ZmNiYjNmN2U5M2Q4YjBhNmJjOCIsInVzZXJfaWQiOiIyOCJ9.kbUpRmMVXE8KKItZRAHsNrAU_blKMfVCt0nLxBr2_TQ','2025-11-26 09:52:36.622984','2025-12-03 09:52:36.000000',28,'35e8fd353ac04fcbb3f7e93d8b0a6bc8'),
(279,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc1NTYwMiwiaWF0IjoxNzY0MTUwODAyLCJqdGkiOiI4NWM1MjUxNGU3MDQ0NTkzYTk3NmRlOTY4YzQwMTU3NSIsInVzZXJfaWQiOiIyMyJ9.BznPyfTurXFmL4lG7OVoQNALSLImlC-wfcrwBr1hnRA','2025-11-26 09:53:22.987196','2025-12-03 09:53:22.000000',NULL,'85c52514e7044593a976de968c401575'),
(280,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc1NTY5NiwiaWF0IjoxNzY0MTUwODk2LCJqdGkiOiJiZDlkMTM4MTU1Mzc0MzVkOTUyMzQ1MGU5MWNmYmZlMSIsInVzZXJfaWQiOiIxMyJ9.RkFm1SnJYt_8JK-4V-rCrDnpriUsekDDCreS3NWlM5g','2025-11-26 09:54:56.078596','2025-12-03 09:54:56.000000',13,'bd9d13815537435d9523450e91cfbfe1'),
(281,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc1NzMzNCwiaWF0IjoxNzY0MTUyNTM0LCJqdGkiOiI4ZTI4NTVlZmJjNmI0MmQ4YTYxMzUzZDdhNTA0YmU4NSIsInVzZXJfaWQiOiIxMyJ9.O3izcw9DvENLa5MSYeoZ0CQ0qHINIUdfzzbz3xX6pdM','2025-11-26 10:22:14.642081','2025-12-03 10:22:14.000000',13,'8e2855efbc6b42d8a61353d7a504be85'),
(282,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc1NzM2NiwiaWF0IjoxNzY0MTUyNTY2LCJqdGkiOiIxYWQyM2I2MWFlYzM0YjYxOGJjMzk0YmZlMTc1NjEyNyIsInVzZXJfaWQiOiIyOCJ9.r5SSY5QIHpQjJQ_HpyytIdl4AnUsaSVQ1MOBlQNw-fw','2025-11-26 10:22:46.684840','2025-12-03 10:22:46.000000',28,'1ad23b61aec34b618bc394bfe1756127'),
(283,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc1NzQxNSwiaWF0IjoxNzY0MTUyNjE1LCJqdGkiOiJmNzRkNjBhMTg1YjE0ZDU0OWNjMDZjNDVkYzE2ZTcyNyIsInVzZXJfaWQiOiIxMyJ9.WDY5OTNx5akWqm8QoTUit4AQ7mJl8zfyRXHUyC3ADfM','2025-11-26 10:23:35.170427','2025-12-03 10:23:35.000000',13,'f74d60a185b14d549cc06c45dc16e727'),
(284,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc1NzU3NywiaWF0IjoxNzY0MTUyNzc3LCJqdGkiOiIzNWNmMzAzMDQ2YWU0OTNiYjMyNTUxMTZjNGJkMTIwNiIsInVzZXJfaWQiOiI0In0.AjmVWLZN2hFYEhWWfPkeY-cp87lvaGIlnM49HrMKP2k','2025-11-26 10:26:17.033865','2025-12-03 10:26:17.000000',4,'35cf303046ae493bb3255116c4bd1206'),
(285,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc1Nzc0OCwiaWF0IjoxNzY0MTUyOTQ4LCJqdGkiOiIwYjdkZGIwZGJkY2M0ZmI0YjAxNzJmYjAxZDZiZGU2NiIsInVzZXJfaWQiOiIyOCJ9.kpCq08-ksunCpZPlTuiYgxg_fSicEtAHlQlAaY2OI0o','2025-11-26 10:29:08.645881','2025-12-03 10:29:08.000000',28,'0b7ddb0dbdcc4fb4b0172fb01d6bde66'),
(286,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc2NTk2NywiaWF0IjoxNzY0MTYxMTY3LCJqdGkiOiJmNzEzNjE3N2E4N2E0YzE0ODg5YTI4ZDYxOGQ0MmMxYiIsInVzZXJfaWQiOiIxMyJ9.5yCv2ikYCA_ln6Lwz75eRsGjknuHaoW9kA0tS4B7j3c','2025-11-26 12:46:07.850403','2025-12-03 12:46:07.000000',13,'f7136177a87a4c14889a28d618d42c1b'),
(287,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc2NjE3OCwiaWF0IjoxNzY0MTYxMzc4LCJqdGkiOiIxMzAwM2QzOWY0OGM0NDI4YmQ4MTM0OGI1ZjRjY2QyYiIsInVzZXJfaWQiOiIyOCJ9.6ZGdGrc5g4lhMP9rE6di2SxjNRMlMjAAkQaZl1iQbvk','2025-11-26 12:49:38.680436','2025-12-03 12:49:38.000000',28,'13003d39f48c4428bd81348b5f4ccd2b'),
(288,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc2NjE5NCwiaWF0IjoxNzY0MTYxMzk0LCJqdGkiOiIzNGQ1MGJkNDAyZWY0MjI2YWVlN2ZmMTc3YzdhN2FmYSIsInVzZXJfaWQiOiI0In0.A-hdBgoXIlZc0VduQ9WTpUBQ8ql--ArpIvRBfGLGkvI','2025-11-26 12:49:54.193410','2025-12-03 12:49:54.000000',4,'34d50bd402ef4226aee7ff177c7a7afa'),
(289,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDc2NjM3MCwiaWF0IjoxNzY0MTYxNTcwLCJqdGkiOiI4Yzk5ZGZiMTFmZmQ0NTdhOWIzYzAzYjNjNjJjMGQ3ZiIsInVzZXJfaWQiOiIxMyJ9.X2-dx_gHRj_meO-0Bgilu1_gAJnbVD9VY_NXwqEV_bQ','2025-11-26 12:52:50.950170','2025-12-03 12:52:50.000000',13,'8c99dfb11ffd457a9b3c03b3c62c0d7f'),
(290,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDgxMDA2MCwiaWF0IjoxNzY0MjA1MjYwLCJqdGkiOiJhZWMxY2JmNjY3NWU0NGI3OGI0MDUzZmIzM2EzYWU4YSIsInVzZXJfaWQiOiIxMyJ9.--NHt76Ev0jTNAZPSJq51-kpXMR7A6edRf9iHXGdT2E','2025-11-27 01:01:00.958797','2025-12-04 01:01:00.000000',13,'aec1cbf6675e44b78b4053fb33a3ae8a'),
(291,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDgxMDM2MCwiaWF0IjoxNzY0MjA1NTYwLCJqdGkiOiJjNTE4MGFiMTBhODU0OGI3OTE4MDJmYmJlODQxYTQzMCIsInVzZXJfaWQiOiIyOCJ9.bDlFVU4JMK5pUZods0E_HkQVifkNE3lhsv_ZI-euVrM','2025-11-27 01:06:00.106284','2025-12-04 01:06:00.000000',28,'c5180ab10a8548b791802fbbe841a430'),
(292,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDgxMDU5NiwiaWF0IjoxNzY0MjA1Nzk2LCJqdGkiOiIyNjcxNmNkYmQzNTQ0OTBlYjhjOTEzZjU3MWEzZWVmNSIsInVzZXJfaWQiOiIxMyJ9.4KVWQFNtPzpAXFSKiLm_Ums-1kG8e7p-P4SN9dTIXjM','2025-11-27 01:09:56.060547','2025-12-04 01:09:56.000000',13,'26716cdbd354490eb8c913f571a3eef5'),
(293,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDgyNTI3OSwiaWF0IjoxNzY0MjIwNDc5LCJqdGkiOiJkMGJmYzJiMmNlZjQ0YTRmOWMzYjJkZTZlN2Y0ZDAyNyIsInVzZXJfaWQiOiIxMyJ9.zZc1RtY4CgNS6I_DAtj4OR-NCj7n-X_uIE4pADtQcck','2025-11-27 05:14:39.755215','2025-12-04 05:14:39.000000',13,'d0bfc2b2cef44a4f9c3b2de6e7f4d027'),
(294,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDgyNTcwMCwiaWF0IjoxNzY0MjIwOTAwLCJqdGkiOiIwNDFlNzJjODRjMGM0ZmVmYmViOTU4NjlhNDY1Y2UxNyIsInVzZXJfaWQiOiIyOCJ9.FOUdWPmMUuKxMArKrVtUT6EwREoXvu3Q_hfnR8qasbc','2025-11-27 05:21:40.130262','2025-12-04 05:21:40.000000',28,'041e72c84c0c4fefbeb95869a465ce17'),
(295,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDgyNTczOSwiaWF0IjoxNzY0MjIwOTM5LCJqdGkiOiJlMDcxMzc2OWIyZjI0NTVjYWUxZDg1NWU4MWU4YzkwOCIsInVzZXJfaWQiOiIxMyJ9.u-RkHg98Ynv9Fyo7xV-y6gpwf6XH8HbVVc2QekbpzmM','2025-11-27 05:22:19.966351','2025-12-04 05:22:19.000000',13,'e0713769b2f2455cae1d855e81e8c908'),
(296,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDgyNTkwNywiaWF0IjoxNzY0MjIxMTA3LCJqdGkiOiJkMzAyZjRjMGRiNWQ0NDQ0ODVlZTY3N2I4N2JmZWFhNSIsInVzZXJfaWQiOiIyOSJ9.xYUTjCOkEJl4MnmyMKkKQb-fGS7a4bAwaAwabq6wteU','2025-11-27 05:25:07.326273','2025-12-04 05:25:07.000000',NULL,'d302f4c0db5d444485ee677b87bfeaa5'),
(297,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDgyNTk1NywiaWF0IjoxNzY0MjIxMTU3LCJqdGkiOiI3YWNkNmI0OWJjMjU0YTBkOTdmNmQyMjY4M2JkYzRmNiIsInVzZXJfaWQiOiIyOSJ9.XvJBzIyhFE75k7Xs1RABGtaMsu3vFWiP0kx6jRpG3wM','2025-11-27 05:25:57.245096','2025-12-04 05:25:57.000000',NULL,'7acd6b49bc254a0d97f6d22683bdc4f6'),
(298,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDgyNzA2MywiaWF0IjoxNzY0MjIyMjYzLCJqdGkiOiJhYjVjY2NjZDFiY2I0Njc0YWJmNTFjNmEzZTMwMjY4OCIsInVzZXJfaWQiOiIyOSJ9.a2fjiJKmTr4-3Fls5tH--gevjfNxrJOoukskxDS60WE','2025-11-27 05:44:23.605116','2025-12-04 05:44:23.000000',NULL,'ab5ccccd1bcb4674abf51c6a3e302688'),
(299,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDgyNzcxNSwiaWF0IjoxNzY0MjIyOTE1LCJqdGkiOiJhYjVjNmFlMjU2NDQ0MDZhYTlkODJlYTRjOTQwMmI5ZCIsInVzZXJfaWQiOiIxMyJ9.GvF_i1dGgTAUvzUD4csbSpmy5lav0wsxHoP3sWuo1kw','2025-11-27 05:55:15.348676','2025-12-04 05:55:15.000000',13,'ab5c6ae25644406aa9d82ea4c9402b9d'),
(300,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDgyOTA4NSwiaWF0IjoxNzY0MjI0Mjg1LCJqdGkiOiI3ODcwYmZlMTM0NzQ0Yzk1YmMwZDJhNGJhMzY5NzRlMCIsInVzZXJfaWQiOiI0In0.VoVqQQ28uwRpzI6yDD_-DPs6dOJ0uI0cehWFPKqCD7w','2025-11-27 06:18:05.861394','2025-12-04 06:18:05.000000',4,'7870bfe134744c95bc0d2a4ba36974e0'),
(301,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDgzMzgxNSwiaWF0IjoxNzY0MjI5MDE1LCJqdGkiOiJmNTIxOGFkOWQyMTI0MmZiODQyMTZhMThmYjIzNTM4OCIsInVzZXJfaWQiOiIxMyJ9.STkRdMsc5JQf1XJ7PNUOF5YpnPKcUDCXYkaxhdMY-Kk','2025-11-27 07:36:55.748074','2025-12-04 07:36:55.000000',13,'f5218ad9d21242fb84216a18fb235388'),
(302,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDgzNDYzMCwiaWF0IjoxNzY0MjI5ODMwLCJqdGkiOiI2Y2QzNTQzYzY4MTk0ZDYzOTFjOGQwOWU5YjE1M2MxNyIsInVzZXJfaWQiOiIzMCJ9.XtHsFv80lpP09VDdB8Egbks5QHlMzkjkJfnWeHPPnas','2025-11-27 07:50:30.189194','2025-12-04 07:50:30.000000',NULL,'6cd3543c68194d6391c8d09e9b153c17'),
(303,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDgzNDczOSwiaWF0IjoxNzY0MjI5OTM5LCJqdGkiOiI0NzQ0ZWZiNTFkNzI0NGVkYjAyZmI5NzQ3YTFhYjAwOSIsInVzZXJfaWQiOiIzMCJ9.3HmGPkL3KT3DavMa6Dn9p3PyzD1AnUb41Mu8j71jGBM','2025-11-27 07:52:19.667629','2025-12-04 07:52:19.000000',NULL,'4744efb51d7244edb02fb9747a1ab009'),
(304,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDgzNTAxOSwiaWF0IjoxNzY0MjMwMjE5LCJqdGkiOiJlNzZkOGM4MTg2NTg0NjdkOGM3NmFhMDMwZWEwODI0YyIsInVzZXJfaWQiOiIxMyJ9.wFhTEFVfZx3kXOyp3z6e3xJiGNGN3tawMk3JWlnZc0Y','2025-11-27 07:56:59.685987','2025-12-04 07:56:59.000000',13,'e76d8c818658467d8c76aa030ea0824c'),
(305,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDgzNTE0MCwiaWF0IjoxNzY0MjMwMzQwLCJqdGkiOiI4MDJhMTNhYzMwODM0YTVlODk2YWU3ODFmYmFkZGNhZiIsInVzZXJfaWQiOiIzMCJ9.lh3PMLdeE8rDMU3G0_r2kR2BgzjTYNk7Pk3E4cptktI','2025-11-27 07:59:00.762079','2025-12-04 07:59:00.000000',NULL,'802a13ac30834a5e896ae781fbaddcaf'),
(306,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDgzOTIxNywiaWF0IjoxNzY0MjM0NDE3LCJqdGkiOiJlNzFhNTQzZDVjOGU0NTM2ODAwMjMyODM0M2NkNjJhOSIsInVzZXJfaWQiOiI0In0.qiRoXPgAYJfnQCQFlbPxiZ3lnNKeiJfw8glYekFCjwI','2025-11-27 09:06:57.525403','2025-12-04 09:06:57.000000',4,'e71a543d5c8e45368002328343cd62a9'),
(307,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDg0MzM0MywiaWF0IjoxNzY0MjM4NTQzLCJqdGkiOiJkOGU5MmMxZGUzNGQ0ZTY3ODM5YjgwN2UyYTJkNmFhZSIsInVzZXJfaWQiOiIxMyJ9.eXkU9AigcD7JcHCzagErLQ0mKEXJZYhGRXMry4yJ9FM','2025-11-27 10:15:43.934529','2025-12-04 10:15:43.000000',13,'d8e92c1de34d4e67839b807e2a2d6aae'),
(308,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDg0NTc4NiwiaWF0IjoxNzY0MjQwOTg2LCJqdGkiOiJlYmY3NmM3YzRjODE0MDE5OWNlMWRlNzZmMzgwNGE5MyIsInVzZXJfaWQiOiIxMyJ9.-Ksx9b_Qbs1rcSQVmoJ8VyvHyUPQuA51u3gXk9JwLsY','2025-11-27 10:56:26.138826','2025-12-04 10:56:26.000000',13,'ebf76c7c4c8140199ce1de76f3804a93'),
(309,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDg0NTg0NCwiaWF0IjoxNzY0MjQxMDQ0LCJqdGkiOiJmZjJhMjEzYWY5NjM0ZjdiYmE0YmMyNmJhOThlOTRjYiIsInVzZXJfaWQiOiI0In0.2VjXsgaoGuuoABYIjTgD1pSPNOwWphTLhD-ELzWAprA','2025-11-27 10:57:24.585796','2025-12-04 10:57:24.000000',4,'ff2a213af9634f7bba4bc26ba98e94cb'),
(310,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDg0NjA3MCwiaWF0IjoxNzY0MjQxMjcwLCJqdGkiOiIzNjYwYmY3NjVmZTE0M2YwODBlMTFkNTFjZGE0Y2IxZSIsInVzZXJfaWQiOiIyOCJ9.tvJCf7U_QZmzg_3VHG9zOBIo0UPZV182DVn7hT-mC08','2025-11-27 11:01:10.372523','2025-12-04 11:01:10.000000',28,'3660bf765fe143f080e11d51cda4cb1e'),
(311,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDg0NjM0MCwiaWF0IjoxNzY0MjQxNTQwLCJqdGkiOiI1NDNkYmVmZjg5NzQ0N2QxOWFlZDMzNmIzNmI3ZmU2MCIsInVzZXJfaWQiOiIxMyJ9.Vs7KxFHcfnUPHcJSl4O7xq1U4dKs5Djatq1ByrN0nnc','2025-11-27 11:05:40.352469','2025-12-04 11:05:40.000000',13,'543dbeff897447d19aed336b36b7fe60'),
(312,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDg0ODgxMCwiaWF0IjoxNzY0MjQ0MDEwLCJqdGkiOiI3NGZmZTJkY2IxMTI0ZTY4OTg2ZTg2MjQ4MWFlNWE0NyIsInVzZXJfaWQiOiIxMyJ9.8ii_VPQV9eQWvGSTiBD8tQYihwxIRJvUbOGxnDbY9cE','2025-11-27 11:46:50.824979','2025-12-04 11:46:50.000000',13,'74ffe2dcb1124e68986e862481ae5a47'),
(313,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDg0ODg0NiwiaWF0IjoxNzY0MjQ0MDQ2LCJqdGkiOiJjNWYzODU1OTE2MWQ0YmY1YjJlMGY3MjM4MzgxMmU3YiIsInVzZXJfaWQiOiI0In0.MerAcBUsFQ8hnqVCOegDisZsBd_Lq3zJh9firen4E7E','2025-11-27 11:47:26.884911','2025-12-04 11:47:26.000000',4,'c5f38559161d4bf5b2e0f72383812e7b'),
(314,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDg0ODkxNSwiaWF0IjoxNzY0MjQ0MTE1LCJqdGkiOiI0NzIzZjcwMzk0N2I0NGY1OTM0YmQ5MTU2ODliZmUyZCIsInVzZXJfaWQiOiIxMyJ9.kTryNXaI1gSz4dpYRadhooct1f2nNJ-xuW39sfSDCSI','2025-11-27 11:48:35.466749','2025-12-04 11:48:35.000000',13,'4723f703947b44f5934bd915689bfe2d'),
(315,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDg0OTExNSwiaWF0IjoxNzY0MjQ0MzE1LCJqdGkiOiIwOTdmNjdjZDNmNjY0MjdhOWE5ZDU2MGE3ZTlhNDg1NSIsInVzZXJfaWQiOiIyOCJ9.GeHbhGcSTXEmJmBbPByU0SDblvN6s8wppTtczbFe0SQ','2025-11-27 11:51:55.074142','2025-12-04 11:51:55.000000',28,'097f67cd3f66427a9a9d560a7e9a4855'),
(316,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDg5NDQyNywiaWF0IjoxNzY0Mjg5NjI3LCJqdGkiOiJmMGY3YjRkNzYwM2M0NzJiYmU5ZWE4NjJmZDU1OTE3NyIsInVzZXJfaWQiOiIxMyJ9.4_RxNhUDg9ppYDCnjzhIgVFUmhPBq9lKySBigu7YrS4','2025-11-28 00:27:07.188887','2025-12-05 00:27:07.000000',13,'f0f7b4d7603c472bbe9ea862fd559177'),
(317,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwMDQ1NSwiaWF0IjoxNzY0Mjk1NjU1LCJqdGkiOiIyYzI4MWVlZDFlMGI0MzQ4OTgwNGY3YjAwODBjYWFmNiIsInVzZXJfaWQiOiIxMCJ9.vIsmplnq4jy-AEUshqNfSy6KfeV2lU_24JuwvumC_m0','2025-11-28 02:07:35.010225','2025-12-05 02:07:35.000000',NULL,'2c281eed1e0b43489804f7b0080caaf6'),
(318,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwMDgwNSwiaWF0IjoxNzY0Mjk2MDA1LCJqdGkiOiJkMGJmZmVjMGMyMTI0MzJhYjg3YzY0ZjNiMThhZGRhNSIsInVzZXJfaWQiOiIyIn0.zFzT9BuuLg2I_ee6rADGUCqCHJVkygA9U89zXgivksw','2025-11-28 02:13:25.910728','2025-12-05 02:13:25.000000',2,'d0bffec0c212432ab87c64f3b18adda5'),
(319,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwMDkxNiwiaWF0IjoxNzY0Mjk2MTE2LCJqdGkiOiIwYWUxYTY3NWExYjY0NzQ1ODRhODgwNDA3NDgxNWM0NiIsInVzZXJfaWQiOiIxMyJ9.I0g6FtJIPTsdm4z8JrKw1YHwtwSo7ylPuYYsmW9Ra2o','2025-11-28 02:15:16.771011','2025-12-05 02:15:16.000000',13,'0ae1a675a1b6474584a8804074815c46'),
(320,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwMDk0MCwiaWF0IjoxNzY0Mjk2MTQwLCJqdGkiOiI0ZDJjY2JkMWIyNTE0MTAxOTZiYWU0MDVlNmQ4NThkNyIsInVzZXJfaWQiOiIxMCJ9.IupD2tBjoV4PIJpYK_RaLrFOjfymGVuRWch5B2Yxgxg','2025-11-28 02:15:40.300363','2025-12-05 02:15:40.000000',NULL,'4d2ccbd1b251410196bae405e6d858d7'),
(321,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwMTAyMywiaWF0IjoxNzY0Mjk2MjIzLCJqdGkiOiIzMjkzYTk2ODY1NDc0MGVjOWZlYTg2NTc2OTkyNTIwZCIsInVzZXJfaWQiOiIxMCJ9.nwWdRa-hw95Z2BI0uqBboiSLMQUb8BFRaPKuEXUYZVo','2025-11-28 02:17:03.485978','2025-12-05 02:17:03.000000',NULL,'3293a968654740ec9fea86576992520d'),
(322,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwMTI2OSwiaWF0IjoxNzY0Mjk2NDY5LCJqdGkiOiI1YTc3YzYxZjIyOGQ0OGUyODE5ZWMzMjQ1OTgxMGVkMCIsInVzZXJfaWQiOiIxMCJ9.ciOaPOR7Tdrx_gAGf7zx2gFgjbZn6mEnThuXs2cuzB0','2025-11-28 02:21:09.811707','2025-12-05 02:21:09.000000',NULL,'5a77c61f228d48e2819ec32459810ed0'),
(323,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwMTI4OCwiaWF0IjoxNzY0Mjk2NDg4LCJqdGkiOiIwM2JlOGRjOGY5ZDc0MGMxODYzM2VjNTVhYzZlZmQzYiIsInVzZXJfaWQiOiIzMSJ9.1bGuvhKFUYhkRFnDRTn2WSEHn_eLQfAwhVD-OUpUDS8','2025-11-28 02:21:28.771080','2025-12-05 02:21:28.000000',NULL,'03be8dc8f9d740c18633ec55ac6efd3b'),
(324,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwMjQwNiwiaWF0IjoxNzY0Mjk3NjA2LCJqdGkiOiI3ZTM0NTAzOGI0NTY0ZDViODA0YTFkNzZlNGRhNTc5MCIsInVzZXJfaWQiOiIxMCJ9.Gl8_0g7_0bKe0G6WBm16a2S0KtZBZoSl9Nz7ohLgFNc','2025-11-28 02:40:06.121713','2025-12-05 02:40:06.000000',NULL,'7e345038b4564d5b804a1d76e4da5790'),
(325,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwMjY0NywiaWF0IjoxNzY0Mjk3ODQ3LCJqdGkiOiI4NjU4NGY3NzIxYzQ0MTlkOTcwOWYzNzlkM2E1OGJlNyIsInVzZXJfaWQiOiIxMyJ9.wX2uJ8v8KMKpebGP3McL142CBXg9Jyu-M-sAKHNAnMM','2025-11-28 02:44:07.788725','2025-12-05 02:44:07.000000',13,'86584f7721c4419d9709f379d3a58be7'),
(326,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwMjcyNywiaWF0IjoxNzY0Mjk3OTI3LCJqdGkiOiJjOWY4OWRhMGU4ODg0MDgyODAzNTY5YmE3MGJmZTk2MyIsInVzZXJfaWQiOiI0In0.k5MpLAab2uRPqkTjXkrJWtlJ8FYi_TPdRDFcHlgdDrY','2025-11-28 02:45:27.372810','2025-12-05 02:45:27.000000',4,'c9f89da0e8884082803569ba70bfe963'),
(327,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwMjc1NiwiaWF0IjoxNzY0Mjk3OTU2LCJqdGkiOiI2MDQ3ZTdiZjJjMmY0MjllYTY1N2YxMGQ2MjU4Njc5NSIsInVzZXJfaWQiOiIyIn0._eDNq64Wm4F500g5eNm04TuBqg9cwsn0GlEe5IR72js','2025-11-28 02:45:56.620244','2025-12-05 02:45:56.000000',2,'6047e7bf2c2f429ea657f10d62586795'),
(328,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwMjgxNywiaWF0IjoxNzY0Mjk4MDE3LCJqdGkiOiI3Mjg5NmVhOWYwMjM0ZWYzYjZjOGVjYTIzNmExOTJiNiIsInVzZXJfaWQiOiIxMyJ9.BIvIOnlZB_7Vxc3sQ1PGJmDz-1vsODyU6bPWDqmrzAU','2025-11-28 02:46:57.269409','2025-12-05 02:46:57.000000',13,'72896ea9f0234ef3b6c8eca236a192b6'),
(329,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwMzM4OSwiaWF0IjoxNzY0Mjk4NTg5LCJqdGkiOiIxMGVhOWQ5ODdhZGQ0YTRkYTQ4NTczOTRjZTQwNmUyNiIsInVzZXJfaWQiOiIxMyJ9.t7SDa8VVku4o3qdnXzoPulS384o3ve5vaGvb3HfZp3g','2025-11-28 02:56:29.348292','2025-12-05 02:56:29.000000',13,'10ea9d987add4a4da4857394ce406e26'),
(330,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwMzY1MywiaWF0IjoxNzY0Mjk4ODUzLCJqdGkiOiI2YmVjYzNhN2U0MTg0MzkyOGRhM2YxYTIyZDQwZDNhZiIsInVzZXJfaWQiOiIxMCJ9.NDGokDgEG7phcaVioxLu8H86QaxGmeoxcrnVF0rd8dw','2025-11-28 03:00:53.965929','2025-12-05 03:00:53.000000',NULL,'6becc3a7e41843928da3f1a22d40d3af'),
(331,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwMzczMiwiaWF0IjoxNzY0Mjk4OTMyLCJqdGkiOiI5NmM4OWVhMWM2MzI0NjExODA2YWNlNDNlNWNkMzRhZSIsInVzZXJfaWQiOiI0In0.ekT83OE-_h6FMagXZBAYhsA6oxufLST5z1rKwerEIkc','2025-11-28 03:02:12.262330','2025-12-05 03:02:12.000000',4,'96c89ea1c6324611806ace43e5cd34ae'),
(332,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwMzk3NCwiaWF0IjoxNzY0Mjk5MTc0LCJqdGkiOiI2OTQxYThjYzE1YmM0YWQzOGQwYjRlMDk4ODlhMzVlOSIsInVzZXJfaWQiOiIxMyJ9.g17PzP-L5dD6Y8bvvxpUk1haUCzFSx35s3G84ensNMc','2025-11-28 03:06:14.871609','2025-12-05 03:06:14.000000',13,'6941a8cc15bc4ad38d0b4e09889a35e9'),
(333,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwNDI0OSwiaWF0IjoxNzY0Mjk5NDQ5LCJqdGkiOiJmMWZiOWQyMTE1ZjU0MGEwOTU0YjQ4OTcwMjUxYTBmZSIsInVzZXJfaWQiOiIxMyJ9.9hjXZG6-6Qf_Mlttj1kt8WpVCtN8shHs-OQXdgik3No','2025-11-28 03:10:49.420555','2025-12-05 03:10:49.000000',13,'f1fb9d2115f540a0954b48970251a0fe'),
(334,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkwOTk4NywiaWF0IjoxNzY0MzA1MTg3LCJqdGkiOiJkODI5MjQ2YmYzZjU0NGExOGI2ZmQ4MjVlYTk5NmFmMSIsInVzZXJfaWQiOiIzMiJ9.EbXYnUM4BnSmbcMOWFjZG4dqJgV8N4WCwLrFko-aBTY','2025-11-28 04:46:27.085571','2025-12-05 04:46:27.000000',32,'d829246bf3f544a18b6fd825ea996af1'),
(335,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkxMDE0NCwiaWF0IjoxNzY0MzA1MzQ0LCJqdGkiOiI1MTdiM2Y3ZDliNjc0NWY4YTdmNGVhNmZjZTE3YjY0NiIsInVzZXJfaWQiOiIzMiJ9.VCuCbDEITzE_OxArEvQSOzqEKfsKn2KX1hXuyb-lLg8','2025-11-28 04:49:04.512701','2025-12-05 04:49:04.000000',32,'517b3f7d9b6745f8a7f4ea6fce17b646'),
(336,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkxMDc5NCwiaWF0IjoxNzY0MzA1OTk0LCJqdGkiOiI3ZDQ3M2U5YmRlNTQ0ODM3OTI2ZDliYjNkZWVmMTA0NCIsInVzZXJfaWQiOiIzMiJ9.JNRQMfAkmOhboXbF_Gymtd2_NjXP3YD0Cj98GSBUe9E','2025-11-28 04:59:54.784792','2025-12-05 04:59:54.000000',32,'7d473e9bde544837926d9bb3deef1044'),
(337,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkxMTI3MSwiaWF0IjoxNzY0MzA2NDcxLCJqdGkiOiIzOGNjNjVlYzA3OTg0NmVjODZmYTlmYmE4Y2EyZmQ3MCIsInVzZXJfaWQiOiI0In0.84p3DSagv7vU1ZVEDmv72vGWUj0Mj7Z5Acvtyi9MZuU','2025-11-28 05:07:51.345545','2025-12-05 05:07:51.000000',4,'38cc65ec079846ec86fa9fba8ca2fd70'),
(338,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkxNDAxOSwiaWF0IjoxNzY0MzA5MjE5LCJqdGkiOiIwN2ZmMzAwN2E2ZTI0MWJkYjU3YjVkNDgxZGM0OWNlZSIsInVzZXJfaWQiOiIzMyJ9.A4uDiPXDnCI_7NHt_POOCtiga070h8Np-kINhv3eckw','2025-11-28 05:53:39.738240','2025-12-05 05:53:39.000000',NULL,'07ff3007a6e241bdb57b5d481dc49cee'),
(339,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkxNDAzMCwiaWF0IjoxNzY0MzA5MjMwLCJqdGkiOiJjN2NhNzA1OTVkNWE0Zjg5YjdlZjA2YjdiMmZjMGNjNiIsInVzZXJfaWQiOiIzMyJ9.ZifIZK8wQe0s0X9o03TY3CX2DQscgesCg0jCaOlvIS0','2025-11-28 05:53:50.892004','2025-12-05 05:53:50.000000',NULL,'c7ca70595d5a4f89b7ef06b7b2fc0cc6'),
(340,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkxNTUwNCwiaWF0IjoxNzY0MzEwNzA0LCJqdGkiOiIzMjE2OTZlY2JiNTM0ZWU2YTQ2YTBiNmExYjFhMDQ5NiIsInVzZXJfaWQiOiIzMyJ9.S7RO9AZZY-JdzlNr1uQ8Mp6XPPvaiA5m9bh9C1xsXHM','2025-11-28 06:18:24.425532','2025-12-05 06:18:24.000000',NULL,'321696ecbb534ee6a46a0b6a1b1a0496'),
(341,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkxNTU0OSwiaWF0IjoxNzY0MzEwNzQ5LCJqdGkiOiJkOTNkN2U0OTRjOTg0NjdmODFlZWUwYmNmMTNkMzA1MCIsInVzZXJfaWQiOiIzMyJ9.6QjWv55BnCfFlaxzlpM_zQD5fkLmAMhLvAepRvWn0Qc','2025-11-28 06:19:09.021059','2025-12-05 06:19:09.000000',NULL,'d93d7e494c98467f81eee0bcf13d3050'),
(342,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkxNTU3OCwiaWF0IjoxNzY0MzEwNzc4LCJqdGkiOiIyN2ZhOGRiNjFlNDg0MjYxYmRmZTMxMmNhODZjNTFlMyIsInVzZXJfaWQiOiIzNCJ9.9GrmH4qS-_lk4xuGyXY8FMR3ekge9gCJ1lBMoJnilAw','2025-11-28 06:19:38.492979','2025-12-05 06:19:38.000000',NULL,'27fa8db61e484261bdfe312ca86c51e3'),
(343,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkxNTYzNiwiaWF0IjoxNzY0MzEwODM2LCJqdGkiOiJkOGI3ZGZiNzc5MzA0NDg0YWEwMmJjNzhlOThmN2JhNyIsInVzZXJfaWQiOiIzMyJ9.E1_Bog5KuTRLhyWWZ5lxC0CGIFFWRRWqZOARVatAeVE','2025-11-28 06:20:36.632814','2025-12-05 06:20:36.000000',NULL,'d8b7dfb779304484aa02bc78e98f7ba7'),
(344,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkxNjI1MSwiaWF0IjoxNzY0MzExNDUxLCJqdGkiOiIyYWJhYzM5Y2Q0MjI0ZjMwODgwZTI0ZDhmMDJlMGUxNiIsInVzZXJfaWQiOiIzMyJ9.XVL8i70298LisGIIIZUkzeBEaFD_XV47Wg_wavLGz4E','2025-11-28 06:30:51.280770','2025-12-05 06:30:51.000000',NULL,'2abac39cd4224f30880e24d8f02e0e16'),
(345,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkxNjY1NywiaWF0IjoxNzY0MzExODU3LCJqdGkiOiI3YTg5YzY2ZTNlMmE0NTQzYjI2MDIxOTczMjI3YzAyMCIsInVzZXJfaWQiOiIzNCJ9.XBPNmQ6pI7c41mbrKBL2anooMd3RO_qm14XP9c5TZjg','2025-11-28 06:37:37.905452','2025-12-05 06:37:37.000000',NULL,'7a89c66e3e2a4543b26021973227c020'),
(346,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkxNjc3NywiaWF0IjoxNzY0MzExOTc3LCJqdGkiOiIzZjAzMDU5MTJhZjA0NmNmOTliZjFlMDVlZjUwMzg3ZiIsInVzZXJfaWQiOiIzMyJ9.FZO9V7ZWGKqcea46-OgFPlk60iZBqwKccnJtzaaghW0','2025-11-28 06:39:37.756577','2025-12-05 06:39:37.000000',NULL,'3f0305912af046cf99bf1e05ef50387f'),
(347,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkxOTgwNCwiaWF0IjoxNzY0MzE1MDA0LCJqdGkiOiI5ZDM4YWNiNjIxNjE0YmNmOGZhOWEyNGZkODA5OGRkMyIsInVzZXJfaWQiOiIxMyJ9.XJa3sWjvGdfIpOi-aIqJGDeNO73-0rgiFbV4hSSJows','2025-11-28 07:30:04.627992','2025-12-05 07:30:04.000000',13,'9d38acb621614bcf8fa9a24fd8098dd3'),
(348,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkxOTgzNCwiaWF0IjoxNzY0MzE1MDM0LCJqdGkiOiJjOTc4MTFjZjM2YjE0YjIyYTg0MzBmOWUwMmQ3MTA3OSIsInVzZXJfaWQiOiIxMyJ9.jJeY_MjEUgkftiPSonXnGMXHCVdshv6eJ6sJY_wAmFY','2025-11-28 07:30:34.751595','2025-12-05 07:30:34.000000',13,'c97811cf36b14b22a8430f9e02d71079'),
(349,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkyMTY3NywiaWF0IjoxNzY0MzE2ODc3LCJqdGkiOiI2MWFmZTU4MjZlMmQ0MjE4YWI0Mjg1ZjVlNmJlNTM2NiIsInVzZXJfaWQiOiIzMiJ9.TUX7s7FdaE_pTFUX9vthlS-nndCaDG3YH_R-NzA4k-k','2025-11-28 08:01:17.265169','2025-12-05 08:01:17.000000',32,'61afe5826e2d4218ab4285f5e6be5366'),
(350,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkyNTc4MSwiaWF0IjoxNzY0MzIwOTgxLCJqdGkiOiI5YTVmOTEwNTVjNTE0ZDljODQxZjAyNzFhNzZmYTk4NiIsInVzZXJfaWQiOiIzNSJ9.tvNsBtqHL4CBAfXgbQgSSXUHKOTCAbRHfB1ayQ1kOK0','2025-11-28 09:09:41.922587','2025-12-05 09:09:41.000000',NULL,'9a5f91055c514d9c841f0271a76fa986'),
(351,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkyNTc4NywiaWF0IjoxNzY0MzIwOTg3LCJqdGkiOiI3MDQ3NDkwM2Q2ZmU0YmJhYWM3NzZhY2I1ZjA1MjkxYSIsInVzZXJfaWQiOiIzNSJ9.-Z5b4fHrK1z4ssmJZINGmQ5dgd0x7glHsFguZskUVSA','2025-11-28 09:09:47.038354','2025-12-05 09:09:47.000000',NULL,'70474903d6fe4bbaac776acb5f05291a'),
(352,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkyNzg4MSwiaWF0IjoxNzY0MzIzMDgxLCJqdGkiOiIwYjQ2ZmU4ZDJjODU0NTJjYTQ0YzY4ZTJiMGMxMjI3MSIsInVzZXJfaWQiOiIxMyJ9.Yu8FxX1HRkOMrSBoLOMtv8tVM3t-894EBP_GlEjaZnk','2025-11-28 09:44:41.619961','2025-12-05 09:44:41.000000',13,'0b46fe8d2c85452ca44c68e2b0c12271'),
(353,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkzODY1NywiaWF0IjoxNzY0MzMzODU3LCJqdGkiOiI0NzhhOTE4NGVhMTQ0MGRkYTRiNjZmMTYyMWJkOGZjNCIsInVzZXJfaWQiOiIxMyJ9.3wXbYkaIiEsFjUWQ5uSSxIgFy6F4gFjI7b4SOrPThaU','2025-11-28 12:44:17.604874','2025-12-05 12:44:17.000000',13,'478a9184ea1440dda4b66f1621bd8fc4'),
(354,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkzODgyOSwiaWF0IjoxNzY0MzM0MDI5LCJqdGkiOiIyODY1OWY4ZGIwNTg0MjY2YjE5MGU0YTA4ZmY2ZjY4NCIsInVzZXJfaWQiOiIxMyJ9.0wVyLmjg_P9xPwQkgIQs4SO3AYbVUMipw2H8YzT3IxU','2025-11-28 12:47:09.637146','2025-12-05 12:47:09.000000',13,'28659f8db0584266b190e4a08ff6f684'),
(355,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkzODg5MywiaWF0IjoxNzY0MzM0MDkzLCJqdGkiOiJjOGYxMDQ2NTg0MjM0MjYxOWI5MzU2Y2NmZmY1NDgxZSIsInVzZXJfaWQiOiIxMyJ9.PXJ08jJykmtNgO8v26A8e5EV9EsBYbo2p4PcE2bYBeU','2025-11-28 12:48:13.960918','2025-12-05 12:48:13.000000',13,'c8f10465842342619b9356ccfff5481e'),
(356,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkzODkyOSwiaWF0IjoxNzY0MzM0MTI5LCJqdGkiOiIwOTgwMTllYzkzNjM0N2UwYjNkNTBiMjAwYTBkMDc5ZCIsInVzZXJfaWQiOiIxMyJ9.UXrktSV_x_Xcj45Kuls_KTUTBFwhqmjtPZwe9zAeuT8','2025-11-28 12:48:49.873757','2025-12-05 12:48:49.000000',13,'098019ec936347e0b3d50b200a0d079d'),
(357,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkzOTY4NiwiaWF0IjoxNzY0MzM0ODg2LCJqdGkiOiJkOGE0MzNkYWFhYWY0ODBjOTMzY2Y4MzJmZjdkNDZhYSIsInVzZXJfaWQiOiIxMyJ9.G5xUVqExlzVLP6rjiZQAqqSnvvVMRG0zrfPq0d70pLc','2025-11-28 13:01:26.312147','2025-12-05 13:01:26.000000',13,'d8a433daaaaf480c933cf832ff7d46aa'),
(358,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDkzOTk4MiwiaWF0IjoxNzY0MzM1MTgyLCJqdGkiOiJhZDdiOGZhNzcyMWE0MDdmYmVjOWI1MTY5YjJmZmRlYiIsInVzZXJfaWQiOiIxMyJ9.nYz3FFjbvK6CMsDQbu2pCI9lBH5yJvx9M1T7jXrcumQ','2025-11-28 13:06:22.278987','2025-12-05 13:06:22.000000',13,'ad7b8fa7721a407fbec9b5169b2ffdeb'),
(359,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDk0MDAyNiwiaWF0IjoxNzY0MzM1MjI2LCJqdGkiOiI3NzNiOGRhZTk3YWM0OGJhYTUzNzM3NDFjZWViOTU0OSIsInVzZXJfaWQiOiI0In0.i_hz_cJUof0I0lKEVuxPM9fqedCRL9NU7t_qK43rHvo','2025-11-28 13:07:06.795710','2025-12-05 13:07:06.000000',4,'773b8dae97ac48baa5373741ceeb9549'),
(360,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDk0MDEyMywiaWF0IjoxNzY0MzM1MzIzLCJqdGkiOiJmNzQ4NGExMGExYjU0YWUxOWVkZjdlMDgyYWUyOWQ1YyIsInVzZXJfaWQiOiIxMyJ9.1hfBaCThTpPs3VUqTKDLdkWBtcQuFiJTqFz0416EH_A','2025-11-28 13:08:43.230251','2025-12-05 13:08:43.000000',13,'f7484a10a1b54ae19edf7e082ae29d5c'),
(361,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDk4MjQxMSwiaWF0IjoxNzY0Mzc3NjExLCJqdGkiOiIyNmNmNDA1MTgwZTQ0YjM1YTA2ZDM2NzQ1OGM2YTg3YiIsInVzZXJfaWQiOiIxMyJ9.l8eBbNSnZIVKXr_Ji7ge0c0yhtYaMlMRTU-yhoHHYCs','2025-11-29 00:53:31.475331','2025-12-06 00:53:31.000000',13,'26cf405180e44b35a06d367458c6a87b'),
(362,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDk4NjgzOCwiaWF0IjoxNzY0MzgyMDM4LCJqdGkiOiI1OGI3MmEwYzYxYzc0ZDE1OWRmYjcyZDg4ZDMzNjQ1NSIsInVzZXJfaWQiOiIxMyJ9.-Pdi_yRJ4rHl0b_c9Is0TgZpSp-40_MyewXat8f7uJ8','2025-11-29 02:07:18.666770','2025-12-06 02:07:18.000000',13,'58b72a0c61c74d159dfb72d88d336455'),
(363,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDk5MjU1MCwiaWF0IjoxNzY0Mzg3NzUwLCJqdGkiOiI3ZmI5ZmRlZjQ2ZWE0ZTFjYTFjMGUzMDBmZjNjMjgxNiIsInVzZXJfaWQiOiIzMyJ9.DukN66bGJzUgs2EFGz8uGKzeZN7QQANtthPsL68OGRU','2025-11-29 03:42:30.531890','2025-12-06 03:42:30.000000',NULL,'7fb9fdef46ea4e1ca1c0e300ff3c2816'),
(364,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDk5NjI3NSwiaWF0IjoxNzY0MzkxNDc1LCJqdGkiOiI2NGVhODI4YWEzZTA0Y2IyYWYwZTdhNTRlMjcxODdhYyIsInVzZXJfaWQiOiIxMyJ9.rz4Guonr_vroNQUaTBryeLsCmaW4-f-2fdMjFiQAfbM','2025-11-29 04:44:35.477869','2025-12-06 04:44:35.000000',13,'64ea828aa3e04cb2af0e7a54e27187ac'),
(365,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDk5NjU5MCwiaWF0IjoxNzY0MzkxNzkwLCJqdGkiOiIyZDBjZjJjODkzNDY0ZGU1YmNlZDg5Y2FmYTUwYzNkNiIsInVzZXJfaWQiOiIyOCJ9.IzAV2EgUwrofVn6XL4Frnzf6JQp89zROt9F-U0W3j0I','2025-11-29 04:49:50.816828','2025-12-06 04:49:50.000000',28,'2d0cf2c893464de5bced89cafa50c3d6'),
(366,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NDk5NjYxMiwiaWF0IjoxNzY0MzkxODEyLCJqdGkiOiI1NWI1MGQ2OTcwY2U0MDU3YjI3ZmQ2ZGY0NzJiZmFkMyIsInVzZXJfaWQiOiIxMyJ9.3dwUCs2ZdN8cg1b1Tpcq5i8gNvYAMqZgdSdeg6pguCw','2025-11-29 04:50:12.269469','2025-12-06 04:50:12.000000',13,'55b50d6970ce4057b27fd6df472bfad3'),
(367,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTAwMDAwNywiaWF0IjoxNzY0Mzk1MjA3LCJqdGkiOiJlOWFmOTM3NTlkODU0YWVkYjczMzRkMWNmYmZkNDk4ZCIsInVzZXJfaWQiOiI0In0.qSystd7_fI9Rfg-5nuY2_FOCl6plYPZtEX89SdYuAbE','2025-11-29 05:46:47.138078','2025-12-06 05:46:47.000000',4,'e9af93759d854aedb7334d1cfbfd498d'),
(368,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTAwMTYwOCwiaWF0IjoxNzY0Mzk2ODA4LCJqdGkiOiJmYmM5MGFiMjgxNmE0NGI4YWFkMzM0MWMzMzg0ZTk4ZCIsInVzZXJfaWQiOiIxMyJ9.2aJs4kuvYk8pZ1ovjpRTZsVbjWBn6bDxQbwS6Js9F_E','2025-11-29 06:13:28.885844','2025-12-06 06:13:28.000000',13,'fbc90ab2816a44b8aad3341c3384e98d'),
(369,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTAwMjMxMiwiaWF0IjoxNzY0Mzk3NTEyLCJqdGkiOiJkNzkxY2YzYjc0YmU0ZjA3YjkwNmJkNzg1NGI2NGQ3MCIsInVzZXJfaWQiOiIxMCJ9.K2xZ-SafqhspvsnCf8PSPpZTF1RVGGkfRJ4JMX4vhz0','2025-11-29 06:25:12.576934','2025-12-06 06:25:12.000000',NULL,'d791cf3b74be4f07b906bd7854b64d70'),
(370,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTAwNzU0OSwiaWF0IjoxNzY0NDAyNzQ5LCJqdGkiOiI1NTZiMzg5MGU2NmE0NTk1ODg4ZDU0MGZmYzNhNTAxZCIsInVzZXJfaWQiOiIxMyJ9.bGhyAbOnXmPfBgebReSCnTcldhbvVl3Mvw7z8aC7aMo','2025-11-29 07:52:29.858829','2025-12-06 07:52:29.000000',13,'556b3890e66a4595888d540ffc3a501d'),
(371,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTAyMDIxMSwiaWF0IjoxNzY0NDE1NDExLCJqdGkiOiIxNmJlMTE1Y2RiMTY0YWIwOTQ2MTYwNzMyY2MwODY2MCIsInVzZXJfaWQiOiI0In0.n-SfX3-ycD_0U-VqFnoE4ab29X7zjFrSYMr-hzUw3Dk','2025-11-29 11:23:31.084559','2025-12-06 11:23:31.000000',4,'16be115cdb164ab0946160732cc08660'),
(372,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTAyMDIzNiwiaWF0IjoxNzY0NDE1NDM2LCJqdGkiOiIwYzA3NTc2YmRhZjE0NWNmYjY1NmU2ZWEyMzQ5MjFkNSIsInVzZXJfaWQiOiIxMyJ9.Pep5Di8SJcBpKHl4GtCMdrp7BK6wg0LV_t_7jjwKlYs','2025-11-29 11:23:56.455642','2025-12-06 11:23:56.000000',13,'0c07576bdaf145cfb656e6ea234921d5'),
(373,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTAyMjQyNywiaWF0IjoxNzY0NDE3NjI3LCJqdGkiOiJhZTBlYTc4MjFhYjE0ZmI0OGRlYWJiNjhkODM4MTcwMiIsInVzZXJfaWQiOiIzNiJ9.qsyW7bMhPVkLySzq652J1ZvenJ0W3M0I_q-VXThF13A','2025-11-29 12:00:27.314839','2025-12-06 12:00:27.000000',NULL,'ae0ea7821ab14fb48deabb68d8381702'),
(374,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTAyMjQ0OCwiaWF0IjoxNzY0NDE3NjQ4LCJqdGkiOiJhMmE3NDJmMTM4M2E0Zjk1OGY3MzE0ZWQ5OGZiNzdhYiIsInVzZXJfaWQiOiIzNiJ9.a4tIbK2ER0m3xbF852AKOjcUekPbrwC44kqbqzBhRms','2025-11-29 12:00:48.768851','2025-12-06 12:00:48.000000',NULL,'a2a742f1383a4f958f7314ed98fb77ab'),
(375,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTAyNjEzNywiaWF0IjoxNzY0NDIxMzM3LCJqdGkiOiI5OTM2YTFmODE5Y2M0MjFjYWM0Mjc1YTljNzUzOTUxNyIsInVzZXJfaWQiOiIzNiJ9.8nxHYskBzefnB7VD6S5s95C78k6z0ONOXoLp1pCuYvs','2025-11-29 13:02:17.801742','2025-12-06 13:02:17.000000',NULL,'9936a1f819cc421cac4275a9c7539517'),
(376,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTA2NjI3NiwiaWF0IjoxNzY0NDYxNDc2LCJqdGkiOiI2OTc0NjI4NTExYzc0NGJiOGExOTFmNTI5MDQ2NTdkNyIsInVzZXJfaWQiOiIxMyJ9.SUTv35mhao3U0v7TQxab0xHcDzy7ASbdU9mHGp-44hM','2025-11-30 00:11:16.208947','2025-12-07 00:11:16.000000',13,'6974628511c744bb8a191f52904657d7'),
(377,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTA2NjMyOCwiaWF0IjoxNzY0NDYxNTI4LCJqdGkiOiJkNjBkM2I3ZTlkZDI0OWQ3ODI4ZDc2N2E0NGZkZTk0MCIsInVzZXJfaWQiOiI0In0.ZAuQICnEPs8XqTJoLE2TXeQopjjrhU15GPyU19HSlK4','2025-11-30 00:12:08.308127','2025-12-07 00:12:08.000000',4,'d60d3b7e9dd249d7828d767a44fde940'),
(378,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTA3MzI5MCwiaWF0IjoxNzY0NDY4NDkwLCJqdGkiOiI2NmExMjlkNzM3YjI0ODgwYmI3NGE5ZjYyNmY0MjVjNyIsInVzZXJfaWQiOiIxMyJ9.1_o7X2jBj9BBBn0lM6PGQkOUMbgPrQIpnNPxinCgfzk','2025-11-30 02:08:10.235593','2025-12-07 02:08:10.000000',13,'66a129d737b24880bb74a9f626f425c7'),
(379,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTA3Nzg1MiwiaWF0IjoxNzY0NDczMDUyLCJqdGkiOiI5NWRiYWU1NmNiZTA0YWI1YTQ1MmNlYTE2YjU2ZThlMSIsInVzZXJfaWQiOiIxMyJ9.D7fXJJjC5mk-Ly-QTP0MbWOlbUMH9rFOtFTAEbi49kA','2025-11-30 03:24:12.381550','2025-12-07 03:24:12.000000',13,'95dbae56cbe04ab5a452cea16b56e8e1'),
(380,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTA5NjU1MCwiaWF0IjoxNzY0NDkxNzUwLCJqdGkiOiI1MTc3Y2UyODhjZjU0NGVhYmYxZjBmMTJiNjg5MGNmMyIsInVzZXJfaWQiOiIxMyJ9.96rVStH2lWET9sIgmv5sxX0R2C_nCXAQozoZStUuxik','2025-11-30 08:35:50.014876','2025-12-07 08:35:50.000000',13,'5177ce288cf544eabf1f0f12b6890cf3'),
(381,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTA5NjY1MCwiaWF0IjoxNzY0NDkxODUwLCJqdGkiOiI2OTk4ZjNkMGI4Yzk0ZDA5OGJlZDExZWQzMWM5OWUwYiIsInVzZXJfaWQiOiI0In0.cBxzZ0toxPl3MYtzXTu9uYR5EMzMHriHjc_tLw2HTHw','2025-11-30 08:37:30.929930','2025-12-07 08:37:30.000000',4,'6998f3d0b8c94d098bed11ed31c99e0b'),
(382,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTA5Njc2OSwiaWF0IjoxNzY0NDkxOTY5LCJqdGkiOiIxNTkyMTZlMWE4NWI0NzZmODhhMWJlNjNiMTExMGY1MCIsInVzZXJfaWQiOiIyOCJ9.z3V-U5ezFFrJI8b8LVQSwJHQDs6TKVdYd1BzPrDkZKY','2025-11-30 08:39:29.507630','2025-12-07 08:39:29.000000',28,'159216e1a85b476f88a1be63b1110f50'),
(383,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTA5NzQ5MCwiaWF0IjoxNzY0NDkyNjkwLCJqdGkiOiJmZmVmY2M0ZjFhMjI0YmY2OWI2NDc0MWJhZjEyMDk4OCIsInVzZXJfaWQiOiIxMyJ9.VM8gVq2ul4XVNA6ORISAE1DAcSFUPwxAms-SUV8BU7g','2025-11-30 08:51:30.730991','2025-12-07 08:51:30.000000',13,'ffefcc4f1a224bf69b64741baf120988'),
(384,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTExMjAxOSwiaWF0IjoxNzY0NTA3MjE5LCJqdGkiOiI3MDc4YjkxZGJlNDY0NjFlYWEwZTY1MDY0OGE0NDc1ZCIsInVzZXJfaWQiOiIyIn0.W6O33NaQxFaoG0EvQxX8kM2jY93c9yoebJJOW-LpQgI','2025-11-30 12:53:39.782366','2025-12-07 12:53:39.000000',2,'7078b91dbe46461eaa0e650648a4475d'),
(385,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTExMjIyMywiaWF0IjoxNzY0NTA3NDIzLCJqdGkiOiJhNDUyODBhYjdkYjc0MGNhYTlmMzE3Y2RmMDJjOGJlNyIsInVzZXJfaWQiOiIzIn0.YJndT8nNVzd-jXCYxyAQ4mtWA_zfVGvmLm2Q0cILbeE','2025-11-30 12:57:03.621064','2025-12-07 12:57:03.000000',NULL,'a45280ab7db740caa9f317cdf02c8be7'),
(386,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTExMjM4MiwiaWF0IjoxNzY0NTA3NTgyLCJqdGkiOiJjN2VhMDBmZGUzZTI0MDkzYjZhYmFkMjFlYzFlMGNjZSIsInVzZXJfaWQiOiIzIn0.6AOdBq4FqS1VgbtOa1dMAxWyf7pK84YvX553YLXQmUU','2025-11-30 12:59:42.286516','2025-12-07 12:59:42.000000',NULL,'c7ea00fde3e24093b6abad21ec1e0cce'),
(387,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTExMzM0MSwiaWF0IjoxNzY0NTA4NTQxLCJqdGkiOiI3OTlhZGE5MmUxNWY0YjNkOTI5YmI1MTVlNGMzMmQxMyIsInVzZXJfaWQiOiIxMyJ9.ERwbrI4xsVmPtJIGS-bnc5Lo7f_qCOnVAar_MHE33VU','2025-11-30 13:15:41.980177','2025-12-07 13:15:41.000000',13,'799ada92e15f4b3d929bb515e4c32d13'),
(388,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTExMzY4MywiaWF0IjoxNzY0NTA4ODgzLCJqdGkiOiJiY2QxZTBiNmNmZGY0ZjhkOTNhOTdhYWVjNzc3MzM2YiIsInVzZXJfaWQiOiIxMCJ9.i_9Mvo-eZepqWBVdQzSEiFGD0Kghm8HV-0ptww-mcKA','2025-11-30 13:21:23.862803','2025-12-07 13:21:23.000000',NULL,'bcd1e0b6cfdf4f8d93a97aaec777336b'),
(389,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTExMzg5NywiaWF0IjoxNzY0NTA5MDk3LCJqdGkiOiJkNjJlNjI2OTEwZmY0NmNkYmM0NjU4MGVjYTBkNmI1NyIsInVzZXJfaWQiOiIzIn0.w91hx2vwR4HNbaqECAdPK6Z1wXSRmgQYhG6T0rsR2fs','2025-11-30 13:24:57.753782','2025-12-07 13:24:57.000000',NULL,'d62e626910ff46cdbc46580eca0d6b57'),
(390,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTExNDEzOCwiaWF0IjoxNzY0NTA5MzM4LCJqdGkiOiIyNzUwMDA5Mjc5ZjY0NTFhYWEwYTczYTcxODcyNTIxZCIsInVzZXJfaWQiOiIzNyJ9.V8mrOf2R7y2B2Dx560Ra9UFIOIBUJhwfo-wOy8UMy7c','2025-11-30 13:28:58.992217','2025-12-07 13:28:58.000000',37,'2750009279f6451aaa0a73a71872521d'),
(391,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTExNDE0NiwiaWF0IjoxNzY0NTA5MzQ2LCJqdGkiOiIyZDFlMGZkZDE3NzQ0OTI5OTJkOWM0Nzc3NjYwYWE0YiIsInVzZXJfaWQiOiIzNyJ9.ObZkIwAVjvMZcf5KlV7p9GuOV3f7uL8guGai2at-pBc','2025-11-30 13:29:06.971343','2025-12-07 13:29:06.000000',37,'2d1e0fdd1774492992d9c4777660aa4b'),
(392,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTExNDM2NCwiaWF0IjoxNzY0NTA5NTY0LCJqdGkiOiI0Y2NkN2ZlOTIzOTk0ZjNiOTg0MWMzODNiYjE0MDg3ZiIsInVzZXJfaWQiOiIzNyJ9.yk1lxY-Qb7roT_rpPZyQvnytJ5j7inWrgJYrmqFCpX4','2025-11-30 13:32:44.494572','2025-12-07 13:32:44.000000',37,'4ccd7fe923994f3b9841c383bb14087f'),
(393,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTEyMTEwOCwiaWF0IjoxNzY0NTE2MzA4LCJqdGkiOiI1NGNhOWE0MWQ1NDE0NDkzOWM5OWJkZjAxZTA2ZTYyNSIsInVzZXJfaWQiOiIxMyJ9.7UkjlUxH5sfifAF_3ydLppQPVrqknyTqjn1mY_6y0Zc','2025-11-30 15:25:08.214124','2025-12-07 15:25:08.000000',13,'54ca9a41d54144939c99bdf01e06e625'),
(394,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE1NTY4NSwiaWF0IjoxNzY0NTUwODg1LCJqdGkiOiI0MTc1MmNjNWQ3MWU0YmQ3YTRlMTM1MTVkNjQ2ZWM5NSIsInVzZXJfaWQiOiIxMyJ9.vN7oGpyetImp0E4-n_iFGr-7VfDftL67ak28CubNraQ','2025-12-01 01:01:25.447406','2025-12-08 01:01:25.000000',13,'41752cc5d71e4bd7a4e13515d646ec95'),
(395,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE1NjIyMSwiaWF0IjoxNzY0NTUxNDIxLCJqdGkiOiIyOGI0ZTZjNzU5ODQ0ZmFjOGExYjBlNDkwMDVhOTQzMSIsInVzZXJfaWQiOiIxMyJ9.G-9iSvxnv6DORRYJa6YK8sfZ7TNXF6XSG_GP56Z899g','2025-12-01 01:10:21.277652','2025-12-08 01:10:21.000000',13,'28b4e6c759844fac8a1b0e49005a9431'),
(396,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE1NjUzOCwiaWF0IjoxNzY0NTUxNzM4LCJqdGkiOiI0ZmM3NzQ2MDljYWM0Nzg1OGZhNWI4MmU5YTQ2YzdjYiIsInVzZXJfaWQiOiI0In0.YupOKEhk_DG8MMnK0eXa4gP7yKh9YJ8JRmjfTwsmg2Y','2025-12-01 01:15:38.723632','2025-12-08 01:15:38.000000',4,'4fc774609cac47858fa5b82e9a46c7cb'),
(397,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE1NjYzNiwiaWF0IjoxNzY0NTUxODM2LCJqdGkiOiJiNzRjMjZiZGNiZWU0ZjljOTg5MTJhNzY2OGIyZDk4MSIsInVzZXJfaWQiOiI0In0.QxM3hPubYM1REALr6ytilL9GGjoB3HLrWPOrU8PQr7A','2025-12-01 01:17:16.765474','2025-12-08 01:17:16.000000',4,'b74c26bdcbee4f9c98912a7668b2d981'),
(398,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE1Njc0OCwiaWF0IjoxNzY0NTUxOTQ4LCJqdGkiOiJhNDhhZmI5ODRiMjE0ZDhmOTRkZTk0Y2UyMDg1ODA1NiIsInVzZXJfaWQiOiIxMyJ9.QXc_TUpa3hpL6DFg_UKKQU3C-kivOxfi0xQw849HRwY','2025-12-01 01:19:08.196643','2025-12-08 01:19:08.000000',13,'a48afb984b214d8f94de94ce20858056'),
(399,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE1NzkxMSwiaWF0IjoxNzY0NTUzMTExLCJqdGkiOiJhNzQ1NzRjOGU0ZmQ0YTgxODliOTRkY2U2MjAxZDE3ZSIsInVzZXJfaWQiOiIxMyJ9.jtnTqHo0ei6rJgzQuDNkZGSmtA_hXLepHmIm7BTy6us','2025-12-01 01:38:31.698248','2025-12-08 01:38:31.000000',13,'a74574c8e4fd4a8189b94dce6201d17e'),
(400,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE1ODE2NiwiaWF0IjoxNzY0NTUzMzY2LCJqdGkiOiJiYTFlOTllMjAwODQ0ZmYzYWVlYmE1ZTdmODk4NzQ3MCIsInVzZXJfaWQiOiIxMyJ9.EcFGkwG5hKDtwBxcaJZyRd2T1WXKDKPYymcf4Eww-HA','2025-12-01 01:42:46.559859','2025-12-08 01:42:46.000000',13,'ba1e99e200844ff3aeeba5e7f8987470'),
(401,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE1ODMyMywiaWF0IjoxNzY0NTUzNTIzLCJqdGkiOiJhN2ZkMDRjYTU2YmU0NWE4ODcxNGY2MjJlMGE3MTQ2YiIsInVzZXJfaWQiOiIyOCJ9.1wG_xAIb1WOZ1gjD_Uc9KzfcqJXb7wcZAJKj6xqiyHE','2025-12-01 01:45:23.579035','2025-12-08 01:45:23.000000',28,'a7fd04ca56be45a88714f622e0a7146b'),
(402,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE1ODM0NiwiaWF0IjoxNzY0NTUzNTQ2LCJqdGkiOiJmMDhmOWU1OGM1ODA0ODg0YTFkYzlhY2MyMzk5ODQ5ZiIsInVzZXJfaWQiOiIxMyJ9.reZQwx3JKINYp3mTAqjm59Vy2N-DWUSrGYjsvl7RKTM','2025-12-01 01:45:46.191758','2025-12-08 01:45:46.000000',13,'f08f9e58c5804884a1dc9acc2399849f'),
(403,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE1OTIwMSwiaWF0IjoxNzY0NTU0NDAxLCJqdGkiOiJlYTA4YzE3OWI5Mjg0ZTcyOThhODAwNTAxMGVmZTEzMSIsInVzZXJfaWQiOiIzIn0.SQr4r17fk3-M3-W9pWdSFHnQLS7oXIjWNs5S2DGQCBE','2025-12-01 02:00:01.047638','2025-12-08 02:00:01.000000',NULL,'ea08c179b9284e7298a8005010efe131'),
(404,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE1OTM5NywiaWF0IjoxNzY0NTU0NTk3LCJqdGkiOiIyZTljMzZiNTVmODA0MzJkYjRjMDlkYzgwMTYyNWE0ZSIsInVzZXJfaWQiOiIzNyJ9.aI1fep3RzaMSHrqttUD6Olu7O5u0lflF-4jASwHVddw','2025-12-01 02:03:17.507962','2025-12-08 02:03:17.000000',37,'2e9c36b55f80432db4c09dc801625a4e'),
(405,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE1OTY2OSwiaWF0IjoxNzY0NTU0ODY5LCJqdGkiOiI4ZWRkMjY0YzkzZWE0ZTEyYWQ2ODVhZTcwOWQzNjNiMiIsInVzZXJfaWQiOiIzOCJ9.2c7ANgcv6wfP-yL-tm6TZrMOjqSIvThRs16v9wonAsg','2025-12-01 02:07:49.246699','2025-12-08 02:07:49.000000',38,'8edd264c93ea4e12ad685ae709d363b2'),
(406,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE1OTY3OSwiaWF0IjoxNzY0NTU0ODc5LCJqdGkiOiIzZWFkNWE0MTI3NzY0NDRjODQ0ZjJlMGExOTZjYWNjYyIsInVzZXJfaWQiOiIzOCJ9.DzvGmBpwiBm6sFFSgdF8oVKMF_iag8ujHXrbWKTain0','2025-12-01 02:07:59.587564','2025-12-08 02:07:59.000000',38,'3ead5a412776444c844f2e0a196caccc'),
(407,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE2MTI5NywiaWF0IjoxNzY0NTU2NDk3LCJqdGkiOiI3MDRkZjU4YTIzNTU0ZmMyOTNhYjdiNTBiMDVjMjY5ZCIsInVzZXJfaWQiOiIxMyJ9.a-nTkT6vd1skBZp9pgN4xWyLOs6FxBHiCoTUyY6kylI','2025-12-01 02:34:57.150894','2025-12-08 02:34:57.000000',13,'704df58a23554fc293ab7b50b05c269d'),
(408,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE2MTg3MCwiaWF0IjoxNzY0NTU3MDcwLCJqdGkiOiIyYzJjNjE5M2NkMDU0MmU3OTRjNTI4YzVkZWY0NmQwMCIsInVzZXJfaWQiOiI0In0.w0l7sEMMJdsWEqkILupne1-LPbLO9fsJIsq60okPZgQ','2025-12-01 02:44:30.556889','2025-12-08 02:44:30.000000',4,'2c2c6193cd0542e794c528c5def46d00'),
(409,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE2MTk3NSwiaWF0IjoxNzY0NTU3MTc1LCJqdGkiOiIzMjczMWFiNDA5YWM0MTZmOTc0OTMyNTZhN2RmMmFmMyIsInVzZXJfaWQiOiI0In0.pTTUXhn6PoHeRRhj30MnIuGXSd_WndDNlwnlWnsKWgM','2025-12-01 02:46:15.289065','2025-12-08 02:46:15.000000',4,'32731ab409ac416f97493256a7df2af3'),
(410,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE2MjIzNSwiaWF0IjoxNzY0NTU3NDM1LCJqdGkiOiI4ZDk4NjgxM2MzNjI0ZGYxOGE4OTk0NDc3MzZlOTk5YiIsInVzZXJfaWQiOiI0In0.B998PPUPdGn3b0b5TZyxFa4_bEfZ9LrNi41JrMwS_O8','2025-12-01 02:50:35.483745','2025-12-08 02:50:35.000000',4,'8d986813c3624df18a899447736e999b'),
(411,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE3MTQwMiwiaWF0IjoxNzY0NTY2NjAyLCJqdGkiOiI4NTMzYTE0ZDJhOTg0MzdjOTBjNmVjYjZkNzliOTQyMiIsInVzZXJfaWQiOiIxMyJ9.X7yiGcq7j31_smke8eiHf6DPV1vtgflaxOOiFPEehbE','2025-12-01 05:23:22.268283','2025-12-08 05:23:22.000000',13,'8533a14d2a98437c90c6ecb6d79b9422'),
(412,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE3NzAyOCwiaWF0IjoxNzY0NTcyMjI4LCJqdGkiOiIzODRmMWZlODUxNmQ0MmM4YjdiNzJhMjI2NTFiNWY1NyIsInVzZXJfaWQiOiIzMiJ9.B04r-k3LMUk5xGUbK6tvldl_RV_7Rb5afMSzOGbGU2o','2025-12-01 06:57:08.860522','2025-12-08 06:57:08.000000',32,'384f1fe8516d42c8b7b72a22651b5f57'),
(413,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE4NzY0MCwiaWF0IjoxNzY0NTgyODQwLCJqdGkiOiI5YjVjMmQzYTQ2YzI0MTUwYTQ3ZjE2ZTFkMGM0ZDIyNiIsInVzZXJfaWQiOiIxMyJ9.MUJ9MnaK3jeWBFYWJeVgXV_RzobFl24mKBG6tXEy63M','2025-12-01 09:54:00.527707','2025-12-08 09:54:00.000000',13,'9b5c2d3a46c24150a47f16e1d0c4d226'),
(414,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE5Mjc5MSwiaWF0IjoxNzY0NTg3OTkxLCJqdGkiOiIxMTQxNGE5NmVkNGI0MmY4YmE5ZGZiMDRjZmFhNWYzZiIsInVzZXJfaWQiOiIxMyJ9.dBxWTuu2_to2l6Xe9epJ3C93BmjG-Lyex6Vh3CiZBQw','2025-12-01 11:19:51.334764','2025-12-08 11:19:51.000000',13,'11414a96ed4b42f8ba9dfb04cfaa5f3f'),
(415,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTE5ODYzMSwiaWF0IjoxNzY0NTkzODMxLCJqdGkiOiJmNmM0NjYxMTFkYTI0MmI1YWJkYzdlMzc2Y2VjMDNiYiIsInVzZXJfaWQiOiIyMCJ9.zacH7POCDLdv71K8wnzJicnr2FUwTxepcXbJR3tsufY','2025-12-01 12:57:11.851167','2025-12-08 12:57:11.000000',20,'f6c466111da242b5abdc7e376cec03bb'),
(416,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTIwNDA3OSwiaWF0IjoxNzY0NTk5Mjc5LCJqdGkiOiJmY2ExYTNmYTQ1Yzk0ODE5OWFjNzI0MzI2MDhjMDM0ZiIsInVzZXJfaWQiOiIxMyJ9.2tUjizyvF3zD3sO20Bg_ZXpzh4qRDQeDd-YJqiEbGWg','2025-12-01 14:27:59.680851','2025-12-08 14:27:59.000000',13,'fca1a3fa45c948199ac72432608c034f'),
(417,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTIwNDM5NSwiaWF0IjoxNzY0NTk5NTk1LCJqdGkiOiIyMGZlOTFhYmQ2Mjg0YWQyYjgxOWUzMjIzMDJlMjJmMiIsInVzZXJfaWQiOiIzOCJ9.pJmGDkxRNCvrJJdhRz_9we7E5Vu0E9Vgmig9Ue8GokU','2025-12-01 14:33:15.303286','2025-12-08 14:33:15.000000',38,'20fe91abd6284ad2b819e322302e22f2'),
(418,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTIzODQ3OSwiaWF0IjoxNzY0NjMzNjc5LCJqdGkiOiJiNDQ1NTNmYjEzOGI0MmRmODhlNDdjMTQ2OWRmYTkyYSIsInVzZXJfaWQiOiIxMyJ9.zukdzxUyeHtuu8BXeMkyix-iG9BqbM2GjVhd2hOomKc','2025-12-02 00:01:19.055859','2025-12-09 00:01:19.000000',13,'b44553fb138b42df88e47c1469dfa92a'),
(419,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTIzOTQ4NiwiaWF0IjoxNzY0NjM0Njg2LCJqdGkiOiIwYjE4ZGI1NGY0YjY0MTA1YjJhMGNlMWQ2MmQyNGVkOCIsInVzZXJfaWQiOiIxMyJ9.10LIrDTftuVciDc0EMo-Qu6cBe_iphJ5S2-s9jnqxMg','2025-12-02 00:18:06.178504','2025-12-09 00:18:06.000000',13,'0b18db54f4b64105b2a0ce1d62d24ed8'),
(420,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI0MDI4NCwiaWF0IjoxNzY0NjM1NDg0LCJqdGkiOiJmODNhYTViYjlmZmQ0NjZjYWUwNDE4N2RhMTE1ZjM4NiIsInVzZXJfaWQiOiI0In0.L3opksdpzt1H47NsduAoeJNZhmmOADCdqV06OY0Dfrs','2025-12-02 00:31:24.487739','2025-12-09 00:31:24.000000',4,'f83aa5bb9ffd466cae04187da115f386'),
(421,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI0MjkwNSwiaWF0IjoxNzY0NjM4MTA1LCJqdGkiOiI5NDM1NTQ3YTg1YWU0M2Q2YTNmZTMyMDI3ZmUxYjIxMSIsInVzZXJfaWQiOiIxMyJ9.nppJpAch2ZcKNK1YDP7ECnK-vniEMZdrxJ7o4T8AJxk','2025-12-02 01:15:05.718366','2025-12-09 01:15:05.000000',13,'9435547a85ae43d6a3fe32027fe1b211'),
(422,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI0NTAwMywiaWF0IjoxNzY0NjQwMjAzLCJqdGkiOiIzNGM0YjA0NGE3MmM0MTM3YTVkNmExMjEwZDAxMjNhNiIsInVzZXJfaWQiOiIyMSJ9.MWxFzhzPlmkDykkqLvf5CaiBjiZH1WwLtOjmq7u2BRE','2025-12-02 01:50:03.884204','2025-12-09 01:50:03.000000',21,'34c4b044a72c4137a5d6a1210d0123a6'),
(423,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI1MDQxMCwiaWF0IjoxNzY0NjQ1NjEwLCJqdGkiOiI5YTVhOTU5ZThjYTQ0ZWY1ODgzZDkxNmIwMzIwZmJmNiIsInVzZXJfaWQiOiIxMyJ9.FXQjmPp4JOS125WV4xk9IqssBthXoCPMISSAgpmqKxM','2025-12-02 03:20:10.212842','2025-12-09 03:20:10.000000',13,'9a5a959e8ca44ef5883d916b0320fbf6'),
(424,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI1NTkzMywiaWF0IjoxNzY0NjUxMTMzLCJqdGkiOiI3ODBhYmM2NjQ5NWI0ZWFhOWU1NGY4M2M1MWMzNDUxMCIsInVzZXJfaWQiOiIzOSJ9.75iUqX7CaJS6SBFfXeDGp_xX5FG_9oeuciP99YyX2yY','2025-12-02 04:52:13.414945','2025-12-09 04:52:13.000000',39,'780abc66495b4eaa9e54f83c51c34510'),
(425,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI1NTk1OSwiaWF0IjoxNzY0NjUxMTU5LCJqdGkiOiJhODU3ZDg1YmY0OWE0MjA3OGJlODRhNjVhNmE4OTdlOCIsInVzZXJfaWQiOiIzOSJ9.14y8Rn9caT1Z7SeyVAZ9Dmw5FuNRGX0c3-YcZVTsaBc','2025-12-02 04:52:39.495971','2025-12-09 04:52:39.000000',39,'a857d85bf49a42078be84a65a6a897e8'),
(426,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI1Nzc0NiwiaWF0IjoxNzY0NjUyOTQ2LCJqdGkiOiIwOTkxYTA1ODliYjI0MGVlYjMwODExMWY0ZGRjN2JmOSIsInVzZXJfaWQiOiIzOSJ9.fjXeslfj-CZCjjfMt7ua6OQ4MdiStLRIiPzLJwy5_BY','2025-12-02 05:22:26.929307','2025-12-09 05:22:26.000000',39,'0991a0589bb240eeb308111f4ddc7bf9'),
(427,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI2MTMwMiwiaWF0IjoxNzY0NjU2NTAyLCJqdGkiOiI3ZGUyYTk0MjA3NWM0YTZiYjgxYTkzY2FiYmJhMjZhOCIsInVzZXJfaWQiOiIxMyJ9.0LTirPh5pmBh5hDpuoJR_CzWHGqSC3uHklaTVX7jiGs','2025-12-02 06:21:42.919235','2025-12-09 06:21:42.000000',13,'7de2a942075c4a6bb81a93cabbba26a8'),
(428,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI2MTYyOSwiaWF0IjoxNzY0NjU2ODI5LCJqdGkiOiJmZDk5NTExNTdiMTM0ZDdlODY0YzYwMWMxMDZmMjZkYyIsInVzZXJfaWQiOiIxMyJ9.7OWfdDYL64-7OoWOplOrpFdxVuSHozg9c1I6YC7hjKM','2025-12-02 06:27:09.953331','2025-12-09 06:27:09.000000',13,'fd9951157b134d7e864c601c106f26dc'),
(429,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI2MTY0MywiaWF0IjoxNzY0NjU2ODQzLCJqdGkiOiJlODU3MTI1N2EwMmM0NjZiOThhNmU0NTRjYjJjODRiMCIsInVzZXJfaWQiOiIyOCJ9.K2tPAH82SK2TGQtRdNfruSnebKQkpguJizpScGIG2sw','2025-12-02 06:27:23.220933','2025-12-09 06:27:23.000000',28,'e8571257a02c466b98a6e454cb2c84b0'),
(430,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI2MTc0MCwiaWF0IjoxNzY0NjU2OTQwLCJqdGkiOiJhOWI2ZGQ2ZjE4MGQ0NDQ4OTlmMDhjNWY4NTI3MWIxYiIsInVzZXJfaWQiOiIxMyJ9.5xJImOG1jWLrn6pbmocllUlq92QI04uX3GGWaAOUYxA','2025-12-02 06:29:00.429518','2025-12-09 06:29:00.000000',13,'a9b6dd6f180d444899f08c5f85271b1b'),
(431,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI2MzM2NywiaWF0IjoxNzY0NjU4NTY3LCJqdGkiOiJjY2E0NWU0YzZiZmQ0NDE5OTBlOTdiZWMwMjYzOGIzNyIsInVzZXJfaWQiOiI0MCJ9.WWJ7dY12dxP25JcH3zbvsFDZC1nn8F338TFFv_jsS9M','2025-12-02 06:56:07.826660','2025-12-09 06:56:07.000000',40,'cca45e4c6bfd441990e97bec02638b37'),
(432,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI2MzM5MiwiaWF0IjoxNzY0NjU4NTkyLCJqdGkiOiI1OWMwNGEwYzBjZTY0NWViYWM2MjFhZTg4MGFkYjJkNCIsInVzZXJfaWQiOiI0MCJ9.uPtE4oJ3VX8seSxr3gfC5aJ3dYoZ7D3YwFHYBIsCECs','2025-12-02 06:56:32.528600','2025-12-09 06:56:32.000000',40,'59c04a0c0ce645ebac621ae880adb2d4'),
(433,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI2Mzk3MSwiaWF0IjoxNzY0NjU5MTcxLCJqdGkiOiI1YzM5ZjRjOGRlZjk0NjU2OTVkYTU5ZjUyN2FmZTJmYyIsInVzZXJfaWQiOiI0MCJ9.qxfulC3RhGD8IUOEudswyIdEDsV1Ps5XGTqa-4mAzMs','2025-12-02 07:06:11.654618','2025-12-09 07:06:11.000000',40,'5c39f4c8def9465695da59f527afe2fc'),
(434,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI2NDc2NiwiaWF0IjoxNzY0NjU5OTY2LCJqdGkiOiIzYzAzMWI5YjFmNjg0NmRiYTk2NTBkNjFlYzc1MDk2OSIsInVzZXJfaWQiOiI0MCJ9.gtbMs5Yb_dkO7BxuwT_pF4k95aIKmPBIJM-Jx97_JXk','2025-12-02 07:19:26.903424','2025-12-09 07:19:26.000000',40,'3c031b9b1f6846dba9650d61ec750969'),
(435,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI2NDk1MCwiaWF0IjoxNzY0NjYwMTUwLCJqdGkiOiIyNzllMTQ3MWQzMjY0Yjg4ODMyM2VlNWE5MGQ3MmZiNCIsInVzZXJfaWQiOiI0MSJ9.izRAVcyAcyv97b39FpewcTskiiNJMl2_p8O0B_PKmUQ','2025-12-02 07:22:30.574530','2025-12-09 07:22:30.000000',41,'279e1471d3264b888323ee5a90d72fb4'),
(436,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI2NTAzMCwiaWF0IjoxNzY0NjYwMjMwLCJqdGkiOiI4ZDZjODZjNzAxZTU0YjNiOTUwYTAzODY5MWMzMzM5NCIsInVzZXJfaWQiOiI0MCJ9.y5EoAM6DFryM5IMYKee6XKiY-F4n3io0mDj198VJE5Y','2025-12-02 07:23:50.746533','2025-12-09 07:23:50.000000',40,'8d6c86c701e54b3b950a038691c33394'),
(437,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI3MjgyMSwiaWF0IjoxNzY0NjY4MDIxLCJqdGkiOiJlMWUyNzU2Y2ViZDE0MmQ2ODVmOThjYWU1Nzg4MmVjZCIsInVzZXJfaWQiOiIxMyJ9.W93ze7IyMyGDXXLuwwF7Secv1fXKMZA7odSjjCP50aI','2025-12-02 09:33:41.801042','2025-12-09 09:33:41.000000',13,'e1e2756cebd142d685f98cae57882ecd'),
(438,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI4NDEzNCwiaWF0IjoxNzY0Njc5MzM0LCJqdGkiOiI0ODJlMDVhOWFjODE0YmMwYWRkYjMwMzQzMmYxOWVkYSIsInVzZXJfaWQiOiIxMyJ9.AMUhvRMDb1P9JegQeNCjlOjaT13G0HWmQDymxAGaZZw','2025-12-02 12:42:14.681729','2025-12-09 12:42:14.000000',13,'482e05a9ac814bc0addb303432f19eda'),
(439,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTI4ODUwOCwiaWF0IjoxNzY0NjgzNzA4LCJqdGkiOiJkZjRhZjMxZTU3ZTk0MjZkOWRhMzRiNzY3ZDYwY2RjZSIsInVzZXJfaWQiOiIxMyJ9.9mB6U_l32URtcAjohqdSciSLknqcPk-OfXUzcDDuPX8','2025-12-02 13:55:08.557132','2025-12-09 13:55:08.000000',13,'df4af31e57e9426d9da34b767d60cdce'),
(440,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTMyOTAxNSwiaWF0IjoxNzY0NzI0MjE1LCJqdGkiOiI3NjYzMzg0YTlhMzA0OThlODA3NDNiZTEzOWZjZWYzNyIsInVzZXJfaWQiOiI0MiJ9.AVP6fzWjC9qqhbgccxgT70PFMTOxG2ur0E_QbjiXUV4','2025-12-03 01:10:15.988710','2025-12-10 01:10:15.000000',42,'7663384a9a30498e80743be139fcef37'),
(441,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTMyOTAyOCwiaWF0IjoxNzY0NzI0MjI4LCJqdGkiOiIyZWJjNTE0NzllYTM0Mjg0YTNiMGJiNWIzZjQ1N2RhOCIsInVzZXJfaWQiOiI0MiJ9.xesi_MjTpjDGurq4I_sW14XnwMFvFE6wvy_ftDpINhg','2025-12-03 01:10:28.123669','2025-12-10 01:10:28.000000',42,'2ebc51479ea34284a3b0bb5b3f457da8'),
(442,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTMyOTIyNCwiaWF0IjoxNzY0NzI0NDI0LCJqdGkiOiI1ZTY5YWFiMGIyYWE0YzA4YWIxYTE2YTE5MTk1MDIxNSIsInVzZXJfaWQiOiI0MiJ9.M3Yy_n2Tf9u79XFdMKt47JnLvLg6SkAsDDRZpeDaNpQ','2025-12-03 01:13:44.046458','2025-12-10 01:13:44.000000',42,'5e69aab0b2aa4c08ab1a16a191950215'),
(443,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTMzMjQzMywiaWF0IjoxNzY0NzI3NjMzLCJqdGkiOiIzMmFkNmYwYTFkMDQ0ODI4OTc3OGU2YTc5MDI0NTFmMSIsInVzZXJfaWQiOiIxMyJ9.ZAYueWqB5KhgZlMLU1XCm7uv52hugv48HhV_0swLAu4','2025-12-03 02:07:13.343484','2025-12-10 02:07:13.000000',13,'32ad6f0a1d0448289778e6a7902451f1'),
(444,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTMzMzE4OCwiaWF0IjoxNzY0NzI4Mzg4LCJqdGkiOiJlYWRlYzg0MWQ2Yzg0ZWE3OWM3OTY2MDdjNGJkYTY0OSIsInVzZXJfaWQiOiIxMyJ9.uP-bjUaMRZImd23AoI1IwPiATvNYnM-2i23vALZncMs','2025-12-03 02:19:48.219024','2025-12-10 02:19:48.000000',13,'eadec841d6c84ea79c796607c4bda649'),
(445,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTMzMzc4MywiaWF0IjoxNzY0NzI4OTgzLCJqdGkiOiI1YjY0ZTQyMDUzOTE0ZDg0YTZjYzhiMDI2ODhhMWRlZSIsInVzZXJfaWQiOiIxMyJ9.2svO5Um0t7afcIl3zvRSHwviwUz2Wkcic3qXN_5L68I','2025-12-03 02:29:43.772838','2025-12-10 02:29:43.000000',13,'5b64e42053914d84a6cc8b02688a1dee'),
(446,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTMzNTIwMCwiaWF0IjoxNzY0NzMwNDAwLCJqdGkiOiI3ZWM3NzU4MjA3MTQ0M2U0OTk0Zjc2OTE4NzBkM2JjMCIsInVzZXJfaWQiOiI0MCJ9.vd4OYXGvnGD4OZ6isRUj-f7VdOWv4wbekI1s9yu9K6c','2025-12-03 02:53:20.051196','2025-12-10 02:53:20.000000',40,'7ec77582071443e4994f7691870d3bc0'),
(447,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTMzNTkwMywiaWF0IjoxNzY0NzMxMTAzLCJqdGkiOiJkY2VjZTRkMDYwNmM0ODNmOGM5NWM4MjhiOWYyYmViYiIsInVzZXJfaWQiOiIxMyJ9.KtAszPEdVhCQePYJ8RCfxz2JsPJAGEY9d6zOu6TM5DM','2025-12-03 03:05:03.043767','2025-12-10 03:05:03.000000',13,'dcece4d0606c483f8c95c828b9f2bebb'),
(448,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTMzNTk0OCwiaWF0IjoxNzY0NzMxMTQ4LCJqdGkiOiJmYzVmNTY5Mzg1ZjQ0MmQyODk1OWEyZmJmNmM1YzAxNSIsInVzZXJfaWQiOiI0In0.ueWvE9F8wiEHAg80HB32B-vb1QK_xGWv9-HfxXQCZmo','2025-12-03 03:05:48.316837','2025-12-10 03:05:48.000000',4,'fc5f569385f442d28959a2fbf6c5c015'),
(449,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTMzNjI3NCwiaWF0IjoxNzY0NzMxNDc0LCJqdGkiOiIyMjY5ZjFkZGMzNTE0M2QzODYxODkxMzkyNTcwN2QxNSIsInVzZXJfaWQiOiIxMyJ9.yKzpF0osy02JljtMdRxvxdVuyHLtlFmJtxgpcod8r3g','2025-12-03 03:11:14.634559','2025-12-10 03:11:14.000000',13,'2269f1ddc35143d38618913925707d15'),
(450,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTM0NTgyMCwiaWF0IjoxNzY0NzQxMDIwLCJqdGkiOiI1ZmQzMTFhY2U4OGE0YzIwYTdmYmU0YjVmNDk4YzFkMCIsInVzZXJfaWQiOiIxMyJ9.J8ogBQLoA5zDcCwR9615iZBOvKY92hsGIdLYmknxDRk','2025-12-03 05:50:20.984776','2025-12-10 05:50:20.000000',13,'5fd311ace88a4c20a7fbe4b5f498c1d0'),
(451,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTM0Njk1OSwiaWF0IjoxNzY0NzQyMTU5LCJqdGkiOiIxNGIzZTFkNWE1YzU0MmFjYmM1MWU2YmI4ZDEyZWJmYiIsInVzZXJfaWQiOiI0MyJ9.Gy9SyLMtA2GHsg97mxJtshtf6kZoswQWSF85OxBeRIE','2025-12-03 06:09:19.652073','2025-12-10 06:09:19.000000',43,'14b3e1d5a5c542acbc51e6bb8d12ebfb'),
(452,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTM0Njk5MSwiaWF0IjoxNzY0NzQyMTkxLCJqdGkiOiJlOGY0MmJlZWEzNGU0NDY4YTIwMjk2ZDA1MjMzMGMzNyIsInVzZXJfaWQiOiI0MyJ9.addo84-Vc5UIcRRp6U49LTCJLFMWjMCiJgCHe8yy6V4','2025-12-03 06:09:51.374038','2025-12-10 06:09:51.000000',43,'e8f42beea34e4468a20296d052330c37'),
(453,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTM0NzU1MiwiaWF0IjoxNzY0NzQyNzUyLCJqdGkiOiI1N2ZkZWEzMmEzNGQ0N2M5OTVmZTRhMmM1N2MyNjc2YyIsInVzZXJfaWQiOiI0MyJ9.YB3xrnXERnnQnJ6Ph9ey0llcNkpEs-IrSWFGZ6ZbxvI','2025-12-03 06:19:12.594018','2025-12-10 06:19:12.000000',43,'57fdea32a34d47c995fe4a2c57c2676c'),
(454,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTM0NzYxNywiaWF0IjoxNzY0NzQyODE3LCJqdGkiOiI0NjlhNGI5MjVjZWU0YzZiYjgwOTVlNmJlZmQyMGJmMiIsInVzZXJfaWQiOiI0MyJ9.NigQLua5c6HmmpYrDvpV0WdWXgFj_wzmwfXrWd0VuzM','2025-12-03 06:20:17.535929','2025-12-10 06:20:17.000000',43,'469a4b925cee4c6bb8095e6befd20bf2'),
(455,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTM0NzY2NSwiaWF0IjoxNzY0NzQyODY1LCJqdGkiOiI2OTk5YTFlMGYyNjI0NTI1ODUyMTU5MGMyMjRjYzg5YiIsInVzZXJfaWQiOiI0NSJ9.FVVjTetYjbkOf2NbdCpQaKPMTXpFVuxIhJ8-05-VURw','2025-12-03 06:21:05.213115','2025-12-10 06:21:05.000000',45,'6999a1e0f26245258521590c224cc89b'),
(456,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTYzNzg0MSwiaWF0IjoxNzY1MDMzMDQxLCJqdGkiOiIzZWM1NmI5YThmYjI0ZTUxOGFmN2IwZDlhNDE4N2QyYyIsInVzZXJfaWQiOiIxMyJ9.qIaorAiof1TrgIMgjqrFn1fKgbdMiOYDW6ZgOvKcv40','2025-12-06 14:57:21.736460','2025-12-13 14:57:21.000000',13,'3ec56b9a8fb24e518af7b0d9a4187d2c'),
(457,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTYzODE2NiwiaWF0IjoxNzY1MDMzMzY2LCJqdGkiOiI2YjM5ZDhjM2YyZjc0MjJiYWUzNTRjNGIzZjZjYTg2YiIsInVzZXJfaWQiOiI0In0.BVgLz3aCKMQ_d_pxY9iFYN-B0VO5aMM_IuJBHt5-3Zw','2025-12-06 15:02:46.042944','2025-12-13 15:02:46.000000',4,'6b39d8c3f2f7422bae354c4b3f6ca86b'),
(458,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTYzODM3MiwiaWF0IjoxNzY1MDMzNTcyLCJqdGkiOiI0NTU4ZjBkMDVhYzE0NDEwYTUxMjJiZmE2MDc1MjQ5NiIsInVzZXJfaWQiOiIxMyJ9.YVLFI7vtwpuG8wo4k8yKvWE8ihzNI2SgDPKcgcpQ4JY','2025-12-06 15:06:12.952191','2025-12-13 15:06:12.000000',13,'4558f0d05ac14410a5122bfa60752496'),
(459,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTYzOTE2OCwiaWF0IjoxNzY1MDM0MzY4LCJqdGkiOiIyZTk4ZTZlZDRiOTI0ODc4YjY2MDY5OGJmOTNiYzJjMCIsInVzZXJfaWQiOiI0In0.UN5d12QETC4laI7i7Zscj3u1JmHFW0NKnWTf-0PXvGM','2025-12-06 15:19:28.926766','2025-12-13 15:19:28.000000',4,'2e98e6ed4b924878b660698bf93bc2c0'),
(460,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTY0NDIxNSwiaWF0IjoxNzY1MDM5NDE1LCJqdGkiOiI5NGFmN2UxYTRmZTM0YTM3YjZkODEwZDkwMDVhYWUyNSIsInVzZXJfaWQiOiIxMyJ9.8oJRsJ5_hEPdic7VzHtLPtGBX2D2GajKwA1Xakfiljs','2025-12-06 16:43:35.655992','2025-12-13 16:43:35.000000',13,'94af7e1a4fe34a37b6d810d9005aae25'),
(461,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTY4MDU3NywiaWF0IjoxNzY1MDc1Nzc3LCJqdGkiOiJjMmVlMTFlZTc0MjY0NTM5YmQ1M2Q5OWE1Y2Y0M2E3NCIsInVzZXJfaWQiOiIxMyJ9.UjVJrWRR2gRFfxbeXELSPiypKjXaaIycyZuCKntGhDU','2025-12-07 02:49:37.914869','2025-12-14 02:49:37.000000',13,'c2ee11ee74264539bd53d99a5cf43a74'),
(462,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTY4NTQ0NCwiaWF0IjoxNzY1MDgwNjQ0LCJqdGkiOiIzZWExMDVjMWJjOWI0MjU1ODAyM2IwODRmNzE1NGExOCIsInVzZXJfaWQiOiI0In0.AgD7-6rkv-ZYDyiYhIo6Xbxmd_Dopd97GCZKcZfghmQ','2025-12-07 04:10:44.625028','2025-12-14 04:10:44.000000',4,'3ea105c1bc9b42558023b084f7154a18'),
(463,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NTY4NzYyNywiaWF0IjoxNzY1MDgyODI3LCJqdGkiOiIzNmZjMzE0N2RmYzk0MWEzOTk0Y2MwZTRmZDQ2ODhlMyIsInVzZXJfaWQiOiIxMyJ9.aRf49468BGt4YfbjrbC53cEw96thPRKpqekfI8ihlhI','2025-12-07 04:47:07.231599','2025-12-14 04:47:07.000000',13,'36fc3147dfc941a3994cc0e4fd4688e3');
/*!40000 ALTER TABLE `token_blacklist_outstandingtoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `role` varchar(20) NOT NULL,
  `school_id` bigint(20) DEFAULT NULL,
  `linked_staff_id` bigint(20) DEFAULT NULL,
  `linked_student_id` bigint(20) DEFAULT NULL,
  `linked_guard_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `linked_staff_id` (`linked_staff_id`),
  UNIQUE KEY `linked_student_id` (`linked_student_id`),
  UNIQUE KEY `linked_guard_id` (`linked_guard_id`),
  KEY `users_school_id_00497666_fk_schools_id` (`school_id`),
  CONSTRAINT `users_linked_guard_id_02c5ea18_fk_guard_id` FOREIGN KEY (`linked_guard_id`) REFERENCES `guard` (`id`),
  CONSTRAINT `users_linked_staff_id_03399757_fk_staff_id` FOREIGN KEY (`linked_staff_id`) REFERENCES `staff` (`id`),
  CONSTRAINT `users_linked_student_id_d7fbe7a1_fk_students_id` FOREIGN KEY (`linked_student_id`) REFERENCES `students` (`id`),
  CONSTRAINT `users_school_id_00497666_fk_schools_id` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'pbkdf2_sha256$1000000$zUGz5VhLt6O8slvmgrh5s0$VkYzXrWjiWOZQpfcK9BN1ZKPxa7TQJj1loR5sT1mbjQ=','2025-11-13 05:25:59.363844',1,'root','','','mandaknidevi04@gmail.com',1,1,'2025-11-12 19:38:23.514534','superuser',NULL,NULL,NULL,NULL),
(2,'pbkdf2_sha256$1000000$qhBQ7LwqKTKRqFPfmjdZCL$y8PuM/dcTC48dRnrPnkyHrks7UBDlVr09HQhKPfRcSQ=','2025-11-28 02:18:29.091986',1,'aryan','','','aryan@aryan.com',1,1,'2025-11-12 21:05:59.064943','superuser',NULL,NULL,NULL,NULL),
(4,'pbkdf2_sha256$1000000$M5VD5O6BC1WVcZ9UfAxBsl$pd5qqEX2vM/JjYpLpZTrjCTjU5gtRk/vREvuFqso7fk=',NULL,1,'mohinderpunia82@gmail.com','mohinder','punia','mohinderpunia82@gmail.com',1,1,'2025-11-13 03:41:10.000000','superuser',NULL,NULL,NULL,NULL),
(6,'pbkdf2_sha256$1000000$JLFOs2Hm8Tea8L5qa3iNiM$u+WQ0xb9EpM32sLbTLZeJaC2+Xc/JBmvCCaKUoQXau4=',NULL,0,'ASIANHIGHSCHOOL','','','ASIANHIGHSCHOOL0@gmail.com',0,1,'2025-11-13 05:30:55.291538','school_admin',3,NULL,NULL,NULL),
(7,'pbkdf2_sha256$1000000$FmLlfLJeZkSSquBjBAYvHq$+FwSHol/8O2wyLWRWRH03AlceK/6CBIg6+K2nG+dmdA=',NULL,0,'Samrat','','','',0,1,'2025-11-13 05:42:12.899242','student',3,NULL,1,NULL),
(8,'pbkdf2_sha256$1000000$M6d6y0COOR1qmkMw18ongK$bhYH01nlbN1ARn0qGgir4PlYi6QuWFu5QzyNs25FTEk=',NULL,0,'nirakarjyotividyamandir','','','njvidyamandir@gmail.com',0,1,'2025-11-13 07:25:29.482266','school_admin',4,NULL,NULL,NULL),
(9,'pbkdf2_sha256$1000000$VFl5Wa4cW9bW6evlod8jgL$1421aLcV0UmKSOWndoIxwfjgihiYNPszuQfXSUN8k9A=',NULL,0,'Lavit','','','',0,1,'2025-11-13 07:34:13.375570','student',4,NULL,2,NULL),
(12,'pbkdf2_sha256$1000000$BUDONfGZfEbZ4nWoFjYEKM$PH3WBDsY3qCPRK/VmZSrBTfEvygBo8RZeW+cJbjK7vg=',NULL,0,'Jaswantparmar','','','parmarjaswant073@gmail.com',0,1,'2025-11-16 03:52:13.415694','school_admin',7,NULL,NULL,NULL),
(13,'pbkdf2_sha256$1000000$VyLHhD8bXEavg6p7FQwIw9$hoyDi62B/tl98xC/47pHTklidVQos6biN6KVKolv3vU=',NULL,0,'feeadmin','','','makegraphy92@gmail.com',0,1,'2025-11-17 01:14:35.481863','school_admin',8,NULL,NULL,NULL),
(16,'pbkdf2_sha256$1000000$682W89mgpXV2OKHxdLzEmh$QKzTMuhAdgn/Lvc2bchWVK+jj6P5EU9su0s8si4BbQ0=',NULL,0,'mothercare','','','mothercare736@gmail.com',0,1,'2025-11-19 04:21:27.190477','school_admin',11,NULL,NULL,NULL),
(18,'pbkdf2_sha256$1000000$cxFaPFhx4iczhlx7OqXyHa$unmpa/WyebkEGXonlces73+Q4VZhJaUzTM3pwTDObms=',NULL,0,'saraswatischool','','','saraswatipublicschool2019@gmail.com',0,1,'2025-11-20 04:21:41.467322','school_admin',13,NULL,NULL,NULL),
(20,'pbkdf2_sha256$1000000$fMoyK1tH7YEJEy3slYqctH$t6De/LxZo+16/Su2siN4AygubxN2x9aZ3HuCKQ6om6c=',NULL,0,'ravindraschool','','','kondal1683@gmail.com',0,1,'2025-11-21 04:25:39.994247','school_admin',15,NULL,NULL,NULL),
(21,'pbkdf2_sha256$1000000$RP3nkhuOJkZ1BTAxurydsv$Y5/PV/MLhhT+kWxHePDqO7Ik0k194gR4W6r7c9CDWQI=',NULL,0,'GVPjangal','','','gvpjangal@gmail.com',0,1,'2025-11-21 05:42:59.887517','school_admin',16,NULL,NULL,NULL),
(22,'pbkdf2_sha256$1000000$BBqI84VaACVc7b3HHnIUYX$VX430A+gc3S4ZholpRaAlGqx15OHsMz1KvML7zR4hoY=',NULL,0,'shivalikpublicschool','','','bijendershahapur23@gmail.com',0,1,'2025-11-25 05:52:31.486238','school_admin',17,NULL,NULL,NULL),
(28,'pbkdf2_sha256$1000000$3iUnW9Bw05i3x14jUJICtY$NYkCrKUp3mdclJLbYbqcuIJjaG4WUpvfLmXpXE19crA=',NULL,0,'mahender_punia_0001','','','',0,1,'2025-11-26 09:50:37.932540','guard',8,NULL,NULL,6),
(32,'pbkdf2_sha256$1000000$lb9xESwwAuwjdpE9Whu81J$TTjfautkhlQTaIlI0FtybPPwWojVJ7MkSeTL3zb3260=',NULL,0,'mdpublicschool','','','chanderparkasharya@gmail.com',0,1,'2025-11-28 04:46:26.553278','school_admin',21,NULL,NULL,NULL),
(37,'pbkdf2_sha256$1000000$y9Mb3p5ZsdPMmoQN97EQ4Z$MJJQfwvoza6qmOxiSMCBkUXfDBR3ouLScADbQ8/OFaE=',NULL,0,'Hellois1','','','cursor.08-oxbow@icloud.com',0,1,'2025-11-30 13:28:58.606657','school_admin',25,NULL,NULL,NULL),
(38,'pbkdf2_sha256$1000000$wfBVD0MTgCaHmCCO0Q3B0j$GWXvTnai87AWs+nvr49LE935jZU6uhaiT3SsvZJd8Lo=',NULL,0,'Testtt3','','','cursor.08-oxbow@icloud.com',0,1,'2025-12-01 02:07:48.828876','school_admin',26,NULL,NULL,NULL),
(39,'pbkdf2_sha256$1000000$lNGYDvQjKbC26YItUSyBo7$vdOx8EODrtA9DSTcIlkVObEN3NlB2ktwJUFieLfVRKE=',NULL,0,'maharanapartap','','','mpps9508@gmail.com',0,1,'2025-12-02 04:52:13.058402','school_admin',27,NULL,NULL,NULL),
(40,'pbkdf2_sha256$1000000$VF1IEUPj80AJsaBye0rghl$tEzPuGquoXR7pd4aEquhtzuIFx5vGV1FjE6KB+k5r8k=',NULL,0,'graminvikasschool','','','vinay99816@gmail.com',0,1,'2025-12-02 06:56:07.248936','school_admin',28,NULL,NULL,NULL),
(41,'pbkdf2_sha256$1000000$Bqtz0tMCNrRZ06Aebahvs7$o5oGh7joa/2jwXMSzOZ3ZqQS18IhQtzWr8zgVbgIfyA=',NULL,0,'tamanataman','','','',0,1,'2025-12-02 07:22:15.517505','student',28,NULL,64,NULL),
(42,'pbkdf2_sha256$1000000$vowYvS4EODvbFw1PBYdLZx$hYBX5TYM0TiKX/uaxcjXAI7YVChYbrST6cveqxAD9lY=',NULL,0,'aryanshi','','','mandaknidevi04@gmail.com',0,1,'2025-12-03 01:10:15.613529','school_admin',29,NULL,NULL,NULL),
(43,'pbkdf2_sha256$1000000$ptk1IAqfnxxhAS57u461gr$zqSJU3WWRF9/IpY4syT1J1iM3NOxT6Wv+ZNHVSa/3Fs=',NULL,0,'vedpublicschool','','','vedpublicschool15@gmail.com',0,1,'2025-12-03 06:09:19.290068','school_admin',30,NULL,NULL,NULL),
(45,'pbkdf2_sha256$1000000$fIuBH0g58BSPnsCpq2YzqB$/7ygQiEFxGsCLGbySVcyoSZ4om4cMBt18GCb9Q3ov/c=',NULL,0,'aaa_1564664','','','',0,1,'2025-12-03 06:20:43.425387','guard',30,NULL,NULL,9);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_groups_user_id_group_id_fc7788e8_uniq` (`user_id`,`group_id`),
  KEY `users_groups_group_id_2f3517aa_fk_auth_group_id` (`group_id`),
  CONSTRAINT `users_groups_group_id_2f3517aa_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `users_groups_user_id_f500bee5_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_groups`
--

LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_user_permissions`
--

DROP TABLE IF EXISTS `users_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_user_permissions_user_id_permission_id_3b86cbdf_uniq` (`user_id`,`permission_id`),
  KEY `users_user_permissio_permission_id_6d08dcd2_fk_auth_perm` (`permission_id`),
  CONSTRAINT `users_user_permissio_permission_id_6d08dcd2_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `users_user_permissions_user_id_92473840_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_user_permissions`
--

LOCK TABLES `users_user_permissions` WRITE;
/*!40000 ALTER TABLE `users_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitor`
--

DROP TABLE IF EXISTS `visitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `visitor` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `contact_no` varchar(30) NOT NULL,
  `purpose` varchar(250) NOT NULL,
  `id_proof` varchar(250) NOT NULL,
  `vehicle_no` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `time_in` time(6) DEFAULT NULL,
  `time_out` time(6) DEFAULT NULL,
  `notes` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `guard_id` bigint(20) DEFAULT NULL,
  `school_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `visitor_guard_id_2db0e75e_fk_guard_id` (`guard_id`),
  KEY `visitor_school_id_f922394d_fk_schools_id` (`school_id`),
  CONSTRAINT `visitor_guard_id_2db0e75e_fk_guard_id` FOREIGN KEY (`guard_id`) REFERENCES `guard` (`id`),
  CONSTRAINT `visitor_school_id_f922394d_fk_schools_id` FOREIGN KEY (`school_id`) REFERENCES `schools` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitor`
--

LOCK TABLES `visitor` WRITE;
/*!40000 ALTER TABLE `visitor` DISABLE KEYS */;
INSERT INTO `visitor` VALUES
(1,'Mahender Punia','9518233053','Office Meeting','255424275354','HR05-1455','2025-11-26','07:06:43.000000','12:37:33.000000','','2025-11-26 07:06:43.284025','2025-11-26 10:29:29.839040',NULL,8),
(4,'Bhagwan Dass','9518233053','Office Meeting','255424275354','HR05-1455','2025-11-28','02:48:05.000000','08:29:27.000000','','2025-11-28 02:48:05.050165','2025-11-28 02:59:26.927485',NULL,8),
(6,'Mahender Punia','9518233053','Office Meeting','255424275354','HR05-1455','2025-11-28','08:36:48.000000','08:37:10.000000','','2025-11-28 03:06:48.094761','2025-11-28 03:07:10.628975',NULL,8),
(8,'Mahender Punia','99999999999','Office Meeting','255424275354','HR05-1455','2025-12-02','11:58:27.000000','11:58:34.000000','','2025-12-02 06:28:27.445511','2025-12-02 06:28:34.616417',NULL,8);
/*!40000 ALTER TABLE `visitor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-08  2:13:17
